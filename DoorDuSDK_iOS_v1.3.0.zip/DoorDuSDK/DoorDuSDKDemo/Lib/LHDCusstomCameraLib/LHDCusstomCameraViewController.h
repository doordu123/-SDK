//
//  LHDCusstomCameraViewController.h
//  LHDCusstomAlbumAndCamera
//
//  Created by 秦沙沙 on 16/3/27.
//  Copyright © 2016年 刘和东. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LHDCusstomCameraViewController;

typedef void (^LHDCusstomCameraGetPhotoImageBlock)(LHDCusstomCameraViewController * cameraVC, UIImage * image);

/**
 *  自定义照相机
 */
@interface LHDCusstomCameraViewController : UIViewController

@property (nonatomic,weak) UIViewController * fromeViewController;//

- (void)cusstomCameraGetPhotoImageBlock:(LHDCusstomCameraGetPhotoImageBlock)block;

- (void)show;

@end
