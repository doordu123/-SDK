//
//  DDDatePickerView.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/25.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDDatePickerView.h"

@interface DDDatePickerView ()

@property (nonatomic, strong) UIDatePicker * datePicker;
@property (nonatomic, strong) UIView * bgView;
@property (nonatomic, strong) UILabel * titleLabel;
@property (nonatomic, strong) UIView * contentView;
@property (nonatomic, assign) CGFloat contentViewHeight;
@property (nonatomic, strong) NSLayoutConstraint * contentViewLayoutConstraintTop;

@property (nonatomic, assign) DDDatePickerReturnDateStringType dateReturnStringType;

/**数据返回*/
@property (nonatomic, copy) void (^returnDataBlock)(NSString * dateString, NSDate * selectedDate);


@end


@implementation DDDatePickerView

+ (DDDatePickerView *)datePickerMode:(UIDatePickerMode)datePickerMode
                dateReturnStringType:(DDDatePickerReturnDateStringType)dateReturnStringType
                         maximumDate:(NSDate *)maximumDate
                         minimumDate:(NSDate *)minimumDate
                         defaultDate:(NSDate *)defaultDate
                               title:(NSString *)title
                     returnDataBlock:(void (^)(NSString * dateString, NSDate * selectedDate))returnDataBlock
{
    DDDatePickerView * pickerView = [[DDDatePickerView alloc] initWithDatePickerMode:datePickerMode dateReturnStringType:dateReturnStringType maximumDate:maximumDate minimumDate:minimumDate defaultDate:defaultDate title:title returnDataBlock:returnDataBlock];
    return pickerView;
}

- (DDDatePickerView *)initWithDatePickerMode:(UIDatePickerMode)datePickerMode
                        dateReturnStringType:(DDDatePickerReturnDateStringType)dateReturnStringType
                                 maximumDate:(NSDate *)maximumDate
                                 minimumDate:(NSDate *)minimumDate
                                 defaultDate:(NSDate *)defaultDate
                                       title:(NSString *)title
                             returnDataBlock:(void (^)(NSString * dateString, NSDate * selectedDate))returnDataBlock
{
    self = [super init];
    if (self) {
        [self __configUI];
        if (maximumDate) {
            _datePicker.maximumDate = maximumDate;
        }
        if (minimumDate) {
            _datePicker.minimumDate = minimumDate;
        }
        if (defaultDate) {
            _datePicker.date = defaultDate;
        } else {
            _datePicker.date = [NSDate date];
        }
        if (title) {
            if (title.length) {
                self.titleLabel.text = title;
            }
        }
        self.dateReturnStringType = dateReturnStringType;
        self.returnDataBlock = returnDataBlock;
    }
    return self;
}

/** 确认按钮点击事件 */
- (void)__sureButtonClicked
{
    if (self.returnDataBlock) {
        [self __returnDate];
    }
    [self dismiss];
}

- (void)__returnDate
{
    NSDate *selectedDate = [_datePicker date];
    // 创建一个日期格式器
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    
    switch (self.dateReturnStringType) {
        case DDDatePickerReturnDateStringyyyyMMddState://@"yyyy-MM-dd"用于选择生日
        {
            [dateFormatter setDateFormat:@"yyyy-MM-dd"];
        }
            break;
        case DDDatePickerReturnDateStringyyyyMMddHHmmState://@"yyyy-MM-dd HH:mm" 选择日期
        {
            [dateFormatter setDateFormat:@"yyyy.MM.dd HH:mm"];
        }
            break;
        case DDDatePickerReturnDateStringyyyyYearMMMonthddDayState://@"yyyy年MM月dd日"用于选择生日
        {
            [dateFormatter setDateFormat:@"yyyy年MM月dd日"];
        }
            break;
        case DDDatePickerReturnDateStringyyyyYearMMMonthddDayHHmmState://@"yyyy年MM日dd日 HH:mm" 选择日期
        {
            [dateFormatter setDateFormat:@"yyyy年MM月dd日 HH:mm"];
        }
            break;
            
        default:
            break;
    }
    NSString *destDateString = [dateFormatter stringFromDate:selectedDate];
    if (self.returnDataBlock) {
        self.returnDataBlock(destDateString, selectedDate);
    }
}

- (void)__configUI
{
    CGFloat datePickerViewHeight = 430/2.0;
    CGFloat topTitleViewHeight = 100/2.0;
    self.translatesAutoresizingMaskIntoConstraints = NO;
    self.contentViewHeight = datePickerViewHeight + topTitleViewHeight;
    //判断是不是iPhone X
    if (([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1125, 2436), [[UIScreen mainScreen] currentMode].size) : NO)) {
        self.contentViewHeight += (83.f - 49.f);
    }
    [self addSubview:self.bgView];
    [self addSubview:self.contentView];
    [self.contentView addSubview:self.datePicker];
    UIView * lineView = [[UIView alloc] init];
    lineView.backgroundColor = [UIColor colorWithRed:229/255.0 green:229/255.0 blue:229/255.0 alpha:1/1.0];
    lineView.translatesAutoresizingMaskIntoConstraints = NO;
    [self.contentView addSubview:lineView];
    
    //取消按钮
    UIButton * cancelButton = [UIButton buttonWithType:UIButtonTypeCustom];
    cancelButton.translatesAutoresizingMaskIntoConstraints = NO;
    [cancelButton setTitle:@"取消" forState:UIControlStateNormal];
    [cancelButton setTitleColor:[[UIColor blackColor]colorWithAlphaComponent:0.8] forState:UIControlStateNormal];
    cancelButton.titleLabel.font = [UIFont systemFontOfSize:36/2.0];
    [cancelButton addTarget:self action:@selector(dismiss) forControlEvents:UIControlEventTouchUpInside];
    [self.contentView addSubview:cancelButton];
    
    //确定按钮
    UIButton * sureButton = [UIButton buttonWithType:UIButtonTypeCustom];
    sureButton.translatesAutoresizingMaskIntoConstraints = NO;
    [sureButton setTitle:@"确定" forState:UIControlStateNormal];
    [sureButton setTitleColor:[[UIColor blackColor]colorWithAlphaComponent:0.8] forState:UIControlStateNormal];
    sureButton.titleLabel.font = [UIFont systemFontOfSize:36/2.0];
    [sureButton addTarget:self action:@selector(__sureButtonClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.contentView addSubview:sureButton];
    
    [self.contentView addSubview:self.titleLabel];
    
    /** 布局 */
    /** self.bgView 布局 */
    //高度
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.bgView attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeHeight multiplier:1 constant:0]];
    //宽度
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.bgView attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeWidth multiplier:1 constant:0]];
    //top
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.bgView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
    //left
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.bgView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    
    /** self.contentView 布局 */
    //高度
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.contentView attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.contentViewHeight]];
    //宽度
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.contentView attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeWidth multiplier:1 constant:0]];
    //left
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.contentView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    //top
    self.contentViewLayoutConstraintTop = [NSLayoutConstraint constraintWithItem:self.contentView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeBottom multiplier:1 constant:0];
    [self addConstraint:self.contentViewLayoutConstraintTop];
    
    /** cancelButton 布局 */
    //高度
    [cancelButton addConstraint:[NSLayoutConstraint constraintWithItem:cancelButton attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:topTitleViewHeight]];
    //宽度
    [cancelButton addConstraint:[NSLayoutConstraint constraintWithItem:cancelButton attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:(73+60)/2.0]];
    //left
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:cancelButton attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    //top
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:cancelButton attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
    
    /** sureButton 布局 */
    //高度
    [sureButton addConstraint:[NSLayoutConstraint constraintWithItem:sureButton attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:topTitleViewHeight]];
    //宽度
    [sureButton addConstraint:[NSLayoutConstraint constraintWithItem:sureButton attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:(73+60)/2.0]];
    //right
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:sureButton attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
    //top
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:sureButton attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
    
    /** titleLabel 布局 */
    //高度
    [self.titleLabel addConstraint:[NSLayoutConstraint constraintWithItem:self.titleLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.titleLabel.font.lineHeight]];
    //左边
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.titleLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:cancelButton attribute:NSLayoutAttributeRight multiplier:1 constant:5]];
    //right
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.titleLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:sureButton attribute:NSLayoutAttributeLeft multiplier:1 constant:-5]];
    //centerY
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.titleLabel attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:sureButton attribute:NSLayoutAttributeCenterY multiplier:1 constant:0]];
    
    /** lineView 布局 */
    //高度
    [lineView addConstraint:[NSLayoutConstraint constraintWithItem:lineView attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:1]];
    //left
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:lineView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    //right
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:lineView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
    //bottom
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:lineView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:sureButton attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
    
    /** self.datePicker 布局  */
    //高度
    [self.datePicker addConstraint:[NSLayoutConstraint constraintWithItem:self.datePicker attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:datePickerViewHeight]];
    //left
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.datePicker attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    //right
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.datePicker attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
    //top
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.datePicker attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:sureButton attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
    
    
}

#pragma mark - 当滑动的时候
- (void)_datePickerValueChanged:(UIDatePicker *)datePicker
{
    
}

#pragma mark - 懒加载
/**
 用于显示标题
 */
- (UILabel *)titleLabel
{
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc] init];
        _titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
        _titleLabel.textColor = [[UIColor blackColor]colorWithAlphaComponent:0.8];
        _titleLabel.font = [UIFont systemFontOfSize:34/2.0];
        _titleLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _titleLabel;
}

/**
 背景view
 */
- (UIView *)bgView
{
    if (!_bgView) {
        _bgView = [[UIView alloc] init];
        _bgView.userInteractionEnabled = YES;
        _bgView.alpha = 0;
        _bgView.translatesAutoresizingMaskIntoConstraints = NO;
        _bgView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.5];
        UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismiss)];
        [_bgView addGestureRecognizer:tap];
    }
    return _bgView;
}
/**
 内容view
 */
- (UIView *)contentView
{
    if (!_contentView) {
        _contentView = [[UIView alloc] init];
        _contentView.userInteractionEnabled = YES;
        _contentView.clipsToBounds = YES;
        _contentView.backgroundColor = [UIColor whiteColor];
        _contentView.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _contentView;
}
- (UIDatePicker *)datePicker
{
    if (!_datePicker) {
        _datePicker = [[UIDatePicker alloc]init];
        _datePicker.datePickerMode = UIDatePickerModeDate;
        [_datePicker setBackgroundColor:[UIColor whiteColor]];
        NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:@"zh_CN"];//设置为中文
        _datePicker.locale = locale;
        _datePicker.date = [NSDate date];
        _datePicker.translatesAutoresizingMaskIntoConstraints = NO;
        [_datePicker addTarget:self action:@selector(_datePickerValueChanged:) forControlEvents:UIControlEventValueChanged];
    }
    return _datePicker;
}



- (void)showFromView:(UIView *)fromView
{
    [fromView addSubview:self];
    //top
    [fromView addConstraint:[NSLayoutConstraint constraintWithItem:self attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:fromView attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
    //bottom
    [fromView addConstraint:[NSLayoutConstraint constraintWithItem:self attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:fromView attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
    //right
    [fromView addConstraint:[NSLayoutConstraint constraintWithItem:self attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:fromView attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
    //left
    [fromView addConstraint:[NSLayoutConstraint constraintWithItem:self attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:fromView attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    [fromView layoutIfNeeded];
    
    self.contentViewLayoutConstraintTop.constant = -self.contentViewHeight;
    [UIView animateWithDuration:0.3 animations:^{
        self.bgView.alpha = 1;
        [self layoutIfNeeded];
    }];
}

- (void)dismiss
{
    self.contentViewLayoutConstraintTop.constant = 0;
    [UIView animateWithDuration:0.3 delay:0 options: UIViewAnimationOptionCurveEaseOut animations:^{
        self.bgView.alpha = 0;
        [self layoutIfNeeded];
    } completion:^(BOOL finished) {
        [self.datePicker removeFromSuperview];
        [self removeFromSuperview];
    }];
}

- (void)dealloc
{
    NSLog(@"dealloc: %@",NSStringFromClass([self class]));
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
