//
//  DDSearchController.h
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/3/9.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DDSearchResultTableViewController.h"
#import "UIView+DDFrame.h"

typedef void (^DDSearchUpdateSearchResultsForSearchVCBlock)(UISearchController * searchVC,NSString * searchText);
typedef void (^DDSearchBarSearchButtonClickedSearchVCBlock)(UISearchController * searchVC,UISearchBar * searchBar);
typedef void (^DDSearchBarSearchButtonCancelSearchVCBlock)(UISearchController * searchVC,UISearchBar * searchBar);
typedef void (^DDSearchPresentSearchControllerBlock)(UISearchController * searchVC);
typedef void (^DDSearchDismissSearchControllerBlock)(UISearchController * searchVC);
typedef void (^DDSearchWillDismissSearchControllerBlock)(UISearchController * searchVC);

@interface DDSearchController : UISearchController

/**向上移动距离*/
@property (nonatomic, assign) CGFloat upwardMoveHeight;

/** 搜索的最大长度 ，默认 20*/
@property (nonatomic, assign) NSInteger searchMaxLength;

/**时时搜索的数据*/
- (void)realTimeSearchResultsBlock:(DDSearchUpdateSearchResultsForSearchVCBlock)block;
/**搜索点击按钮*/
- (void)searchButtonClickedBlock:(DDSearchBarSearchButtonClickedSearchVCBlock)block;
/**取消搜索点击按钮*/
- (void)cancelButtonClickedBlock:(DDSearchBarSearchButtonCancelSearchVCBlock)block;
- (void)presentSearchControllerBlock:(DDSearchPresentSearchControllerBlock)block;
- (void)didDismissSearchControllerBlock:(DDSearchDismissSearchControllerBlock)block;
- (void)willDismissSearchControllerBlock:(DDSearchWillDismissSearchControllerBlock)block;

@end
