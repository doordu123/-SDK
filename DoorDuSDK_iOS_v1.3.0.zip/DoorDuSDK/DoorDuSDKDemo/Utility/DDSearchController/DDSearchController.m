//
//  DDSearchController.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/3/9.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDSearchController.h"

@interface DDSearchController () <UISearchResultsUpdating,UISearchBarDelegate,UISearchControllerDelegate>

@property (nonatomic,copy) DDSearchUpdateSearchResultsForSearchVCBlock searchResultBlock;

@property (nonatomic,copy) DDSearchBarSearchButtonClickedSearchVCBlock searchButtonClikcedBlock;

@property (nonatomic,copy) DDSearchBarSearchButtonCancelSearchVCBlock searchButtonCancelBlock;

@property (nonatomic,copy) DDSearchPresentSearchControllerBlock presentBlock;

@property (nonatomic,copy) DDSearchDismissSearchControllerBlock dismissBlock;

@property (nonatomic,copy) DDSearchWillDismissSearchControllerBlock willDismissBlock;

@property (nonatomic,weak) DDSearchResultTableViewController * resultsController;


@end

@implementation DDSearchController

- (instancetype)initWithSearchResultsController:(UIViewController *)searchResultsController
{
    self = [super initWithSearchResultsController:searchResultsController];
    if (self) {
        [self configUI:searchResultsController];
    }
    return self;
}

- (void)configUI:(UIViewController *)searchResultsController
{
    self.searchMaxLength = 20;
    self.upwardMoveHeight = 0;
    // 是否添加半透明覆盖层
    self.dimsBackgroundDuringPresentation = YES;
    if (searchResultsController) {
        searchResultsController.definesPresentationContext = YES;
    }
    self.definesPresentationContext = YES;
    self.searchResultsUpdater = self;
    self.delegate = self;
    //是否隐藏导航栏
    self.hidesNavigationBarDuringPresentation = YES;
    self.searchBar.delegate = self;
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    UIView * topView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, [UIApplication sharedApplication].statusBarFrame.size.height+44)];
    topView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:topView];
    [self.searchBar sizeToFit];
}

- (void)updateSearchResultsForSearchController:(UISearchController *)searchController
{
    NSLog(@"%@",searchController.searchBar.text);
    if (self.searchResultBlock) {
        self.searchResultBlock(searchController,searchController.searchBar.text);
    }
}

- (void)willDismissSearchController:(UISearchController *)searchController;
{
    if (self.willDismissBlock) {
        self.willDismissBlock(searchController);
    }
}
- (void)willDismissSearchControllerBlock:(DDSearchWillDismissSearchControllerBlock)block
{
    self.willDismissBlock = block;
}

- (void)presentSearchController:(UISearchController *)searchController
{
    self.presentBlock(searchController);
    self.searchBar.top = 0;
}

- (void)didDismissSearchController:(UISearchController *)searchController
{
    if (self.dismissBlock) {
        self.dismissBlock(searchController);
    }
    __weak typeof(self) weakSelf = self;
    [UIView animateWithDuration:0.10 animations:^{
        weakSelf.searchBar.top = weakSelf.upwardMoveHeight;
    }];
}

- (void)presentSearchControllerBlock:(DDSearchPresentSearchControllerBlock)block
{
    self.presentBlock = block;
}
- (void)didDismissSearchControllerBlock:(DDSearchPresentSearchControllerBlock)block
{
    self.dismissBlock = block;
}

#pragma mark - UISearchBarDelegate
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    if (self.searchButtonClikcedBlock) {
        self.searchButtonClikcedBlock(self,searchBar);
    }
}
- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    if (self.searchButtonCancelBlock) {
        self.searchButtonCancelBlock(self,searchBar);
    }
    if (_resultsController) {
        if (_resultsController.ddSearchClearData) {
            _resultsController.ddSearchClearData();
        }
    }
}

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar{
    searchBar.showsCancelButton = YES;
    for(UIView *view in  [[[searchBar subviews] objectAtIndex:0] subviews]) {
        if([view isKindOfClass:[NSClassFromString(@"UINavigationButton") class]]) {
            UIButton * cancel =(UIButton *)view;
            [cancel setTitle:@"取消" forState:UIControlStateNormal];
            cancel.titleLabel.font = [UIFont systemFontOfSize:16];
        }
    }
}

-(BOOL)searchBar:(UISearchBar *)searchBar shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    NSCharacterSet *doNotWant = [NSCharacterSet characterSetWithCharactersInString:@"[]{}（#%-*+=_）\\|~(＜＞$%^&*￥)_+ #——……！@￥"];
    NSRange rangeOfText = [text rangeOfCharacterFromSet:doNotWant];
    if ((rangeOfText.location != NSNotFound) || searchBar.text.length > self.searchMaxLength) {
        return NO;
    }
    return YES;
}


- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    if (searchText.length == 0) {
        if (_resultsController) {
            if (_resultsController.ddSearchClearData) {
                _resultsController.ddSearchClearData();
            }
        }
    }
}

- (void)searchButtonClickedBlock:(DDSearchBarSearchButtonClickedSearchVCBlock)block
{
    self.searchButtonClikcedBlock = block;
}
/**取消搜索点击按钮*/
- (void)cancelButtonClickedBlock:(DDSearchBarSearchButtonCancelSearchVCBlock)block;
{
    self.searchButtonCancelBlock = block;
}

#pragma mark - UISearchResultsUpdating
/**时时搜索的数据*/
- (void)realTimeSearchResultsBlock:(DDSearchUpdateSearchResultsForSearchVCBlock)block
{
    self.searchResultBlock = block;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-d application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
