//
//  DDSearchResultTableViewController.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/3/9.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDSearchResultTableViewController.h"

@interface DDSearchResultTableViewController ()

@end

@implementation DDSearchResultTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.definesPresentationContext = YES;
    self.tableView.tableFooterView = [[UIView alloc] init];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (_ddNumberOfSectionsInTableView) {
        return _ddNumberOfSectionsInTableView(tableView);
    }
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (_ddSearchNumberOfRowsInSection) {
        return _ddSearchNumberOfRowsInSection(tableView,section);
    }
    return 0;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (_ddSearchCellForRowAtIndexPath) {
        return _ddSearchCellForRowAtIndexPath(tableView, indexPath);
    }
    else{
        UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"UITableViewCellCCCCCCCCDDSearchDisplayController"];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"UITableViewCellCCCCCCCCDDSearchDisplayController"];
        }
        return cell;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (_ddSearchHeightForHeaderInSection) {
        return _ddSearchHeightForHeaderInSection(tableView, section);
    }else {
        return 0.0;
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (_ddSearchViewForHeaderInSection) {
        return _ddSearchViewForHeaderInSection(tableView,section);
    } else {
        UITableViewHeaderFooterView * view = [tableView dequeueReusableHeaderFooterViewWithIdentifier:@"UITableViewHeaderFooterView"];
        if (!view) {
            view = [[UITableViewHeaderFooterView alloc] initWithReuseIdentifier:@"UITableViewHeaderFooterView"];
        }
        return view;
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    if (_ddSearchHeightForFooterInSection) {
        return _ddSearchHeightForFooterInSection(tableView, section);
    }else {
        return 0.0;
    }
}

// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    if (_ddSearchCanEditRowAtIndexPath) {
        return _ddSearchCanEditRowAtIndexPath(tableView, indexPath);
    }
    else{
        return NO;
    }
}
#pragma mark - Table view delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (_ddSearchHeightForRowAtIndexPath) {
        return _ddSearchHeightForRowAtIndexPath(tableView, indexPath);
    }
    return 0.0;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (_ddSearchDidSelectRowAtIndexPath) {
        return _ddSearchDidSelectRowAtIndexPath(tableView, indexPath);
    }
}
- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (_ddSearchDidDeselectRowAtIndexPath) {
        _ddSearchDidDeselectRowAtIndexPath(tableView, indexPath);
    }else{
        [tableView deselectRowAtIndexPath:indexPath animated:NO];
    }
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    if (_ddSearchWillBeginDragging) {
        _ddSearchWillBeginDragging();
    }
    NSLog(@"开始拖拽的时候");
}

/**刷新数据*/
- (void)reloadData
{
    [self.tableView reloadData];
}


- (void)dealloc
{
    NSLog(@"\ndealloc: %@\n",NSStringFromClass([self class]));
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-d application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
