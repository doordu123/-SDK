//
//  DDSearchResultTableViewController.h
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/3/9.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DDSearchResultTableViewController : UITableViewController

/**返回当前的cell*/
@property (nonatomic,copy) UITableViewCell * (^ddSearchCellForRowAtIndexPath)(UITableView *tableView, NSIndexPath *indexPath);
/**是否可以编辑*/
@property (nonatomic,copy) BOOL (^ddSearchCanEditRowAtIndexPath)(UITableView *tableView, NSIndexPath *indexPath);
/**当前cell的高度*/
@property (nonatomic,copy) CGFloat (^ddSearchHeightForRowAtIndexPath)(UITableView *tableView, NSIndexPath *indexPath);
/**当前section header的高度*/
@property (nonatomic,copy) CGFloat (^ddSearchHeightForHeaderInSection)(UITableView *tableView, NSInteger section);
/**当前section header View*/
@property (nonatomic,copy) UIView * (^ddSearchViewForHeaderInSection)(UITableView *tableView, NSInteger section);



/**当前section footer的高度*/
@property (nonatomic,copy) CGFloat (^ddSearchHeightForFooterInSection)(UITableView *tableView, NSInteger section);
/**选中的行*/
@property (nonatomic,copy) void (^ddSearchDidSelectRowAtIndexPath)(UITableView *tableView, NSIndexPath *indexPath);
/**反选中的行*/
@property (nonatomic,copy) void (^ddSearchDidDeselectRowAtIndexPath)(UITableView *tableView, NSIndexPath *indexPath);
/**section 对应的多少row*/
@property (nonatomic,copy) NSInteger (^ddSearchNumberOfRowsInSection)(UITableView *tableView, NSInteger section);
/**有多少个 section*/
@property (nonatomic,copy) NSInteger (^ddNumberOfSectionsInTableView)(UITableView *tableView);

/**开始拖拽的时候，这时可以做一些操作，比如：用于隐藏键盘*/
@property (nonatomic,copy) void (^ddSearchWillBeginDragging)(void);
/**清空数据*/
@property (nonatomic,copy) void (^ddSearchClearData)(void);

/**刷新数据*/
- (void)reloadData;

@end
