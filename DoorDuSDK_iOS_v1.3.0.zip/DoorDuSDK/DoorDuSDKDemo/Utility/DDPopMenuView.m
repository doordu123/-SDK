//
//  DDPopMenuView.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/31.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDPopMenuView.h"
#import "UIView+DDFrame.h"

@interface DDPopMenuView () <UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView * tableView;

@property (nonatomic, strong) DDPopArrowView * popArrowView;

@end

@implementation DDPopMenuView

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self configUI];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self configUI];
    }
    return self;
}

- (void)configUI
{
    self.selectedRow = 0;
    self.singleRowHeight = 90/2.0;
    [self addSubview:self.tableView];
    self.tableView.backgroundColor = [UIColor orangeColor];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    self.tableView.frame = self.bounds;
}

- (void)setTitlesArray:(NSArray *)titlesArray
{
    _titlesArray = titlesArray;
    if (!_maxRowNumber) {//没有设置过
        _maxRowNumber = _titlesArray.count;
    }
    [self.tableView reloadData];
}

- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.width, self.height) style:UITableViewStylePlain];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.bounces = NO;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    return _tableView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return self.singleRowHeight;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.titlesArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"UITableViewCell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"UITableViewCell"];
        cell.textLabel.font = [UIFont systemFontOfSize:32/2.0];
        cell.textLabel.textColor = [[UIColor blackColor]colorWithAlphaComponent:0.6];
        UIView * lineView = [[UIView alloc] initWithFrame:CGRectMake(15, 0, self.width-15, 0.5)];
        lineView.height = 0.5;
        lineView.backgroundColor = [[UIColor blackColor]colorWithAlphaComponent:0.18];
        lineView.tag = 100;
        [cell.contentView addSubview:lineView];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    UIView * lineView = [cell viewWithTag:100];
    if (indexPath.row == self.titlesArray.count-1) {
        lineView.hidden = YES;
    } else {
        lineView.hidden = NO;
    }
    lineView.bottom = self.singleRowHeight;
    if (self.selectedRow == indexPath.row) {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
    } else {
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    cell.textLabel.x = 15;
    cell.textLabel.text = self.titlesArray[indexPath.row];
    return cell;

}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    self.selectedRow = indexPath.row;
    [self.tableView reloadData];
    if (self.returnSelectedBlock) {
        self.returnSelectedBlock(indexPath.row, self.titlesArray[indexPath.row]);
    }
    [self.popArrowView dismiss];
}

- (void)showFromView:(UIView *)fromView superView:(UIView *)superView
{
    self.popArrowView = [DDPopArrowView popViewWithContentView:self withStyle:DDPopArrowViewBackgroundStyleDefault showFromView:fromView superView:superView];
}

- (void)showFromPoint:(CGPoint)fromPoint superView:(UIView *)superView
{
    self.popArrowView = [DDPopArrowView popViewWithContentView:self withStyle:DDPopArrowViewBackgroundStyleDefault showFromPoint:fromPoint superView:superView];
}

- (void)dismissComplete:(void (^)(void))complete
{
    [self.popArrowView dismissComplete:complete];
}

- (void)dealloc
{
    NSLog(@"dealloc:%@",NSStringFromClass([self class]));
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
