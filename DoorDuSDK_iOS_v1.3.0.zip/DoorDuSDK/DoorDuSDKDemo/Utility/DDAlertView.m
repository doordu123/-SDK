//
//  DDAlertView.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/26.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDAlertView.h"

@interface DDUIAlertAction : UIAlertAction

/**增加一个标记*/
@property (nonatomic,assign) NSUInteger tag;

@end

@implementation DDUIAlertAction

@end

@implementation DDAlertView

/**
 * vc：弹出的控制器
 * title：标题
 * message：内容
 * otherButtons：点击按钮数组，按照数组顺序，按钮从上向下拍
 * clickedBlock：返回点击了第几个，按照数组顺序,从 0 开始
 */
+ (void)alertShowWithVC:(UIViewController *)vc
                  title:(NSString *)title
                message:(NSString *)message
       otherButtonTitle:(NSArray *)otherButtons
           clickedBlock:(void (^)(NSInteger index))clickedBlock
{
    /** 初始化UIAlertController */
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title
                                                                   message:message
                                                            preferredStyle:UIAlertControllerStyleAlert];
    if (otherButtons.count) {
        for (NSInteger i = 0; i < otherButtons.count ; i++) {
            NSString * alertTitle = otherButtons[i];
            DDUIAlertAction * aaction = [DDUIAlertAction actionWithTitle:alertTitle style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                DDUIAlertAction * dAction = (DDUIAlertAction *)action;
                if (clickedBlock) {
                    clickedBlock(dAction.tag);
                }
            }];
            aaction.tag = i;
            [alert addAction:aaction];
        }
    }
    /**弹出*/
    [vc presentViewController:alert animated:YES completion:^ {
    }];
}

@end
