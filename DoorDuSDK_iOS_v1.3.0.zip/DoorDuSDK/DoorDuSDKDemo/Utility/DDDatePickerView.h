//
//  DDDatePickerView.h
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/25.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import <UIKit/UIKit.h>

/**返回时间字符串类型*/
typedef NS_ENUM(NSInteger, DDDatePickerReturnDateStringType) {
    DDDatePickerReturnDateStringyyyyMMddState,  //@"yyyy-MM-dd"用于选择生日 yyyy-MM-dd
    DDDatePickerReturnDateStringyyyyMMddHHmmState,  //@"yyyy.MM.dd HH:mm" 选择日期
    DDDatePickerReturnDateStringyyyyYearMMMonthddDayState,  //@"yyyy年MM月dd日"用于选择生日
    DDDatePickerReturnDateStringyyyyYearMMMonthddDayHHmmState,  //@"yyyy年MM日dd日 HH:mm" 选择日期
};


@interface DDDatePickerView : UIView


/**
 类方法 返回 DDDatePickerView

 @param datePickerMode
                      UIDatePickerModeTime用户选择当天的时间
                      UIDatePickerModeDate用于选择生日用的
                      UIDatePickerModeDateAndTime用于选择今年的日期和时间
                      UIDatePickerModeCountDownTimer 用于选择当个小时和分钟
 @param dateReturnStringType 时间返回的格式字符串
 @param maximumDate 最大的时间，可以为nil(用于选择生日的时候，肯定不能超过当前的时间)（[NSDate date]）,活动的开始时间也肯定大于当前的时间
 @param minimumDate 最小的时间，可以为nil（用于选择活动时间的时候，设置结束时间的时候（最小时间应该为开始时间）
 @param defaultDate 默认弹出后，显示的时间，默认为当前的时间
 @param title 标题
 @param returnDataBlock 返回值
 @return DDDatePickerView对象
 */
+ (DDDatePickerView *)datePickerMode:(UIDatePickerMode)datePickerMode
                dateReturnStringType:(DDDatePickerReturnDateStringType)dateReturnStringType
                         maximumDate:(NSDate *)maximumDate
                         minimumDate:(NSDate *)minimumDate
                         defaultDate:(NSDate *)defaultDate
                               title:(NSString *)title
                     returnDataBlock:(void (^)(NSString * dateString, NSDate * selectedDate))returnDataBlock;

- (void)showFromView:(UIView *)fromView;
- (void)dismiss;


@end
