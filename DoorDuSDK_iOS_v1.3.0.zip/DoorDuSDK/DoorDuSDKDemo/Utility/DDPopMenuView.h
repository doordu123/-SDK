//
//  DDPopMenuView.h
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/31.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DDPopArrowView.h"

@interface DDPopMenuView : UIView

/** 菜单数组，里面是字符串 */
@property (nonatomic,strong) NSArray * titlesArray;
/** 单行的高度,默认是：45 */
@property (nonatomic,assign) CGFloat singleRowHeight;
/**最多显示几个，几个后可以上下滑动，默认是titlesArray数组的个数*/
@property (nonatomic,assign) NSInteger maxRowNumber;
/**选中了第几个*/
@property (nonatomic,assign) NSInteger selectedRow;

@property (nonatomic, copy) void (^returnSelectedBlock)(NSInteger row, NSString * title);

- (void)showFromView:(UIView *)fromView superView:(UIView *)superView;
- (void)showFromPoint:(CGPoint)fromPoint superView:(UIView *)superView;;

- (void)dismissComplete:(void (^)(void))complete;

@end
