//
//  DDPasswordListTableViewCell.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/3/1.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDPasswordListTableViewCell.h"

@interface DDPasswordListTableViewCell ()

/** 密码 */
@property (nonatomic, strong) UILabel * passwordLabel;

/** 时间 */
@property (nonatomic, strong) UILabel * timeLabel;

/** 状态显示 */
@property (nonatomic, strong) UILabel * stateLabel;

@end

@implementation DDPasswordListTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self _configUI];
    }
    return self;
}

- (void)setModel:(DoorDuOpenDoorPwd *)model
{
    _model = model;
    /**状态 0-未使用 1-已使用 2-已过期*/
    self.passwordLabel.text = model.password;
    self.timeLabel.text = model.apply_time;
    self.stateLabel.text = model.msg;
    if (model.status.integerValue == 0) {
        self.passwordLabel.textColor = [UIColor colorWithRed:0.33 green:0.95 blue:0.64 alpha:1.00];
        self.stateLabel.textColor = [UIColor colorWithRed:0.33 green:0.95 blue:0.64 alpha:1.00];
    } else if (model.status.integerValue == 1) {
        self.passwordLabel.textColor = [UIColor colorWithRed:0.49 green:0.74 blue:0.20 alpha:1.00];
        self.stateLabel.textColor = [UIColor colorWithRed:0.49 green:0.74 blue:0.20 alpha:1.00];
    } else if (model.status.integerValue == 2) {
        self.passwordLabel.textColor = [UIColor colorWithRed:0.71 green:0.71 blue:0.71 alpha:1.00];
        self.stateLabel.textColor = [UIColor colorWithRed:0.98 green:0.46 blue:0.47 alpha:1.00];
    }
}

#pragma mark - 界面布局
- (void)_configUI
{
    [self.contentView addSubview:self.passwordLabel];
    [self.contentView addSubview:self.timeLabel];
    [self.contentView addSubview:self.stateLabel];
    
    /** passwordLabel布局 */
    //左
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.passwordLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.passwordLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeCenterX multiplier:1 constant:0]];
    //上
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.passwordLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeTop multiplier:1 constant:15]];
    //下
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.passwordLabel attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeBottom multiplier:1 constant:-15]];
    
    /** timeLabel布局 */
    //左
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.timeLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeCenterX multiplier:1 constant:-50]];
    //右
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.timeLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeRight multiplier:1 constant:-10]];
    //上
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.timeLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeTop multiplier:1 constant:15]];
    
    /** stateLabel布局 */
    //左
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.stateLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeCenterX multiplier:1 constant:-50]];
    //右
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.stateLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeRight multiplier:1 constant:-10]];
    //上
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.stateLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.timeLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:10]];
    //下
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.stateLabel attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeBottom multiplier:1 constant:-15]];

}

#pragma mark - 懒加载
/** 密码 */
- (UILabel *)passwordLabel
{
    if (!_passwordLabel) {
        _passwordLabel = [[UILabel alloc] init];
        _passwordLabel.translatesAutoresizingMaskIntoConstraints = NO;
        _passwordLabel.font = [UIFont systemFontOfSize:26];
    }
    return _passwordLabel;
}
/** 时间 */
- (UILabel *)timeLabel
{
    if (!_timeLabel) {
        _timeLabel = [[UILabel alloc] init];
        _timeLabel.translatesAutoresizingMaskIntoConstraints = NO;
        _timeLabel.font = [UIFont systemFontOfSize:13];
        _timeLabel.textAlignment = NSTextAlignmentRight;
        _timeLabel.textColor = [UIColor colorWithRed:0.00 green:0.00 blue:0.00 alpha:1.00];
    }
    return _timeLabel;
}
/** 状态显示 */
- (UILabel *)stateLabel
{
    if (!_stateLabel) {
        _stateLabel = [[UILabel alloc] init];
        _stateLabel.translatesAutoresizingMaskIntoConstraints = NO;
        _stateLabel.font = [UIFont systemFontOfSize:18];
        _stateLabel.textAlignment = NSTextAlignmentRight;
    }
    return _stateLabel;
}


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
