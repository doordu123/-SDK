//
//  DDPasswordDetailViewController.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/2/28.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDPasswordDetailViewController.h"

@interface DDPasswordDetailViewController ()<UITableViewDelegate,UITableViewDataSource>

/** 密码 */
@property (nonatomic, strong) UILabel * passwordLabel;

/** 时间 */
@property (nonatomic, strong) UILabel * timeLabel;

@property (nonatomic, strong) UITableView * tableView;

@property (nonatomic, strong) DoorDuOpenDoorPasswordDetail * detailModel;

@end

@implementation DDPasswordDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if (@available(iOS 11.0, *)){
        [[UIScrollView appearance] setContentInsetAdjustmentBehavior:UIScrollViewContentInsetAdjustmentNever];
    } else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }

    self.view.backgroundColor = [UIColor whiteColor];
    [self _configUI];

    [self _requestPasswordDetailData];
    
    
}

#pragma mark - 获取密码详情
- (void)_requestPasswordDetailData
{
    __weak typeof(self) weakSelf = self;
    [DoorDuDataManager getDoorPasswordDetailWithRoomId:self.roomInfo.room_number_id passwordId:self.model.password_id completion:^(DoorDuOpenDoorPasswordDetail *pwdDetail, DoorDuError *error) {
        if (!error) {
            weakSelf.detailModel = pwdDetail;
            [weakSelf.tableView reloadData];
            weakSelf.passwordLabel.text = pwdDetail.password;
            weakSelf.timeLabel.text = [NSString stringWithFormat:@"申请于：%@",pwdDetail.apply_time];
        }
    }];
}


#pragma mark - tableView 代理

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.detailModel.doorsStatus.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"UITableViewCell" forIndexPath:indexPath];
    DoorDuOpenDoorDoorStatus * model = self.detailModel.doorsStatus[indexPath.row];
    cell.textLabel.textColor = [UIColor blackColor];
    cell.textLabel.text = model.door_name;
    return cell;
}

#pragma mark - 界面布局
- (void)_configUI
{
    [self.view addSubview:self.tableView];
    [self.tableView registerClass:UITableViewCell.class forCellReuseIdentifier:@"UITableViewCell"];
    [self.view addSubview:self.passwordLabel];
    [self.view addSubview:self.timeLabel];
    
    /** passwordLabel 布局 */
    //top
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.passwordLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.topLayoutGuide attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
    //左
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.passwordLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    //右
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.passwordLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
    //高
    [self.passwordLabel addConstraint:[NSLayoutConstraint constraintWithItem:self.passwordLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:120]];
    
    
    /** timeLabel 布局 */
    //top
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.timeLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.passwordLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
    //左
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.timeLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    //右
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.timeLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
    //高
    [self.timeLabel addConstraint:[NSLayoutConstraint constraintWithItem:self.timeLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:30]];
    
    /** tableView 布局 */
    //top
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.timeLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
    //左
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    //右
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
    //下面
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.bottomLayoutGuide attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
}

#pragma mark -懒加载
- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.translatesAutoresizingMaskIntoConstraints = NO;
        _tableView.backgroundColor = [UIColor colorWithRed:0.94 green:0.94 blue:0.96 alpha:1.00];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.tableFooterView = [[UIView alloc] init];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLineEtched;
        _tableView.rowHeight = UITableViewAutomaticDimension;
        _tableView.estimatedRowHeight = 60;
    }
    return _tableView;
}

/** 密码 */
- (UILabel *)passwordLabel
{
    if (!_passwordLabel) {
        _passwordLabel = [[UILabel alloc] init];
        _passwordLabel.translatesAutoresizingMaskIntoConstraints = NO;
        _passwordLabel.font = [UIFont systemFontOfSize:70];
        _passwordLabel.textAlignment = NSTextAlignmentCenter;
        _passwordLabel.textColor = [UIColor colorWithRed:0.49 green:0.74 blue:0.20 alpha:1.00];
    }
    return _passwordLabel;
}

/** 时间 */
- (UILabel *)timeLabel
{
    if (!_timeLabel) {
        _timeLabel = [[UILabel alloc] init];
        _timeLabel.translatesAutoresizingMaskIntoConstraints = NO;
        _timeLabel.font = [UIFont systemFontOfSize:18];
        _timeLabel.textAlignment = NSTextAlignmentCenter;
        _timeLabel.textColor = [UIColor colorWithRed:0.98 green:0.46 blue:0.47 alpha:1.00];
    }
    return _timeLabel;
}


- (void)dealloc
{
    NSLog(@"\ndealloc: %@\n",NSStringFromClass([self class]));
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
