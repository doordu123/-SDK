//
//  DDCallTransferViewController.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/30.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDCallTransferViewController.h"

@interface DDCallTransferViewController ()

/** 当前呼叫转接号码 */
@property (nonatomic, strong) UILabel * currentTransferNumberLabel;

/** 输入框 */
@property (nonatomic, strong) UITextField * inputTextField;

/** 修改按钮 */
@property (nonatomic, strong) UIButton * changeButton;

/** 信息描述用的 */
@property (nonatomic, strong) UILabel * desLabel;

@property (nonatomic, strong) DoorDuCallTransfer *transferNumberInfo;

@end

@implementation DDCallTransferViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if (@available(iOS 11.0, *)){
        [[UIScrollView appearance] setContentInsetAdjustmentBehavior:UIScrollViewContentInsetAdjustmentNever];
    } else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }

    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"呼叫转接";
//    [self _configUI];
    [self _requestCallTransferData];
    
}

#pragma mark - 呼叫转接设置请求
- (void)_requestCallTransferSetData
{
    if (self.inputTextField.text.length == 0) {
        return;
    }
    //nationCode 默认是 86
    [SVProgressHUD showWithStatus:@"呼叫转接设置中..."];
    __weak typeof(self) weakSelf = self;
    [DoorDuDataManager setUserTransferNumberWithRoomId:self.roomInfo.room_number_id mobile:self.inputTextField.text nationCode:@"" completion:^(BOOL isSuccess, DoorDuError *error) {
        [SVProgressHUD dismiss];
        if (error) {
            [DDProgressHUD showCenterWithText:error.message duration:1.5];
        } else {
            [DDProgressHUD showCenterWithText:@"设置呼叫转接成功" duration:1.5];
            [weakSelf.navigationController popViewControllerAnimated:YES];
        }
    }];
}
#pragma mark - 获取转接号码数据
- (void)_requestCallTransferData
{
    [SVProgressHUD showWithStatus:@"获取呼叫转接号请求中..."];
    __weak typeof(self) weakSelf = self;
    [DoorDuDataManager getUserTransferNumberWithRoomId:self.roomInfo.room_number_id completion:^(DoorDuCallTransfer *transferNumberInfo, DoorDuError *error) {
        [SVProgressHUD dismiss];
        if (error) {
            [DDProgressHUD showCenterWithText:error.message duration:1.5];
        } else {
            weakSelf.transferNumberInfo = transferNumberInfo;
            weakSelf.currentTransferNumberLabel.text = [NSString stringWithFormat:@"当前手机号码：%@ %@", transferNumberInfo.nation_code,transferNumberInfo.transfer_mobile];
            [weakSelf _configUI];
        }
    }];
}

#pragma mark - 界面布局
- (void)_configUI
{
    [self.view addSubview:self.currentTransferNumberLabel];
    /** 布局 currentTransferNumberLabel */
    //高
    [self.currentTransferNumberLabel addConstraint:[NSLayoutConstraint constraintWithItem:self.currentTransferNumberLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.currentTransferNumberLabel.font.lineHeight]];
    //上
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.currentTransferNumberLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.topLayoutGuide attribute:NSLayoutAttributeBottom multiplier:1 constant:15]];
    //左
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.currentTransferNumberLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.currentTransferNumberLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    
    [self.view addSubview:self.inputTextField];
    [self.view addSubview:self.changeButton];
    [self.view addSubview:self.desLabel];
    
#pragma mark - 注意   只有业主可以修改转接号码,判断有没有权限设置转接号码
    /**1：有权限 0：无权限 */
    if (self.transferNumberInfo.set_permission.integerValue == 0) {
        /** 只有业主可以修改转接号码 */
        return;
    }
    
    /** 布局 inputTextField */
    //高
    [self.inputTextField addConstraint:[NSLayoutConstraint constraintWithItem:self.inputTextField attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.inputTextField.font.lineHeight+6]];
    //上
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.inputTextField attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.currentTransferNumberLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:15]];
    //左
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.inputTextField attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.inputTextField attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];

    /** 布局 changeButton */
    //高
    [self.changeButton addConstraint:[NSLayoutConstraint constraintWithItem:self.changeButton attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:44]];
    //上
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.changeButton attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.inputTextField attribute:NSLayoutAttributeBottom multiplier:1 constant:15]];
    //左
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.changeButton attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.changeButton attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    
    /** 布局 desLabel */
    //高
    [self.desLabel addConstraint:[NSLayoutConstraint constraintWithItem:self.desLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.desLabel.font.lineHeight*3]];
    //上
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.desLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.changeButton attribute:NSLayoutAttributeBottom multiplier:1 constant:15]];
    //左
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.desLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.desLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];

    
}

#pragma mark - 懒加载
/** 当前呼叫转接号码 */
- (UILabel *)currentTransferNumberLabel
{
    if (!_currentTransferNumberLabel) {
        _currentTransferNumberLabel = [[UILabel alloc] init];
        _currentTransferNumberLabel.text = @"当前手机号码";
        _currentTransferNumberLabel.font = [UIFont systemFontOfSize:16];
        _currentTransferNumberLabel.textColor = [UIColor blackColor];
        _currentTransferNumberLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _currentTransferNumberLabel;
}
/** 输入框 */
- (UITextField *)inputTextField
{
    if (!_inputTextField) {
        _inputTextField = [[UITextField alloc] init];
        _inputTextField.placeholder = @"请输入手机号码";
        _inputTextField.keyboardType = UIKeyboardTypeNumberPad;
        _inputTextField.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _inputTextField;
}
/** 修改按钮 */
- (UIButton *)changeButton
{
    if (!_changeButton) {
        _changeButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _changeButton.translatesAutoresizingMaskIntoConstraints = NO;
        [_changeButton setTitle:@"确认修改" forState:UIControlStateNormal];
        [_changeButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _changeButton.backgroundColor = [UIColor colorWithRed:0.42 green:0.71 blue:0.11 alpha:1.00];
        _changeButton.layer.cornerRadius = 3;
        _changeButton.layer.masksToBounds = YES;
        [_changeButton addTarget:self action:@selector(_requestCallTransferSetData) forControlEvents:UIControlEventTouchUpInside];
    }
    return _changeButton;
}
/** 信息描述用的 */
- (UILabel *)desLabel
{
    if (!_desLabel) {
        _desLabel = [[UILabel alloc] init];
        _desLabel.numberOfLines = 3;
        _desLabel.font = [UIFont systemFontOfSize:13];
        _desLabel.textAlignment = NSTextAlignmentCenter;
        _desLabel.textColor = [UIColor lightGrayColor];
        _desLabel.translatesAutoresizingMaskIntoConstraints = NO;
        _desLabel.text = @"呼叫开门无处理时，自动转接至此电话号码。苛设置手机号或固定电话，例：0755-8888888";
    }
    return _desLabel;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}

- (void)dealloc
{
    NSLog(@"\ndealloc: %@\n",NSStringFromClass([self class]));
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
