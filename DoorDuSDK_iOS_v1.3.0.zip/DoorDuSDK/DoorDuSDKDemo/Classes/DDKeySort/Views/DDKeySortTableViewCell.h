//
//  DDKeySortTableViewCell.h
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/2/1.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DDKeySortTableViewCell : UITableViewCell

@property (nonatomic, strong) DoorDuKeyInfo * model;

@end
