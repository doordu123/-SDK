//
//  DDKeySortViewController.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/2/1.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDKeySortViewController.h"
#import "DDKeySortTableViewCell.h"
#import "DDChangeKeyNameViewController.h"

@interface DDKeySortViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) NSMutableArray * dataArray;

@property (nonatomic, strong) UITableView * tableView;

/** 编辑和完成button */
@property (nonatomic, strong) UIButton * editDoneButton;

@end

@implementation DDKeySortViewController

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.tableView reloadData];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if (@available(iOS 11.0, *)){
        [[UIScrollView appearance] setContentInsetAdjustmentBehavior:UIScrollViewContentInsetAdjustmentNever];
    } else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }
    
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"钥匙排序";
    UIBarButtonItem * rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:self.editDoneButton];
    self.navigationItem.rightBarButtonItem = rightBarButtonItem;
    
    [self _configUI];
    
    [self.dataArray addObjectsFromArray:self.keyList];
    
    [self.tableView reloadData];
}

#pragma mark - 完成和编辑按钮
- (void)_editDoneButtonClicked:(UIButton *)sender
{
    sender.selected = !sender.selected;
    [self.tableView setEditing:sender.selected animated:YES];
    if (!sender.selected) {
        [self _requestDoneSortKeyData];
    }
}

#pragma mark - 排序变更接口
- (void)_requestDoneSortKeyData
{
    if ([self _checkKeySortIsChnage]) {//排序有变更
        NSString * keySortString = @"";
        for (NSInteger  i = 0; i < self.dataArray.count; i++) {
            DoorDuKeyInfo * key = self.dataArray[i];
            if (i == self.dataArray.count - 1) {
                keySortString = [keySortString stringByAppendingFormat:@"%@",key.door_id];
            } else {
                keySortString =[keySortString stringByAppendingFormat:@"%@,",key.door_id];
            }
        }
        
        [SVProgressHUD showWithStatus:@"钥匙排序中..."];
        __weak typeof(self) weakSelf = self;
        [DoorDuDataManager setUserKeysSortWithRoomId:self.roomInfo.room_number_id doorIds:keySortString completion:^(BOOL isSuccess, DoorDuError *error) {
            [SVProgressHUD dismiss];
            __strong typeof(weakSelf) strongSelf = weakSelf;
            if (isSuccess) {
                NSArray * keyArray = self.dataArray.mutableCopy;
                strongSelf.keyList = [NSArray arrayWithArray:keyArray];
                if (strongSelf.returnDataBlock) {
                    strongSelf.returnDataBlock(strongSelf.keyList);
                }
            } else {
                [DDProgressHUD showCenterWithText:error.message duration:1.5];
            }
        }];
    }
    
}
#pragma mark - 检测钥匙顺序是否变更
- (BOOL)_checkKeySortIsChnage
{
    for (NSInteger  i = 0; i < self.keyList.count; i++) {
        DoorDuKeyInfo * key1 = self.keyList[i];
        DoorDuKeyInfo * key2 = self.dataArray[i];
        if (![key1.door_id isEqualToString:key2.door_id]) {
            return YES;
        }
    }
    return NO;
}
#pragma mark - tableView 代理
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    DDKeySortTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"DDKeySortTableViewCell" forIndexPath:indexPath];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    cell.model = self.dataArray[indexPath.row];
    //返回cell之前重新刷新约束，重新计算高度
    [cell setNeedsUpdateConstraints];
    [cell updateConstraintsIfNeeded];
    return cell;
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView
           editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    return UITableViewCellEditingStyleNone;
}

- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}

/** 移动完成的时候 */
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath *)destinationIndexPath {
    DoorDuKeyInfo * sourceinfo = self.dataArray[sourceIndexPath.row];
    
    [self.dataArray removeObjectAtIndex:sourceIndexPath.row];
    [self.dataArray insertObject:sourceinfo atIndex:destinationIndexPath.row];

}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (!self.tableView.editing) {//不是编辑的状态，改名字
        DDChangeKeyNameViewController * vc = [[DDChangeKeyNameViewController alloc] init];
        DoorDuKeyInfo * model = self.dataArray[indexPath.row];
        vc.model = self.dataArray[indexPath.row];
        __weak typeof(self) weakSelf = self;
        vc.returnDataBlock = ^{
            DoorDuKeyInfo * model1 = weakSelf.keyList[indexPath.row];
            model1.door_alias = model.door_alias;
        };
        [self.navigationController pushViewController:vc animated:YES];
    }
}


#pragma mark - 界面不去
- (void)_configUI
{
    [self.view addSubview:self.tableView];
    [self.tableView registerClass:DDKeySortTableViewCell.class forCellReuseIdentifier:@"DDKeySortTableViewCell"];
    
    /** 布局 tableView*/
    //上面top
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.topLayoutGuide attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
    //左边
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    //右边
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
    //底部
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.bottomLayoutGuide attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
    
}

#pragma mark - 懒加载
- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.backgroundColor = [UIColor colorWithRed:0.94 green:0.94 blue:0.96 alpha:1.00];
        _tableView.tableFooterView = [[UIView alloc]init];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        _tableView.translatesAutoresizingMaskIntoConstraints = NO;
        _tableView.rowHeight = UITableViewAutomaticDimension;
        _tableView.estimatedRowHeight = 60;
    }
    return _tableView;
}
/** 编辑和完成button */
- (UIButton *)editDoneButton
{
    if (!_editDoneButton) {
        _editDoneButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_editDoneButton setTitle:@"  编辑  " forState:UIControlStateNormal];
        [_editDoneButton setTitle:@"  完成  " forState:UIControlStateSelected];
        [_editDoneButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_editDoneButton sizeToFit];
        [_editDoneButton addTarget:self action:@selector(_editDoneButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _editDoneButton;
}

- (NSMutableArray *)dataArray
{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

- (void)dealloc
{
    NSLog(@"\ndealloc: %@\n",NSStringFromClass([self class]));
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
