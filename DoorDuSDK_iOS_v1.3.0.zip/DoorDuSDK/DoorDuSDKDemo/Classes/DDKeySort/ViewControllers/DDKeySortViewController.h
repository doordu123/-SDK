//
//  DDKeySortViewController.h
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/2/1.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DDKeySortViewController : UIViewController

// 钥匙数据
@property (nonatomic, strong) NSArray<DoorDuKeyInfo *> *keyList;

@property (nonatomic, strong) DoorDuRoomInfo *roomInfo;

/** 名字更改返回 */
@property (nonatomic, strong) void (^returnDataBlock)(NSArray<DoorDuKeyInfo *> *keyList);

@end
