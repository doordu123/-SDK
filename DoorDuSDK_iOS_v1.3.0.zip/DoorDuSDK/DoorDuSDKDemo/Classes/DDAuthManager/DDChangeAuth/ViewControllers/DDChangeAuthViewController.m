//
//  DDChangeAuthViewController.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/26.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDChangeAuthViewController.h"
#import "DDAddAuthNamePhoneTableViewCell.h"
#import "DDAddAuthIdentityTableViewCell.h"
#import "DDAddAuthTimeTableViewCell.h"
#import "DDDatePickerView.h"
#import "NSDate+DDTools.h"
#import <DoorDuSDK/DoorDuDataManager.h>
#import "DDAlertView.h"

@interface DDChangeAuthViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView * tableView;

/** 完成按钮 */
@property (nonatomic, strong) UIButton * changeButton;

/** 删除按钮 */
@property (nonatomic, strong) UIButton * deleteButton;

@property (nonatomic, strong) NSMutableArray * dataArray;

/** 授权身份类型 授权类型 1-家人 2-租客 3-临时客人，默认1 */
@property (nonatomic, assign) NSInteger authType;

@end

@implementation DDChangeAuthViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if (@available(iOS 11.0, *)){
        [[UIScrollView appearance] setContentInsetAdjustmentBehavior:UIScrollViewContentInsetAdjustmentNever];
    } else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }

    self.view.backgroundColor = [UIColor whiteColor];
    self.authType = 1;
    self.title = @"修改授权";
    [self _configUI];
    [self _makeLayoutModels];
    
}

#pragma mark - 点击事件
/** 修改点击 */
- (void)_changeButtonClicked
{
    NSString * nameString = @"";//姓名
    NSString * authTyeString = @"";//授权类型
    NSString * beginTimeString = @"";//开始时间
    NSString * endTimeString = @"";//结束时间
    
    /***  姓名  ***/
    NSArray * subArray = self.dataArray[0];
    //姓名
    DDAddAuthLayoutModel * model = subArray[0];
    nameString = model.contentString;

    /***  授权身份  ***/
    //授权身份
    authTyeString = [NSString stringWithFormat:@"%ld",self.authType];
    
    /***  授权时间 ***/
    subArray = self.dataArray[2];
    //开始时间
    model = subArray[0];
    beginTimeString = model.contentString;
    //结束时间
    model = subArray[1];
    endTimeString = model.contentString;
    
    //姓名
    if (nameString.length == 0) {
        [DDProgressHUD showCenterWithText:@"请输入姓名" duration:1.5];
        return;
    }
    __weak typeof(self) weakSelf = self;
    [SVProgressHUD showWithStatus:@"修改授权中..."];
    [DoorDuDataManager modifyAuthorizeWithName:nameString authUserId:self.model.auth_user_id roomId:self.roomInfo.room_number_id authType:authTyeString beginTime:beginTimeString endTime:endTimeString completion:^(BOOL isSuccess, DoorDuError *error) {
        [SVProgressHUD dismiss];
        if (isSuccess) {
            [DDProgressHUD showCenterWithText:@"修改授权成功" duration:1.5];
            [weakSelf.navigationController popViewControllerAnimated:YES];
        } else {
            [DDProgressHUD showCenterWithText:error.message duration:1.5];
        }
    }];
    
}
/** 删除授权 */
- (void)__deleteAuthClicked
{
    __weak typeof(self) weakSelf = self;
    [DDAlertView alertShowWithVC:self title:@"删除授权" message:@"确定删除？" otherButtonTitle:@[@"取消",@"确定"] clickedBlock:^(NSInteger index) {
        if (index == 1) {//删除授权
            [weakSelf _deleteAuthRequestData];
        }
    }];
}
#pragma mark - 删除授权请求
- (void)_deleteAuthRequestData
{
    __weak typeof(self) weakSelf = self;
    [SVProgressHUD showWithStatus:@"删除授权中..."];
    [DoorDuDataManager deleteAuthorizeWithAuthUserId:self.model.auth_user_id roomId:self.roomInfo.room_number_id completion:^(BOOL isSuccess, DoorDuError *error) {
        [SVProgressHUD dismiss];
        if (isSuccess) {
            [DDProgressHUD showCenterWithText:@"删除授权成功" duration:1.5];
            [weakSelf.navigationController popViewControllerAnimated:YES];
        } else {
            [DDProgressHUD showCenterWithText:error.message duration:1.5];
        }
    }];
}

/** 开始时间点击 */
- (void)_beginDateClickedAtIndexPath:(NSIndexPath *)indexPath
{
    NSArray * subArray = self.dataArray[indexPath.section];
    DDAddAuthLayoutModel * model = subArray[indexPath.row];
    __weak typeof(self) weakSelf = self;
    DDDatePickerView * pickerView = [DDDatePickerView datePickerMode:UIDatePickerModeDate dateReturnStringType:DDDatePickerReturnDateStringyyyyMMddState maximumDate:nil minimumDate:[NSDate date] defaultDate:model.date title:model.titleString returnDataBlock:^(NSString *dateString, NSDate *selectedDate) {
        model.contentString = dateString;
        model.date = selectedDate;
        DDAddAuthLayoutModel * model1 = subArray[indexPath.row+1];
        
        NSComparisonResult result = [model1.date compare:selectedDate];
        if (result == NSOrderedAscending || result == NSOrderedSame) {
            model1.date = [model.date returnAfterAFewYearsDateWithNumber:2];
            model1.contentString = [[model.date returnAfterAFewYearsDateWithNumber:2] returnDateStringWithDateFormat:@"yyyy-MM-dd"];
        }
        [weakSelf.tableView reloadData];
    }];
    [pickerView showFromView:self.navigationController.view];
}
/** 结束时间点击 */
- (void)_endDateClickedAtIndexPath:(NSIndexPath *)indexPath
{
    NSArray * subArray = self.dataArray[indexPath.section];
    DDAddAuthLayoutModel * model = subArray[indexPath.row];
    DDAddAuthLayoutModel * model1 = subArray[indexPath.row-1];
    __weak typeof(self) weakSelf = self;
    DDDatePickerView * pickerView = [DDDatePickerView datePickerMode:UIDatePickerModeDate dateReturnStringType:DDDatePickerReturnDateStringyyyyMMddState maximumDate:nil minimumDate:[model1.date returnAfterAFewDayDateWithNumber:1] defaultDate:model.date title:model.titleString returnDataBlock:^(NSString *dateString, NSDate *selectedDate) {
        model.contentString = dateString;
        model.date = selectedDate;
        [weakSelf.tableView reloadData];
    }];
    [pickerView showFromView:self.navigationController.view];
}


#pragma mark - tableView 代理

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.dataArray.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSArray * subArray = self.dataArray[section];
    return subArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return 15;
    }
    if (section == 1 || section == 2) {
        return 30;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSArray * subArray = self.dataArray[indexPath.section];
    DDAddAuthLayoutModel * model = subArray[indexPath.row];
    if (indexPath.section == 0) {
        DDAddAuthNamePhoneTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"DDAddAuthNamePhoneTableViewCell" forIndexPath:indexPath];
        cell.model = model;
        cell.inputTextField.enabled = YES;
        if (indexPath.row == 1) {
            cell.inputTextField.enabled = NO;
        }
        return cell;
    }
    if (indexPath.section == 1) {
        DDAddAuthIdentityTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"DDAddAuthIdentityTableViewCell" forIndexPath:indexPath];
        cell.model = model;
        cell.accessoryType = UITableViewCellAccessoryNone;
        if (indexPath.row == self.authType - 1) {
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
        }
        return cell;
    }
    if (indexPath.section == 2) {
        DDAddAuthTimeTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"DDAddAuthTimeTableViewCell" forIndexPath:indexPath];
        cell.model = model;
        return cell;
    }
    return nil;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [self.view endEditing:YES];
    /** 授权身份类型 */
    if (indexPath.section == 1) {
        self.authType = indexPath.row + 1;
        [self.tableView reloadData];
    }
    if (indexPath.section == 2) {
        if (indexPath.row == 0) {
            [self _beginDateClickedAtIndexPath:indexPath];
        }
        if (indexPath.row == 1) {
            [self _endDateClickedAtIndexPath:indexPath];
        }
    }
}


#pragma mark - 制造UI列表数据
- (void)_makeLayoutModels
{
    [self.dataArray removeAllObjects];
    /** 姓名和手机号 */
    DDAddAuthLayoutModel * model1 = [[DDAddAuthLayoutModel alloc] init];
    model1.titleString = @"姓名";
    model1.placeholderString = @"请输入姓名...";
    model1.contentString = self.model.auth_user_name;
    DDAddAuthLayoutModel * model2 = [[DDAddAuthLayoutModel alloc] init];
    model2.titleString = @"+86";
    model2.placeholderString = @"请输入手机号...";
    model2.contentString = self.model.auth_user_mobile;
    [self.dataArray addObject:@[model1,model2]];
    /** 授权身份 */
    DDAddAuthLayoutModel * model3 = [[DDAddAuthLayoutModel alloc] init];
    model3.titleString = @"家人";
    DDAddAuthLayoutModel * model4 = [[DDAddAuthLayoutModel alloc] init];
    model4.titleString = @"租客";
    DDAddAuthLayoutModel * model5 = [[DDAddAuthLayoutModel alloc] init];
    model5.titleString = @"临时客人";
    self.authType = self.model.auth_type.integerValue;
    
    [self.dataArray addObject:@[model3,model4,model5]];
    /** 时间 */
    DDAddAuthLayoutModel * model6 = [[DDAddAuthLayoutModel alloc] init];
    model6.titleString = @"开始时间";
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    
    model6.contentString = self.model.begin_time;
    
    model6.date = [dateFormatter dateFromString:self.model.begin_time];;

    
    DDAddAuthLayoutModel * model7 = [[DDAddAuthLayoutModel alloc] init];
    model7.titleString = @"结束时间";
    model7.date = [[NSDate date] returnAfterAFewYearsDateWithNumber:2];
    model7.contentString = self.model.end_time;
    model7.date = [dateFormatter dateFromString:self.model.end_time];;
    
    [self.dataArray addObject:@[model6,model7]];
    [self.tableView reloadData];
}

#pragma mark - 界面不去
- (void)_configUI
{
    [self.view addSubview:self.tableView];
    [self.tableView registerClass:DDAddAuthNamePhoneTableViewCell.class forCellReuseIdentifier:@"DDAddAuthNamePhoneTableViewCell"];
    [self.tableView registerClass:DDAddAuthIdentityTableViewCell.class forCellReuseIdentifier:@"DDAddAuthIdentityTableViewCell"];
    [self.tableView registerClass:DDAddAuthTimeTableViewCell.class forCellReuseIdentifier:@"DDAddAuthTimeTableViewCell"];
    [self.view addSubview:self.changeButton];
    [self.view addSubview:self.deleteButton];
    
    /** 布局changeButton */
    //左
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.changeButton attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.changeButton attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1 constant:-15]];
    //高
    [self.changeButton addConstraint:[NSLayoutConstraint constraintWithItem:self.changeButton attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:40]];
    //下
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.changeButton attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeBottom multiplier:1 constant:-15]];
    
    
    /** 布局deleteButton */
    //左
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.deleteButton attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.changeButton attribute:NSLayoutAttributeRight multiplier:1 constant:15]];
    //右
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.deleteButton attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    //高
    [self.deleteButton addConstraint:[NSLayoutConstraint constraintWithItem:self.deleteButton attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:40]];
    //下
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.deleteButton attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeBottom multiplier:1 constant:-15]];

    
    /** 布局 tableView*/
    //上面top
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.topLayoutGuide attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
    //左边
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    //右边
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
    //底部
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.changeButton attribute:NSLayoutAttributeTop multiplier:1 constant:-10]];
    
}


#pragma mark - 懒加载
- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.backgroundColor = [UIColor colorWithRed:0.94 green:0.94 blue:0.96 alpha:1.00];
        _tableView.tableFooterView = [[UIView alloc]init];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.translatesAutoresizingMaskIntoConstraints = NO;
        _tableView.rowHeight = UITableViewAutomaticDimension;
        _tableView.estimatedRowHeight = 60;
    }
    return _tableView;
}
/** 修改按钮 */
- (UIButton *)changeButton
{
    if (!_changeButton) {
        _changeButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_changeButton setTitle:@"修改" forState:UIControlStateNormal];
        [_changeButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _changeButton.translatesAutoresizingMaskIntoConstraints = NO;
        _changeButton.backgroundColor = [UIColor colorWithRed:0.42 green:0.71 blue:0.11 alpha:1.00];
        [_changeButton addTarget:self action:@selector(_changeButtonClicked) forControlEvents:UIControlEventTouchUpInside];
        _changeButton.layer.masksToBounds = YES;
        _changeButton.layer.cornerRadius = 3;
    }
    return _changeButton;
}
/** 删除按钮 */
- (UIButton *)deleteButton
{
    if (!_deleteButton) {
        _deleteButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_deleteButton setTitle:@"删除" forState:UIControlStateNormal];
        [_deleteButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _deleteButton.translatesAutoresizingMaskIntoConstraints = NO;
        _deleteButton.backgroundColor = [UIColor colorWithRed:0.98 green:0.46 blue:0.47 alpha:1.00];
        [_deleteButton addTarget:self action:@selector(__deleteAuthClicked) forControlEvents:UIControlEventTouchUpInside];
        _deleteButton.layer.masksToBounds = YES;
        _deleteButton.layer.cornerRadius = 3;
    }
    return _deleteButton;
}

- (NSMutableArray *)dataArray
{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

- (void)dealloc
{
    NSLog(@"\ndealloc: %@\n",NSStringFromClass([self class]));
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
