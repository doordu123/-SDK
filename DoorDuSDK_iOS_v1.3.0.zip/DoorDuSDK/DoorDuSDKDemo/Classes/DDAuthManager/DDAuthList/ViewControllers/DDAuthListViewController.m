//
//  DDAuthListViewController.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/25.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDAuthListViewController.h"
#import "DDAuthListTableViewCell.h"
#import "DDAddAuthViewController.h"
#import "DDChangeAuthViewController.h"

@interface DDAuthListViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) NSMutableArray * dataArray;

@property (nonatomic, strong) UITableView * tableView;

@property (nonatomic, strong) UIView * bottomContentView;

/** 授权信息 */
@property (nonatomic, strong) UILabel * authInfoLabel;

@end

@implementation DDAuthListViewController

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self _requestAuthListData];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if (@available(iOS 11.0, *)){
        [[UIScrollView appearance] setContentInsetAdjustmentBehavior:UIScrollViewContentInsetAdjustmentNever];
    } else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }
    self.view.backgroundColor = [UIColor colorWithRed:0.94 green:0.94 blue:0.96 alpha:1.00];
    [self _configUI];
    
    
}

#pragma mark - 添加授权点击事件
- (void)_addAuthButtonClicked
{
    DDAddAuthViewController * vc = [[DDAddAuthViewController alloc] init];
    vc.roomInfo = self.roomInfo;
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - 请求授权记录
- (void)_requestAuthListData
{
    /** 可以分页，这里就不写了 */
    __weak typeof(self) weakSelf = self;
    [DoorDuDataManager getAuthorizeListWithRoomId:self.roomInfo.room_number_id startPage:nil pageSize:nil completion:^(DoorDuAuthorizeListInfo *authList, DoorDuError *error) {
        [weakSelf.dataArray removeAllObjects];
        [weakSelf.dataArray addObjectsFromArray:authList.authList];
        [self _refreshAuthInfoLabelUI:authList.upper_limit auth_list_number:authList.auth_list_number];
    }];
}
/** upper_limit 授权人数上限,0无限制,-1不能授权，大于0就是限制人数 */
/** auth_list_number 已授权列表总人数 */
- (void)_refreshAuthInfoLabelUI:(NSString *)upper_limit auth_list_number:(NSString *)auth_list_number
{
    if (upper_limit.integerValue == 0) {//不限制
        self.authInfoLabel.text = [NSString stringWithFormat:@"您已授权：%@ 人",auth_list_number];
    }
    if (upper_limit.integerValue == -1) {
        self.authInfoLabel.text = [NSString stringWithFormat:@"您无权限授权，如需要授权权限请联系物业管理处"];
    }
    if (upper_limit.integerValue > 0) {//可以授权多少人
        self.authInfoLabel.text = [NSString stringWithFormat:@"您可以授权%@，已授权：%@ 人，如需增加请联系物业管理处",upper_limit,auth_list_number];
    }
    [self.tableView reloadData];
}

#pragma mark - tableView 代理
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    DDAuthListTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"DDAuthListTableViewCell" forIndexPath:indexPath];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.model = self.dataArray[indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    DDChangeAuthViewController * vc = [[DDChangeAuthViewController alloc] init];
    vc.roomInfo = self.roomInfo;
    vc.model = self.dataArray[indexPath.row];
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - 界面不去
- (void)_configUI
{
    [self.view addSubview:self.tableView];
    [self.tableView registerClass:DDAuthListTableViewCell.class forCellReuseIdentifier:@"DDAuthListTableViewCell"];
    [self.view addSubview:self.bottomContentView];
    /**  bottomContentView添加子view */
    [self _configBottomContentView];

    /** 布局 tableView*/
    //上面top
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.topLayoutGuide attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
    //左边
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    //右边
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
    
    //底部
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.bottomContentView attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
    /** 布局 bottomContentView*/
    //左边
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.bottomContentView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    //右边
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.bottomContentView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
    //底部
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.bottomContentView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.bottomLayoutGuide attribute:NSLayoutAttributeTop multiplier:1 constant:0]];

    
}
/** bottomContentView添加子view */
- (void)_configBottomContentView
{
    UIButton * addAuthButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [addAuthButton setTitle:@"添加授权" forState:UIControlStateNormal];
    [addAuthButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    addAuthButton.translatesAutoresizingMaskIntoConstraints = NO;
    addAuthButton.backgroundColor = [UIColor colorWithRed:0.42 green:0.71 blue:0.11 alpha:1.00];
    [addAuthButton addTarget:self action:@selector(_addAuthButtonClicked) forControlEvents:UIControlEventTouchUpInside];
    addAuthButton.layer.masksToBounds = YES;
    addAuthButton.layer.cornerRadius = 3;
    //添加子空间
    [self.bottomContentView addSubview:addAuthButton];
    [self.bottomContentView addSubview:self.authInfoLabel];
    
    /** 布局addAuthButton */
    //上
    [self.bottomContentView addConstraint:[NSLayoutConstraint constraintWithItem:addAuthButton attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.bottomContentView attribute:NSLayoutAttributeTop multiplier:1 constant:15]];
    //左
    [self.bottomContentView addConstraint:[NSLayoutConstraint constraintWithItem:addAuthButton attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.bottomContentView attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.bottomContentView addConstraint:[NSLayoutConstraint constraintWithItem:addAuthButton attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.bottomContentView attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    //高
    [addAuthButton addConstraint:[NSLayoutConstraint constraintWithItem:addAuthButton attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:40]];

    /** 布局authInfoLabel */
    //上
    [self.bottomContentView addConstraint:[NSLayoutConstraint constraintWithItem:self.authInfoLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:addAuthButton attribute:NSLayoutAttributeBottom multiplier:1 constant:15]];
    //左
    [self.bottomContentView addConstraint:[NSLayoutConstraint constraintWithItem:self.authInfoLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.bottomContentView attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.bottomContentView addConstraint:[NSLayoutConstraint constraintWithItem:self.authInfoLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.bottomContentView attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    //高
    [self.authInfoLabel addConstraint:[NSLayoutConstraint constraintWithItem:self.authInfoLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.authInfoLabel.font.lineHeight*2]];
    
    //下
    [self.bottomContentView addConstraint:[NSLayoutConstraint constraintWithItem:self.authInfoLabel attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.bottomContentView attribute:NSLayoutAttributeBottom multiplier:1 constant:-15]];

}

#pragma mark - 懒加载
- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.backgroundColor = [UIColor colorWithRed:0.94 green:0.94 blue:0.96 alpha:1.00];
        _tableView.tableFooterView = [[UIView alloc]init];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.translatesAutoresizingMaskIntoConstraints = NO;
        _tableView.rowHeight = UITableViewAutomaticDimension;
        _tableView.estimatedRowHeight = 60;
    }
    return _tableView;
}

- (UIView *)bottomContentView
{
    if (!_bottomContentView) {
        _bottomContentView = [[UIView alloc] init];
        _bottomContentView.translatesAutoresizingMaskIntoConstraints = NO;
        _bottomContentView.backgroundColor = [[UIColor lightGrayColor]colorWithAlphaComponent:0.3];
    }
    return _bottomContentView;
}
/** 授权信息 */
- (UILabel *)authInfoLabel
{
    if (!_authInfoLabel) {
        _authInfoLabel = [[UILabel alloc] init];
        _authInfoLabel.text = @"授权人数";
        _authInfoLabel.translatesAutoresizingMaskIntoConstraints = NO;
        _authInfoLabel.font = [UIFont systemFontOfSize:13];
        _authInfoLabel.textColor = [UIColor blackColor];
        _authInfoLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _authInfoLabel;
}

- (NSMutableArray *)dataArray
{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

- (void)dealloc
{
    NSLog(@"\ndealloc: %@\n",NSStringFromClass([self class]));
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
