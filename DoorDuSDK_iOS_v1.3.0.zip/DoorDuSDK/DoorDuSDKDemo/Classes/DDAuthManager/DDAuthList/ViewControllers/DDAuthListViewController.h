//
//  DDAuthListViewController.h
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/25.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import <UIKit/UIKit.h>

/** 授权列表 */
@interface DDAuthListViewController : UIViewController

@property (nonatomic, strong) DoorDuRoomInfo *roomInfo;

@end
