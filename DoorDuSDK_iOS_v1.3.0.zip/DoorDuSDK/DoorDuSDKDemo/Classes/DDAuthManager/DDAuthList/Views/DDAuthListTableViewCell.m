//
//  DDAuthListTableViewCell.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/25.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDAuthListTableViewCell.h"

@interface DDAuthListTableViewCell ()

/** 姓名 */
@property (nonatomic, strong) UILabel * nameLabel;

/** 授权类型 */
@property (nonatomic, strong) UILabel * authTypeLabel;

/** 授权时间 */
@property (nonatomic, strong) UILabel * authTimeLabel;

@end

@implementation DDAuthListTableViewCell


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self _configUI];
    }
    return self;
}

- (void)setModel:(DoorDuAuthorizeInfo *)model
{
    _model = model;
    self.nameLabel.text = model.auth_user_name;
    self.authTypeLabel.text = model.auth_type_info;
    self.authTimeLabel.text = [NSString stringWithFormat:@"%@-%@",model.begin_time,model.end_time];
}

#pragma mark - 界面布局
- (void)_configUI
{    
    self.backgroundColor = [UIColor whiteColor];
    self.contentView.backgroundColor = [UIColor whiteColor];
    [self.contentView addSubview:self.nameLabel];
    [self.contentView addSubview:self.authTypeLabel];
    [self.contentView addSubview:self.authTimeLabel];
    UIView * bottomLineView = [[UIView alloc] init];
    bottomLineView.translatesAutoresizingMaskIntoConstraints = NO;
    bottomLineView.backgroundColor = [[UIColor blackColor]colorWithAlphaComponent:0.2];
    
    [self.contentView addSubview:bottomLineView];
    
    /** 布局 nameLabel */
    //高度
    [self.nameLabel addConstraint:[NSLayoutConstraint constraintWithItem:self.nameLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.nameLabel.font.lineHeight]];
    //上
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.nameLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeTop multiplier:1 constant:15]];
    //左
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.nameLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.nameLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];

    
    /** 布局 authTypeLabel */
    //高度
    [self.authTypeLabel addConstraint:[NSLayoutConstraint constraintWithItem:self.authTypeLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.authTypeLabel.font.lineHeight]];
    //上
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.authTypeLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.nameLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:10]];
    //左
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.authTypeLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.authTypeLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];

    /** 布局 authTimeLabel */
    //高度
    [self.authTimeLabel addConstraint:[NSLayoutConstraint constraintWithItem:self.authTimeLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.authTimeLabel.font.lineHeight]];
    //上
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.authTimeLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.authTypeLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:10]];
    //左
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.authTimeLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.authTimeLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];

    /** 布局bottomLineView */
    //高度
    [bottomLineView addConstraint:[NSLayoutConstraint constraintWithItem:bottomLineView attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:0.5]];
    //上
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:bottomLineView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.authTimeLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:15]];
    //左
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:bottomLineView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    //右
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:bottomLineView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeRight multiplier:1 constant:50]];

    //下
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:bottomLineView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];

}

#pragma mark - 懒加载
/** 姓名 */
- (UILabel *)nameLabel
{
    if (!_nameLabel) {
        _nameLabel = [[UILabel alloc] init];
        _nameLabel.textColor = [UIColor blackColor];
        _nameLabel.font = [UIFont systemFontOfSize:16];
        _nameLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _nameLabel;
}

/** 授权类型 */
- (UILabel *)authTypeLabel
{
    if (!_authTypeLabel) {
        _authTypeLabel = [[UILabel alloc] init];
        _authTypeLabel.textColor = [UIColor blackColor];
        _authTypeLabel.font = [UIFont systemFontOfSize:13];
        _authTypeLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _authTypeLabel;
}

/** 授权时间 */
- (UILabel *)authTimeLabel
{
    if (!_authTimeLabel) {
        _authTimeLabel = [[UILabel alloc] init];
        _authTimeLabel.textColor = [UIColor blackColor];
        _authTimeLabel.font = [UIFont systemFontOfSize:13];
        _authTimeLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _authTimeLabel;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
