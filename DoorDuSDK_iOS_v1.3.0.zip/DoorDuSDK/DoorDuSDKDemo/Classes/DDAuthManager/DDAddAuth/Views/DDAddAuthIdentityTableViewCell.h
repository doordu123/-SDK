//
//  DDAddAuthIdentityTableViewCell.h
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/25.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DDAddAuthLayoutModel.h"

/** 授权身份 */
@interface DDAddAuthIdentityTableViewCell : UITableViewCell

@property (nonatomic, strong) DDAddAuthLayoutModel * model;


@end
