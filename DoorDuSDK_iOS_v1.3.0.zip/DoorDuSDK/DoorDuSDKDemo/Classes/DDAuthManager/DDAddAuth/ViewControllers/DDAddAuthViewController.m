//
//  DDAddAuthViewController.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/25.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDAddAuthViewController.h"
#import "DDAddAuthNamePhoneTableViewCell.h"
#import "DDAddAuthIdentityTableViewCell.h"
#import "DDAddAuthTimeTableViewCell.h"
#import "DDDatePickerView.h"
#import "NSDate+DDTools.h"
#import <DoorDuSDK/DoorDuDataManager.h>

@interface DDAddAuthViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView * tableView;

/** 完成按钮 */
@property (nonatomic, strong) UIButton * completeButton;

@property (nonatomic, strong) NSMutableArray * dataArray;

/** 授权身份类型 授权类型 1-家人 2-租客 3-临时客人，默认1 */
@property (nonatomic, assign) NSInteger authType;

@end

@implementation DDAddAuthViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if (@available(iOS 11.0, *)){
        [[UIScrollView appearance] setContentInsetAdjustmentBehavior:UIScrollViewContentInsetAdjustmentNever];
    } else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }

    self.view.backgroundColor = [UIColor whiteColor];
    self.authType = 1;
    self.title = @"添加授权";
    [self _configUI];
    [self _makeLayoutModels];
    
}

#pragma mark - 点击事件
/** 完成点击 */
- (void)_completeButtonClicked
{
    NSString * nationCodeString = @"86";//国家码，默认86
    NSString * nameString = @"";//姓名
    NSString * phoneString = @"";//手机号
    NSString * authTyeString = @"";//授权类型
    NSString * beginTimeString = @"";//开始时间
    NSString * endTimeString = @"";//结束时间
    
    /***  姓名 和 手机号  ***/
    NSArray * subArray = self.dataArray[0];
    //姓名
    DDAddAuthLayoutModel * model = subArray[0];
    nameString = model.contentString;
    //手机号
    model = subArray[1];
    phoneString = model.contentString;
    /***  授权身份  ***/
    //授权身份
    authTyeString = [NSString stringWithFormat:@"%ld",self.authType];
    
    /***  授权时间 ***/
    subArray = self.dataArray[2];
    //开始时间
    model = subArray[0];
    beginTimeString = model.contentString;
    //结束时间
    model = subArray[1];
    endTimeString = model.contentString;
    
    //姓名
    if (nameString.length == 0) {
        [DDProgressHUD showCenterWithText:@"请输入姓名" duration:1.5];
        return;
    }
    //手机号
    if (phoneString.length == 0) {
        [DDProgressHUD showCenterWithText:@"请输入手机号" duration:1.5];
        return;
    }
    __weak typeof(self) weakSelf = self;
    [SVProgressHUD showWithStatus:@"添加授权中..."];
    [DoorDuDataManager addAuthorizeWithNationCode:nationCodeString name:nameString authMobile:phoneString roomId:self.roomInfo.room_number_id authType:authTyeString beginTime:beginTimeString endTime:endTimeString completion:^(BOOL isSuccess, DoorDuError *error) {
        [SVProgressHUD dismiss];
        if (isSuccess) {
            [DDProgressHUD showCenterWithText:@"授权成功" duration:1.5];
            [weakSelf _makeLayoutModels];
        } else {
            [DDProgressHUD showCenterWithText:error.message duration:1.5];
        }
    }];
    
}
/** 开始时间点击 */
- (void)_beginDateClickedAtIndexPath:(NSIndexPath *)indexPath
{
    NSArray * subArray = self.dataArray[indexPath.section];
    DDAddAuthLayoutModel * model = subArray[indexPath.row];
    __weak typeof(self) weakSelf = self;
    DDDatePickerView * pickerView = [DDDatePickerView datePickerMode:UIDatePickerModeDate dateReturnStringType:DDDatePickerReturnDateStringyyyyMMddState maximumDate:nil minimumDate:[NSDate date] defaultDate:model.date title:model.titleString returnDataBlock:^(NSString *dateString, NSDate *selectedDate) {
        model.contentString = dateString;
        model.date = selectedDate;
        DDAddAuthLayoutModel * model1 = subArray[indexPath.row+1];
        
        NSComparisonResult result = [model1.date compare:selectedDate];
        if (result == NSOrderedAscending || result == NSOrderedSame) {
            model1.date = [model.date returnAfterAFewYearsDateWithNumber:2];
            model1.contentString = [[model.date returnAfterAFewYearsDateWithNumber:2] returnDateStringWithDateFormat:@"yyyy-MM-dd"];
        }
        [weakSelf.tableView reloadData];
    }];
    [pickerView showFromView:self.navigationController.view];
}
/** 结束时间点击 */
- (void)_endDateClickedAtIndexPath:(NSIndexPath *)indexPath
{
    NSArray * subArray = self.dataArray[indexPath.section];
    DDAddAuthLayoutModel * model = subArray[indexPath.row];
    DDAddAuthLayoutModel * model1 = subArray[indexPath.row-1];
    __weak typeof(self) weakSelf = self;
    DDDatePickerView * pickerView = [DDDatePickerView datePickerMode:UIDatePickerModeDate dateReturnStringType:DDDatePickerReturnDateStringyyyyMMddState maximumDate:nil minimumDate:[model1.date returnAfterAFewDayDateWithNumber:1] defaultDate:model.date title:model.titleString returnDataBlock:^(NSString *dateString, NSDate *selectedDate) {
        model.contentString = dateString;
        model.date = selectedDate;
        [weakSelf.tableView reloadData];
    }];
    [pickerView showFromView:self.navigationController.view];
}


#pragma mark - tableView 代理

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.dataArray.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSArray * subArray = self.dataArray[section];
    return subArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return 15;
    }
    if (section == 1 || section == 2) {
        return 30;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSArray * subArray = self.dataArray[indexPath.section];
    DDAddAuthLayoutModel * model = subArray[indexPath.row];
    if (indexPath.section == 0) {
        DDAddAuthNamePhoneTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"DDAddAuthNamePhoneTableViewCell" forIndexPath:indexPath];
        cell.model = model;
        return cell;
    }
    if (indexPath.section == 1) {
        DDAddAuthIdentityTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"DDAddAuthIdentityTableViewCell" forIndexPath:indexPath];
        cell.model = model;
        cell.accessoryType = UITableViewCellAccessoryNone;
        if (indexPath.row == self.authType - 1) {
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
        }
        return cell;
    }
    if (indexPath.section == 2) {
        DDAddAuthTimeTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"DDAddAuthTimeTableViewCell" forIndexPath:indexPath];
        cell.model = model;
        return cell;
    }
    return nil;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [self.view endEditing:YES];
    /** 授权身份类型 */
    if (indexPath.section == 1) {
        self.authType = indexPath.row + 1;
        [self.tableView reloadData];
    }
    if (indexPath.section == 2) {
        if (indexPath.row == 0) {
            [self _beginDateClickedAtIndexPath:indexPath];
        }
        if (indexPath.row == 1) {
            [self _endDateClickedAtIndexPath:indexPath];
        }
    }
}


#pragma mark - 制造UI列表数据
- (void)_makeLayoutModels
{
    [self.dataArray removeAllObjects];
    /** 姓名和手机号 */
    DDAddAuthLayoutModel * model1 = [[DDAddAuthLayoutModel alloc] init];
    model1.titleString = @"姓名";
    model1.placeholderString = @"请输入姓名...";
    DDAddAuthLayoutModel * model2 = [[DDAddAuthLayoutModel alloc] init];
    model2.titleString = @"+86";
    model2.placeholderString = @"请输入手机号...";
    [self.dataArray addObject:@[model1,model2]];
    /** 授权身份 */
    DDAddAuthLayoutModel * model3 = [[DDAddAuthLayoutModel alloc] init];
    model3.titleString = @"家人";
    DDAddAuthLayoutModel * model4 = [[DDAddAuthLayoutModel alloc] init];
    model4.titleString = @"租客";
    DDAddAuthLayoutModel * model5 = [[DDAddAuthLayoutModel alloc] init];
    model5.titleString = @"临时客人";
    [self.dataArray addObject:@[model3,model4,model5]];
    /** 时间 */
    DDAddAuthLayoutModel * model6 = [[DDAddAuthLayoutModel alloc] init];
    model6.titleString = @"开始时间";
    model6.date = [NSDate date];
    model6.contentString = [[NSDate date] returnDateStringWithDateFormat:@"yyyy-MM-dd"];
    DDAddAuthLayoutModel * model7 = [[DDAddAuthLayoutModel alloc] init];
    model7.titleString = @"结束时间";
    model7.date = [[NSDate date] returnAfterAFewYearsDateWithNumber:2];
    model7.contentString = [[[NSDate date] returnAfterAFewYearsDateWithNumber:2] returnDateStringWithDateFormat:@"yyyy-MM-dd"];
    [self.dataArray addObject:@[model6,model7]];
    [self.tableView reloadData];
}

#pragma mark - 界面不去
- (void)_configUI
{
    [self.view addSubview:self.tableView];
    [self.tableView registerClass:DDAddAuthNamePhoneTableViewCell.class forCellReuseIdentifier:@"DDAddAuthNamePhoneTableViewCell"];
    [self.tableView registerClass:DDAddAuthIdentityTableViewCell.class forCellReuseIdentifier:@"DDAddAuthIdentityTableViewCell"];
    [self.tableView registerClass:DDAddAuthTimeTableViewCell.class forCellReuseIdentifier:@"DDAddAuthTimeTableViewCell"];
    [self.view addSubview:self.completeButton];
    
    /** 布局completeButton */
    //左
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.completeButton attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.completeButton attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    //高
    [self.completeButton addConstraint:[NSLayoutConstraint constraintWithItem:self.completeButton attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:40]];
    //下
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.completeButton attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeBottom multiplier:1 constant:-15]];

    
    /** 布局 tableView*/
    //上面top
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.topLayoutGuide attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
    //左边
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    //右边
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
    //底部
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.completeButton attribute:NSLayoutAttributeTop multiplier:1 constant:-10]];
    
}


#pragma mark - 懒加载
- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.backgroundColor = [UIColor colorWithRed:0.94 green:0.94 blue:0.96 alpha:1.00];
        _tableView.tableFooterView = [[UIView alloc]init];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.translatesAutoresizingMaskIntoConstraints = NO;
        _tableView.rowHeight = UITableViewAutomaticDimension;
        _tableView.estimatedRowHeight = 60;
    }
    return _tableView;
}
/** 完成按钮 */
- (UIButton *)completeButton
{
    if (!_completeButton) {
        _completeButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_completeButton setTitle:@"完成" forState:UIControlStateNormal];
        [_completeButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _completeButton.translatesAutoresizingMaskIntoConstraints = NO;
        _completeButton.backgroundColor = [UIColor colorWithRed:0.42 green:0.71 blue:0.11 alpha:1.00];
        [_completeButton addTarget:self action:@selector(_completeButtonClicked) forControlEvents:UIControlEventTouchUpInside];
        _completeButton.layer.masksToBounds = YES;
        _completeButton.layer.cornerRadius = 3;
    }
    return _completeButton;
}
- (NSMutableArray *)dataArray
{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

- (void)dealloc
{
    NSLog(@"\ndealloc: %@\n",NSStringFromClass([self class]));
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
