//
//  DDEntityCardViewController.h
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/26.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DDEntityCardViewController : UIViewController

@property (nonatomic, strong) DoorDuRoomInfo *roomInfo;

@end
