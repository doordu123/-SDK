//
//  DDEntityCardTableViewCell.h
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/26.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DDEntityCardTableViewCell : UITableViewCell

@property (nonatomic, strong) DoorDuEntityCardInfo * model;

@end
