//
//  DDEntityCardTableViewCell.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/26.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDEntityCardTableViewCell.h"

@interface DDEntityCardTableViewCell ()

/** dep */
@property (nonatomic, strong) UILabel * depLabel;

/** 名字 */
@property (nonatomic, strong) UILabel * nameLabel;

/** 时间 */
@property (nonatomic, strong) UILabel * timeLabel;

/** 卡 */
@property (nonatomic, strong) UILabel * cardDesLabel;

/** 是否有效 */
@property (nonatomic, strong) UILabel * validLabel;

@end


@implementation DDEntityCardTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self _configUI];
    }
    return self;
}

- (void)setModel:(DoorDuEntityCardInfo *)model
{
    _model = model;
    self.depLabel.text = model.dep_name;
    self.nameLabel.text = model.owner_name;
    self.timeLabel.text = [NSString stringWithFormat:@"授权开始时间：%@，授权结束时间：%@",model.start_time,model.end_time];
    self.cardDesLabel.text = [NSString stringWithFormat:@"备注：%@，卡号：%@",model.remark,model.card_number];
    self.validLabel.text = model.status_info;
}


#pragma mark - 界面布局
- (void)_configUI
{
    self.depLabel.text = @"栋";
    self.nameLabel.text = @"拥有者姓名";
    self.timeLabel.text = [NSString stringWithFormat:@"授权开始时间：2018-01-01，授权结束时间：2019-03-03"];
    self.cardDesLabel.text = [NSString stringWithFormat:@"备注：身份证，卡号：34234354353"];
    self.validLabel.text = @"有效";

    [self.contentView addSubview:self.depLabel];
    [self.contentView addSubview:self.nameLabel];
    [self.contentView addSubview:self.timeLabel];
    [self.contentView addSubview:self.cardDesLabel];
    [self.contentView addSubview:self.validLabel];
    
    /** 布局 depLabel */
    //高
    [self.depLabel addConstraint:[NSLayoutConstraint constraintWithItem:self.depLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.depLabel.font.lineHeight]];
    //左
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.depLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.depLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    //上
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.depLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeTop multiplier:1 constant:15]];
    
    /** 布局 nameLabel */
    //高
    [self.nameLabel addConstraint:[NSLayoutConstraint constraintWithItem:self.nameLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.nameLabel.font.lineHeight]];
    //上
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.nameLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.depLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:10]];
    //左
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.nameLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.nameLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    
    /** 布局 timeLabel */
    //高
    [self.timeLabel addConstraint:[NSLayoutConstraint constraintWithItem:self.timeLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.timeLabel.font.lineHeight]];
    //左
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.timeLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.timeLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    //上
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.timeLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.nameLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:10]];

    /** 布局 cardDesLabel */
    //高
    [self.cardDesLabel addConstraint:[NSLayoutConstraint constraintWithItem:self.cardDesLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.cardDesLabel.font.lineHeight]];
    //左
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.cardDesLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.cardDesLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    //上
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.cardDesLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.timeLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:10]];
    
    /** 布局 validLabel */
    //高
    [self.validLabel addConstraint:[NSLayoutConstraint constraintWithItem:self.validLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.validLabel.font.lineHeight]];
    //左
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.validLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.validLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    //上
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.validLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.cardDesLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:10]];
    //下
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.validLabel attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeBottom multiplier:1 constant:-15]];

}

#pragma mark - 懒加载

/** dep */
- (UILabel *)depLabel
{
    if (!_depLabel) {
        _depLabel = [[UILabel alloc] init];
        _depLabel.textColor = [UIColor blackColor];
        _depLabel.font = [UIFont systemFontOfSize:15];
        _depLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _depLabel;
}
/** 名字 */
- (UILabel *)nameLabel
{
    if (!_nameLabel) {
        _nameLabel = [[UILabel alloc] init];
        _nameLabel.textColor = [UIColor blackColor];
        _nameLabel.font = [UIFont systemFontOfSize:15];
        _nameLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _nameLabel;
}
/** 时间 */
- (UILabel *)timeLabel
{
    if (!_timeLabel) {
        _timeLabel = [[UILabel alloc] init];
        _timeLabel.textColor = [UIColor blackColor];
        _timeLabel.font = [UIFont systemFontOfSize:15];
        _timeLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _timeLabel;
}
/** 卡 */
- (UILabel *)cardDesLabel
{
    if (!_cardDesLabel) {
        _cardDesLabel = [[UILabel alloc] init];
        _cardDesLabel.textColor = [UIColor blackColor];
        _cardDesLabel.font = [UIFont systemFontOfSize:15];
        _cardDesLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _cardDesLabel;
}
/** 是否有效 */
- (UILabel *)validLabel
{
    if (!_validLabel) {
        _validLabel = [[UILabel alloc] init];
        _validLabel.textColor = [UIColor blackColor];
        _validLabel.font = [UIFont systemFontOfSize:15];
        _validLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _validLabel;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
