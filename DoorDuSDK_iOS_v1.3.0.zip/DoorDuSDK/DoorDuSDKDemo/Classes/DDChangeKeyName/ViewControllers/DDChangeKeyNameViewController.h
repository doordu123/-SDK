//
//  DDChangeKeyNameViewController.h
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/2/1.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DDChangeKeyNameViewController : UIViewController

@property (nonatomic, strong) DoorDuKeyInfo * model;

/** 名字更改返回 */
@property (nonatomic, strong) void (^returnDataBlock)(void);

@end
