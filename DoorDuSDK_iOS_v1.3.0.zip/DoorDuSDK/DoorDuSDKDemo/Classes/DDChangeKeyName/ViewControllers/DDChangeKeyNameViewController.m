//
//  DDChangeKeyNameViewController.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/2/1.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDChangeKeyNameViewController.h"

@interface DDChangeKeyNameViewController ()

/** 当前别名 */
@property (nonatomic, strong) UILabel * currentNameLabel;

/** 输入框 */
@property (nonatomic, strong) UITextField * inputTextField;

/** 修改按钮 */
@property (nonatomic, strong) UIButton * changeButton;

/** 信息描述用的 */
@property (nonatomic, strong) UILabel * desLabel;

@end

@implementation DDChangeKeyNameViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if (@available(iOS 11.0, *)){
        [[UIScrollView appearance] setContentInsetAdjustmentBehavior:UIScrollViewContentInsetAdjustmentNever];
    } else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }

    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"修改钥匙";
    
    [self _configUI];
    self.currentNameLabel.text = self.model.door_alias;
    
}

#pragma mark - 点击事件
- (void)_changeButtonClicked
{
    if (self.inputTextField.text.length == 0) {
        [DDProgressHUD showCenterWithText:@"不能为空" duration:1.5];
        return;
    }
    if (self.inputTextField.text.length > 6) {
        [DDProgressHUD showCenterWithText:@"不能大于6个字" duration:1.5];
        return;
    }
    [SVProgressHUD showWithStatus:@"修改别名中..."];
    __weak typeof(self) weakSelf = self;
    [DoorDuDataManager setUserKeypackageAliasWithDoorId:self.model.door_id alias:self.inputTextField.text completion:^(BOOL isSuccess, DoorDuError *error) {
        [SVProgressHUD dismiss];
        if (error) {
            [DDProgressHUD showCenterWithText:error.message duration:1.5];
        } else {
            weakSelf.model.door_alias = weakSelf.inputTextField.text;
            if (weakSelf.returnDataBlock) {
                weakSelf.returnDataBlock();
            }
            [weakSelf.navigationController popViewControllerAnimated:YES];
            [DDProgressHUD showCenterWithText:@"修改别名成功" duration:1.5];
        }
    }];
}

#pragma mark - 界面布局
- (void)_configUI
{
    [self.view addSubview:self.currentNameLabel];
    /** 布局 currentTransferNumberLabel */
    //高
    [self.currentNameLabel addConstraint:[NSLayoutConstraint constraintWithItem:self.currentNameLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.currentNameLabel.font.lineHeight]];
    //上
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.currentNameLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.topLayoutGuide attribute:NSLayoutAttributeBottom multiplier:1 constant:15]];
    //左
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.currentNameLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.currentNameLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    
    [self.view addSubview:self.inputTextField];
    [self.view addSubview:self.changeButton];
    [self.view addSubview:self.desLabel];
    
    /** 布局 inputTextField */
    //高
    [self.inputTextField addConstraint:[NSLayoutConstraint constraintWithItem:self.inputTextField attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.inputTextField.font.lineHeight+6]];
    //上
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.inputTextField attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.currentNameLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:15]];
    //左
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.inputTextField attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.inputTextField attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    
    /** 布局 changeButton */
    //高
    [self.changeButton addConstraint:[NSLayoutConstraint constraintWithItem:self.changeButton attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:44]];
    //上
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.changeButton attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.inputTextField attribute:NSLayoutAttributeBottom multiplier:1 constant:15]];
    //左
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.changeButton attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.changeButton attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    
    /** 布局 desLabel */
    //高
    [self.desLabel addConstraint:[NSLayoutConstraint constraintWithItem:self.desLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.desLabel.font.lineHeight*3]];
    //上
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.desLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.changeButton attribute:NSLayoutAttributeBottom multiplier:1 constant:15]];
    //左
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.desLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.desLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    
    
}

#pragma mark - 懒加载
/** 当前呼叫转接号码 */
- (UILabel *)currentNameLabel
{
    if (!_currentNameLabel) {
        _currentNameLabel = [[UILabel alloc] init];
        _currentNameLabel.text = @"当前名字";
        _currentNameLabel.font = [UIFont systemFontOfSize:16];
        _currentNameLabel.textColor = [UIColor blackColor];
        _currentNameLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _currentNameLabel;
}
/** 输入框 */
- (UITextField *)inputTextField
{
    if (!_inputTextField) {
        _inputTextField = [[UITextField alloc] init];
        _inputTextField.placeholder = @"请输入别名";
        _inputTextField.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _inputTextField;
}
/** 修改按钮 */
- (UIButton *)changeButton
{
    if (!_changeButton) {
        _changeButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _changeButton.translatesAutoresizingMaskIntoConstraints = NO;
        [_changeButton setTitle:@"确认更改" forState:UIControlStateNormal];
        [_changeButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _changeButton.backgroundColor = [UIColor colorWithRed:0.42 green:0.71 blue:0.11 alpha:1.00];
        _changeButton.layer.cornerRadius = 3;
        _changeButton.layer.masksToBounds = YES;
        [_changeButton addTarget:self action:@selector(_changeButtonClicked) forControlEvents:UIControlEventTouchUpInside];
    }
    return _changeButton;
}
/** 信息描述用的 */
- (UILabel *)desLabel
{
    if (!_desLabel) {
        _desLabel = [[UILabel alloc] init];
        _desLabel.numberOfLines = 3;
        _desLabel.font = [UIFont systemFontOfSize:13];
        _desLabel.textAlignment = NSTextAlignmentCenter;
        _desLabel.textColor = [UIColor lightGrayColor];
        _desLabel.translatesAutoresizingMaskIntoConstraints = NO;
        _desLabel.text = @"起个喜欢的名字方便记忆，不超过6个汉字";
    }
    return _desLabel;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}

- (void)dealloc
{
    NSLog(@"\ndealloc: %@\n",NSStringFromClass([self class]));
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
