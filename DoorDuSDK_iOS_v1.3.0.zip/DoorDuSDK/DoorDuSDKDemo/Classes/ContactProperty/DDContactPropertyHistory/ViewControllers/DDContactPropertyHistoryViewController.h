//
//  DDContactPropertyHistoryViewController.h
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/24.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import <UIKit/UIKit.h>

/** 联系物业历史记录示例 */
@interface DDContactPropertyHistoryViewController : UIViewController

@property (nonatomic, strong) DoorDuRoomInfo *roomInfo;

@end
