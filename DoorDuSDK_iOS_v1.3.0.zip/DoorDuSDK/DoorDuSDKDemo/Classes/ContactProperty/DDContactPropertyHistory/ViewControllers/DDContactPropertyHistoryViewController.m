//
//  DDContactPropertyHistoryViewController.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/24.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDContactPropertyHistoryViewController.h"
#import "DDContactPropertyHistoryTableViewCell.h"

@interface DDContactPropertyHistoryViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) NSMutableArray * dataArray;

@property (nonatomic, strong) UITableView * tableView;

@end

@implementation DDContactPropertyHistoryViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if (@available(iOS 11.0, *)){
        [[UIScrollView appearance] setContentInsetAdjustmentBehavior:UIScrollViewContentInsetAdjustmentNever];
    } else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }

    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"联系物业记录";
    [self _configUI];
    
    [self _requestContactPropertyHistoryData];

}


#pragma mark - 接口请求
- (void)_requestContactPropertyHistoryData
{
    __weak typeof(self) weakSelf = self;
    [SVProgressHUD showWithStatus:@"联系物业记录请求中..."];
    [DoorDuDataManager contactPropertyHistoryWithDepID:self.roomInfo.dep_id startPage:@"1" pageNo:@"50" completion:^(NSArray<DoorDuPropertyPublishInfo *> *publishList, DoorDuError *error) {
        [SVProgressHUD dismiss];
        if (publishList) {
            [weakSelf.dataArray addObjectsFromArray:publishList];
            [weakSelf.tableView reloadData];
        } else {
            [DDProgressHUD showCenterWithText:error.message duration:1.5];
        }
    }];
}

#pragma mark - tableView 代理
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    DDContactPropertyHistoryTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"DDContactPropertyHistoryTableViewCell" forIndexPath:indexPath];
    
    cell.model = self.dataArray[indexPath.row];
    
    
    //返回cell之前重新刷新约束，重新计算高度
    [cell setNeedsUpdateConstraints];
    [cell updateConstraintsIfNeeded];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}


#pragma mark - 界面不去
- (void)_configUI
{
    [self.view addSubview:self.tableView];
    [self.tableView registerClass:DDContactPropertyHistoryTableViewCell.class forCellReuseIdentifier:@"DDContactPropertyHistoryTableViewCell"];
    
    /** 布局 tableView*/
    //上面top
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.topLayoutGuide attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
    //左边
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    //右边
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
    //底部
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.bottomLayoutGuide attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
    
}

#pragma mark - 懒加载
- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.backgroundColor = [UIColor colorWithRed:0.94 green:0.94 blue:0.96 alpha:1.00];
        _tableView.tableFooterView = [[UIView alloc]init];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        _tableView.translatesAutoresizingMaskIntoConstraints = NO;
        _tableView.rowHeight = UITableViewAutomaticDimension;
        _tableView.estimatedRowHeight = 60;
    }
    return _tableView;
}

- (NSMutableArray *)dataArray
{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

- (void)dealloc
{
    NSLog(@"\ndealloc: %@\n",NSStringFromClass([self class]));
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
