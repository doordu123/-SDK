//
//  DDContactPropertyHistoryTableViewCell.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/26.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDContactPropertyHistoryTableViewCell.h"
#import "DDContactPropertyHistoryImageContentView.h"

@interface DDContactPropertyHistoryTableViewCell ()

/** 问题类型 */
@property (nonatomic, strong) UILabel * typeInfoLabel;

/** 时间 */
@property (nonatomic, strong) UILabel * timeLabel;

/** 内容 */
@property (nonatomic, strong) UILabel * contentLabel;

/** contentLabel 的bottom */
@property (nonatomic, strong) NSLayoutConstraint * contentLayoutBottom;

/** contentLabel 的top */
@property (nonatomic, strong) NSLayoutConstraint * contentLayoutTop;

/** 用于显示图片 */
@property (nonatomic, strong) DDContactPropertyHistoryImageContentView * imageContentView;

/** imageContentView 的bottom */
@property (nonatomic, strong) NSLayoutConstraint * imageContentBottom;

/** imageContentView 的top */
@property (nonatomic, strong) NSLayoutConstraint * imageContentTop;


@end

@implementation DDContactPropertyHistoryTableViewCell


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self _configUI];
    }
    return self;
}

- (void)setModel:(DoorDuPropertyPublishInfo *)model
{
    _model = model;
    self.typeInfoLabel.text = model.tag_type_info;
    self.timeLabel.text = model.create_time;
    if (self.contentLayoutBottom) {
        [self.contentView removeConstraint:self.contentLayoutBottom];
        self.contentLayoutBottom = nil;
    }
    if (self.imageContentBottom) {
        [self.contentView removeConstraint:self.imageContentBottom];
        self.imageContentBottom = nil;
    }
    if (self.imageContentTop) {
        [self.contentView removeConstraint:self.imageContentTop];
        self.imageContentTop = nil;
    }
    self.contentLabel.hidden = NO;
    self.imageContentView.hidden = NO;
    /** 也有content 也有 image的情况 */
    if (model.content.length && model.photos_name.count) {
        
        //imageContent top
        self.imageContentTop = [NSLayoutConstraint constraintWithItem:self.imageContentView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.contentLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:10];
        [self.contentView addConstraint:self.imageContentTop];
        
        //imageContent bottom
        self.imageContentBottom = [NSLayoutConstraint constraintWithItem:self.imageContentView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeBottom multiplier:1 constant:-15];
        [self.contentView addConstraint:self.imageContentBottom];
        
        self.imageContentView.imageUrlsArray = model.photos_name;
    } else if (model.content.length) {
        self.imageContentView.hidden = YES;
        self.contentLayoutBottom = [NSLayoutConstraint constraintWithItem:self.contentLabel attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeBottom multiplier:1 constant:-15];
        [self.contentView addConstraint:self.contentLayoutBottom];
        self.imageContentView.imageUrlsArray = @[];
    } else {
        self.contentLabel.hidden = YES;
        
        //imageContent top
        self.imageContentTop = [NSLayoutConstraint constraintWithItem:self.imageContentView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.timeLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:10];
        self.imageContentTop.priority = 888;
        [self.contentView addConstraint:self.imageContentTop];
        
        
        self.imageContentBottom = [NSLayoutConstraint constraintWithItem:self.imageContentView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeBottom multiplier:1 constant:-15];
        self.imageContentBottom.priority = 888;
        [self.contentView addConstraint:self.imageContentBottom];
        self.imageContentView.imageUrlsArray = model.photos_name;
    }
    [self.contentView layoutIfNeeded];
    
    self.contentLabel.text = model.content;
}


#pragma mark - 界面布局
- (void)_configUI
{
    self.clipsToBounds = YES;
    [self.contentView addSubview:self.typeInfoLabel];
    [self.contentView addSubview:self.timeLabel];
    [self.contentView addSubview:self.contentLabel];
    [self.contentView addSubview:self.imageContentView];
    /** 布局 typeInfoLabel */
    //高
    [self.typeInfoLabel addConstraint:[NSLayoutConstraint constraintWithItem:self.typeInfoLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.typeInfoLabel.font.lineHeight]];
    //左
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.typeInfoLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.typeInfoLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    //上
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.typeInfoLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeTop multiplier:1 constant:15]];
    
    /** 布局 timeLabel */
    //高
    [self.timeLabel addConstraint:[NSLayoutConstraint constraintWithItem:self.timeLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.timeLabel.font.lineHeight]];
    //上
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.timeLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.typeInfoLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:10]];
    //左
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.timeLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.timeLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    
    /** 布局 contentLabel */
    //左
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.contentLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.contentLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    //上
    self.contentLayoutTop = [NSLayoutConstraint constraintWithItem:self.contentLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.timeLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:10];
    [self.contentView addConstraint:self.contentLayoutTop];

    /** 布局 imageContentView */
    //高
    [self.imageContentView addConstraint:[NSLayoutConstraint constraintWithItem:self.imageContentView attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:[DDContactPropertyHistoryImageContentView singleImageViewWidth]]];
    //左
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.imageContentView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    //右
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.imageContentView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
    
    //    self.imageContentBottom = [NSLayoutConstraint constraintWithItem:self.imageContentView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeBottom multiplier:1 constant:-15];
//    //下
//    [self.contentView addConstraint:self.imageContentBottom];
    
}
#pragma mark - 懒加载
/** 问题类型 */
- (UILabel *)typeInfoLabel
{
    if (!_typeInfoLabel) {
        _typeInfoLabel = [[UILabel alloc] init];
        _typeInfoLabel.textColor = [UIColor blackColor];
        _typeInfoLabel.font = [UIFont systemFontOfSize:15];
        _typeInfoLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _typeInfoLabel;
}
/** 时间 */
- (UILabel *)timeLabel
{
    if (!_timeLabel) {
        _timeLabel = [[UILabel alloc] init];
        _timeLabel.textColor = [UIColor blackColor];
        _timeLabel.font = [UIFont systemFontOfSize:15];
        _timeLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _timeLabel;
}
/** 内容 */
- (UILabel *)contentLabel
{
    if (!_contentLabel) {
        _contentLabel = [[UILabel alloc] init];
        _contentLabel.numberOfLines = 0;
        _contentLabel.textColor = [UIColor blackColor];
        _contentLabel.font = [UIFont systemFontOfSize:15];
        _contentLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _contentLabel;
}
/** 用于显示图片 */
- (DDContactPropertyHistoryImageContentView *)imageContentView
{
    if (!_imageContentView) {
        _imageContentView = [[DDContactPropertyHistoryImageContentView alloc] init];
        _imageContentView.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _imageContentView;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
