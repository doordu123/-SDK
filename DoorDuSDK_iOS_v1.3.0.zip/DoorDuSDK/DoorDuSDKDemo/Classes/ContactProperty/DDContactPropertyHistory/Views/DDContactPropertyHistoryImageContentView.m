//
//  DDContactPropertyHistoryImageContentView.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/29.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDContactPropertyHistoryImageContentView.h"
#import "DDContactPropertyHistoryImageContentCollectionViewCell.h"
#import "UIImageView+DDImageCache.h"

@interface DDContactPropertyHistoryImageContentView ()<UICollectionViewDelegate,UICollectionViewDataSource>

@property (nonatomic,strong) UICollectionView * collectionView;//添加图片

@end

@implementation DDContactPropertyHistoryImageContentView

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self _configUI];
    }
    return self;
}

- (void)setImageUrlsArray:(NSArray *)imageUrlsArray
{
    _imageUrlsArray = imageUrlsArray;
    if (imageUrlsArray.count) {
//        [self.collectionView scrollRectToVisible:CGRectZero animated:NO];
        [self.collectionView reloadData];
    }
}

#pragma mark - 代理方法

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.imageUrlsArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    DDContactPropertyHistoryImageContentCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"DDContactPropertyHistoryImageContentCollectionViewCell" forIndexPath:indexPath];
    NSString * imageKeyString = self.imageUrlsArray[indexPath.row];
    [cell.imageView dd_setImageWithURL:[NSURL URLWithString:imageKeyString]];
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{

    
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    //上左下右
    //{top, left, bottom, right}
    return UIEdgeInsetsMake(0, 15, 0, 15);
}

#pragma mark - 界面布局
- (void)_configUI
{
    [self addSubview:self.collectionView];
    //上
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.collectionView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
    //左
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.collectionView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    //右
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.collectionView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
    //下
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.collectionView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
}

#pragma mark - 懒加载
#pragma mark - 懒加载
- (UICollectionView *)collectionView
{
    if (!_collectionView) {
        UICollectionViewFlowLayout * layout = [[UICollectionViewFlowLayout alloc] init];
        layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        //设置水平方向的空隙
        NSInteger space = 10;
        layout.minimumInteritemSpacing = space;
        layout.minimumLineSpacing = space;
        //设置垂直方向的空隙
        
        layout.itemSize = CGSizeMake([[self class] singleImageViewWidth], [[self class] singleImageViewWidth]);
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
        _collectionView.translatesAutoresizingMaskIntoConstraints = NO;
        _collectionView.backgroundColor = [UIColor whiteColor];
        _collectionView.dataSource = self;
        _collectionView.delegate = self;
        _collectionView.showsVerticalScrollIndicator = NO;
//        _collectionView.showsHorizontalScrollIndicator = NO;
        [_collectionView registerClass:DDContactPropertyHistoryImageContentCollectionViewCell.class forCellWithReuseIdentifier:@"DDContactPropertyHistoryImageContentCollectionViewCell"];
    }
    return _collectionView;
}

+ (CGFloat)singleImageViewWidth
{
    return ([UIScreen mainScreen].bounds.size.width - (30+20))/3.0;
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
