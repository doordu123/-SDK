//
//  DDContactPropertyHistoryImageContentCollectionViewCell.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/29.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDContactPropertyHistoryImageContentCollectionViewCell.h"

@implementation DDContactPropertyHistoryImageContentCollectionViewCell

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self __configUI];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self __configUI];
    }
    return self;
}

- (void)__configUI
{
    [self.contentView addSubview:self.imageView];
    //上
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.imageView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
    //左
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.imageView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    //右
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.imageView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
    //下
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.imageView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];

}


#pragma mark - 懒加载
- (UIImageView *)imageView
{
    if (!_imageView) {
        _imageView = [[UIImageView alloc] init];
        _imageView.contentMode = UIViewContentModeScaleAspectFill;
        _imageView.clipsToBounds = YES;
        _imageView.userInteractionEnabled = NO;
        _imageView.backgroundColor = [UIColor orangeColor];
        _imageView.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _imageView;
}


@end
