//
//  DDContactPropertyImageContentView.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/24.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDContactPropertyImageContentView.h"
#import "DDContactPropertyImageCollectionViewCell.h"
#import "DDActionSheet.h"
#import "TZImagePickerController.h"

@interface DDContactPropertyImageContentView ()<UICollectionViewDelegate,UICollectionViewDataSource,UITextViewDelegate>

@property (nonatomic,strong) UICollectionView * collectionView;//添加图片

@property (nonatomic, strong) NSLayoutConstraint * collectionViewHeightLayoutConstraint;

@end

@implementation DDContactPropertyImageContentView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self __configUI];
        self.userInteractionEnabled = YES;
    }
    return self;
}

/** 刷新数据 */
- (void)reloadData
{
    [self __reloadData];
}
- (void)__reloadData
{
    NSInteger imageArrayCount = self.imageArray.count;
    NSInteger row = ceil((imageArrayCount<self.maxNumber?(imageArrayCount+1):self.maxNumber)/4.0);
    CGFloat height = row * [self.class singleImageViewWidth]+(row-1)*10;
    self.collectionViewHeightLayoutConstraint.constant = height;
    [self layoutIfNeeded];
    [self.collectionView reloadData];
    if (self.retrunRefreshBlock) {
        self.retrunRefreshBlock();
    }
}

#pragma mark - 代理方法

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if (self.imageArray.count == self.maxNumber) {
        return self.imageArray.count;
    }
    return self.imageArray.count+1;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    [self.superview.superview endEditing:YES];
    DDContactPropertyImageCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"DDContactPropertyImageCollectionViewCell" forIndexPath:indexPath];
    if (self.imageArray.count == self.maxNumber) {//最大个数了
        cell.deleteButton.hidden = NO;
        cell.imageView.image = self.imageArray[indexPath.row];
    } else {//没有
        if (indexPath.row == self.imageArray.count) {//最后一个
            cell.deleteButton.hidden = YES;
            cell.imageView.image = [UIImage imageNamed:@"DDContactPorpertyImageAddImage"];
        } else {
            cell.deleteButton.hidden = NO;
            cell.imageView.image = self.imageArray[indexPath.row];
        }
    }
    __weak typeof(self) weakSelf = self;
    /** 删除回调 */
    cell.deleteButtonClickedBlock = ^{
        [weakSelf.imageArray removeObjectAtIndex:indexPath.row];
        [weakSelf __reloadData];
    };
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    [self.superview.superview endEditing:YES];
    if (self.imageArray.count == indexPath.row && self.imageArray.count < self.maxNumber) {//点击了 加号
        __weak typeof(self) weakSelf = self;
        [DDActionSheet showWithVC:self.superViewController title:nil cancel:@"取消" message:nil otherButtonTitle:@[@"照相",@"从手机相册选择"] clickedBlock:^(NSInteger index) {
            if (index == 0) {//照相
                [weakSelf __cameraClicked];
            } else if (index == 1) {//选择相册
                [weakSelf __albumClicked];
            }
        }];
    } else {
        
    }
}

#pragma mark - 选择了相机
- (void)__cameraClicked
{
    
}
#pragma mark - 选择了相册
- (void)__albumClicked
{
    TZImagePickerController *imagePickerVc = [[TZImagePickerController alloc] initWithMaxImagesCount:self.maxNumber - self.imageArray.count columnNumber:4 delegate:nil pushPhotoPickerVc:YES];
    // 3. 设置是否可以选择视频/图片/原图
    imagePickerVc.allowPickingVideo = NO;
    imagePickerVc.allowPickingImage = YES;
    imagePickerVc.allowPickingOriginalPhoto = YES;
    imagePickerVc.allowPickingGif = NO;
    imagePickerVc.allowPickingMultipleVideo = NO; // 是否可以多选视频
    // 4. 照片排列按修改时间升序
    imagePickerVc.sortAscendingByModificationDate = YES;
    imagePickerVc.showSelectBtn = NO;
    imagePickerVc.allowCrop = YES;
    imagePickerVc.needCircleCrop = NO;
    imagePickerVc.isStatusBarDefault = NO;
#pragma mark - 到这里为止
    __weak typeof(self) weakSelf = self;
    [imagePickerVc setDidFinishPickingPhotosHandle:^(NSArray<UIImage *> *photos, NSArray *assets, BOOL isSelectOriginalPhoto) {
        [weakSelf.imageArray addObjectsFromArray:photos];
        [weakSelf __reloadData];
    }];
    
    [self.superViewController presentViewController:imagePickerVc animated:YES completion:nil];

}



- (void)__configUI
{
    [self addSubview:self.collectionView];
    //上
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.collectionView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
    //左
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.collectionView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    //右
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.collectionView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
    
    //高
    self.collectionViewHeightLayoutConstraint = [NSLayoutConstraint constraintWithItem:self.collectionView attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:0];
    
    //下
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.collectionView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];

    
    [self.collectionView addConstraint:self.collectionViewHeightLayoutConstraint];

    
    [self __reloadData];
}


#pragma mark - 懒加载
- (UICollectionView *)collectionView
{
    if (!_collectionView) {
        UICollectionViewFlowLayout * layout = [[UICollectionViewFlowLayout alloc] init];
        layout.scrollDirection = UICollectionViewScrollDirectionVertical;
        //设置水平方向的空隙
        NSInteger space = 10;
        layout.minimumInteritemSpacing = space;
        layout.minimumLineSpacing = space;
        //设置垂直方向的空隙
        
        layout.itemSize = CGSizeMake([[self class] singleImageViewWidth], [[self class] singleImageViewWidth]);
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
        _collectionView.translatesAutoresizingMaskIntoConstraints = NO;
        _collectionView.backgroundColor = [UIColor whiteColor];
        _collectionView.dataSource = self;
        _collectionView.delegate = self;
        _collectionView.scrollEnabled = NO;
        _collectionView.showsVerticalScrollIndicator = NO;
        _collectionView.showsHorizontalScrollIndicator = NO;
        _collectionView.userInteractionEnabled = YES;
        [_collectionView registerClass:DDContactPropertyImageCollectionViewCell.class forCellWithReuseIdentifier:@"DDContactPropertyImageCollectionViewCell"];
    }
    return _collectionView;
}
- (NSMutableArray *)imageArray
{
    if (!_imageArray) {
        _imageArray = [NSMutableArray array];
    }
    return _imageArray;
}

+ (CGFloat)singleImageViewWidth
{
    return ([UIScreen mainScreen].bounds.size.width - (30+30))/4.0;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
