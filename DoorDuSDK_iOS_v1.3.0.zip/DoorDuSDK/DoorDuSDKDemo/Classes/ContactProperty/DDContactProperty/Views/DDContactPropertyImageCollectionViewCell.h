//
//  DDContactPropertyImageCollectionViewCell.h
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/24.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DDContactPropertyImageCollectionViewCell : UICollectionViewCell

@property (nonatomic, strong) UIImageView * imageView;//图片

@property (nonatomic, strong) UIButton * deleteButton;//删除按钮

@property (nonatomic,copy) void (^deleteButtonClickedBlock)(void);

@end
