//
//  DDContactPropertyImageCollectionViewCell.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/24.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDContactPropertyImageCollectionViewCell.h"

@implementation DDContactPropertyImageCollectionViewCell

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self __configUI];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self __configUI];
    }
    return self;
}

- (void)__configUI
{
    [self.contentView addSubview:self.imageView];
    self.imageView.frame = self.bounds;
    
    [self.contentView addSubview:self.deleteButton];
    CGFloat delta = self.imageView.frame.size.width - (self.deleteButton.frame.origin.x + self.deleteButton.frame.size.width);
    CGRect newframe = self.deleteButton.frame;
    newframe.origin.x += delta ;
    
    self.deleteButton.frame = newframe;
    
}
//删除点击事件
- (void)_deleteButtonClicked
{
    if (self.deleteButtonClickedBlock) {
        self.deleteButtonClickedBlock();
    }
}

#pragma mark - 懒加载
- (UIImageView *)imageView
{
    if (!_imageView) {
        _imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 0, 0)];
        _imageView.contentMode = UIViewContentModeScaleAspectFill;
        _imageView.clipsToBounds = YES;
        _imageView.userInteractionEnabled = NO;
    }
    return _imageView;
}

- (UIButton *)deleteButton
{
    if (!_deleteButton) {
        _deleteButton = [UIButton buttonWithType:UIButtonTypeCustom];
        UIImage * image = [UIImage imageNamed:@"DDContactPorpertyDeleteImage"];
        _deleteButton.frame = CGRectMake(0, 0, image.size.width, image.size.height);
        [_deleteButton setImage:image forState:UIControlStateNormal];
        [_deleteButton addTarget:self action:@selector(_deleteButtonClicked) forControlEvents:UIControlEventTouchUpInside];
    }
    return _deleteButton;
}

@end
