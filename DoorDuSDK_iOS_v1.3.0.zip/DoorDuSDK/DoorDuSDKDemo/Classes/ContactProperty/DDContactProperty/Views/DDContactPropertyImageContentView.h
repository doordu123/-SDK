//
//  DDContactPropertyImageContentView.h
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/24.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import <UIKit/UIKit.h>

/** 用于选择图片 */
@interface DDContactPropertyImageContentView : UIView

@property (nonatomic,weak) UIViewController * superViewController;

/** 选择图片的最多个数 */
@property (nonatomic, assign) NSInteger maxNumber;

/** 图片的个数 */
@property (nonatomic, strong) NSMutableArray * imageArray;

/** 刷新数据 */
- (void)reloadData;

@property (nonatomic,copy) void (^retrunRefreshBlock)(void) ;

@end
