//
//  DDContactPropertyViewController.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/24.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDContactPropertyViewController.h"
#import "DDPlaceholderTextView.h"
#import "DDContactPropertyImageContentView.h"
#import "DDActionSheet.h"
#import "DDContactPropertyHistoryViewController.h"
#import "UIImage+scale.h"
#import <DoorDuSDK/DoorDuDataManager.h>


@interface DDContactPropertyViewController ()<UITextViewDelegate>

/** 包含留言描述inputTextView和图片 */
@property (nonatomic, strong) UIView * topContentBackgroundView;

/** 物业留言描述 */
@property (nonatomic, strong) DDPlaceholderTextView * inputTextView;

/** 承载imageView */
@property (nonatomic, strong) DDContactPropertyImageContentView * imageContentView;

/** 标签button */
@property (nonatomic, strong) UIButton * tagButton;

/** 标签数组 */
@property (nonatomic, strong) NSArray * tagArray;

/** 发布按钮 */
@property (nonatomic, strong) UIButton * issueButton;


@end

@implementation DDContactPropertyViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if (@available(iOS 11.0, *)){
        [[UIScrollView appearance] setContentInsetAdjustmentBehavior:UIScrollViewContentInsetAdjustmentNever];
    } else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }
    
    self.title = @"联系物业";
    self.view.backgroundColor = [UIColor colorWithRed:0.91 green:0.91 blue:0.92 alpha:1.00];
    self.tagArray = @[@"其它",@"投诉建议",@"报修维护",@"失物招领"];
    [self _configUI];
    
    UIBarButtonItem * rightItem = [[UIBarButtonItem alloc] initWithTitle:@"记录" style:UIBarButtonItemStylePlain target:self action:@selector(_contactPropertyHistoryClicked)];
    self.navigationItem.rightBarButtonItem = rightItem;
    
}

#pragma mark - 点击事件
/** 标签点击 */
- (void)_tagButtonClicked
{
    [self.view endEditing:YES];
    __weak typeof(self) weakSelf = self;
    [DDActionSheet showWithVC:self title:@"选择一个标签" cancel:@"取消" message:nil otherButtonTitle:self.tagArray clickedBlock:^(NSInteger index) {
        [weakSelf.tagButton setTitle:weakSelf.tagArray[index] forState:UIControlStateNormal];
    }];
}
/** 联系物业记录 */
- (void)_contactPropertyHistoryClicked
{
    DDContactPropertyHistoryViewController * vc = [[DDContactPropertyHistoryViewController alloc] init];
    vc.roomInfo = self.roomInfo;
    [self.navigationController pushViewController:vc animated:YES];
}

/** 发布按钮 */
- (void)_issueButtonClicked
{
    if (self.inputTextView.text.length == 0 && self.imageContentView.imageArray.count == 0) {
        
        return;
    }
    NSMutableArray * imageDatasArray = [NSMutableArray array];
    for (UIImage * image in self.imageContentView.imageArray) {
        NSData * imageData = [image resizePressImage2DataScale:0.5];
        [imageDatasArray addObject:imageData];
    }
    NSInteger tagType = [self.tagArray indexOfObject:self.tagButton.titleLabel.text];
    [SVProgressHUD showWithStatus:@"联系物业信息发布中..."];
    
    [DoorDuDataManager contactPropertyWithRoomId:self.roomInfo.room_number_id content:self.inputTextView.text imageDatas:imageDatasArray tagType:[NSString stringWithFormat:@"%ld",tagType] completion:^(BOOL isSuccess, DoorDuError *error) {
        [SVProgressHUD dismiss];
        if (isSuccess) {
            [DDProgressHUD showCenterWithText:@"联系物业成功" duration:1.5];
        } else {
            [DDProgressHUD showCenterWithText:error.message duration:1.5];
        }
    }];
}

#pragma mark - UITextViewDelegate
-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    if ([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
        return NO;
    }
    NSString * string = [textView.text stringByReplacingCharactersInRange:range withString:text];
    NSUInteger maxLength = 140;
    if ((string.length > maxLength) && (range.length != 1)){
        textView.text = [string substringToIndex:maxLength];
        return NO;
    }else {
        return YES;
    }
}

#pragma mark - 界面布局
- (void)_configUI
{
    [self.view addSubview:self.topContentBackgroundView];
    /** 布局 topContentBackgroundView */
    //上
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.topContentBackgroundView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.topLayoutGuide attribute:NSLayoutAttributeBottom multiplier:1 constant:15]];
    //左
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.topContentBackgroundView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    //右
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.topContentBackgroundView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
    
    /** 添加输入框 */
    [self.topContentBackgroundView addSubview:self.inputTextView];
    
    /** 布局inputTextView */
    //上
    [self.topContentBackgroundView addConstraint:[NSLayoutConstraint constraintWithItem:self.inputTextView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.topContentBackgroundView attribute:NSLayoutAttributeTop multiplier:1 constant:5]];
    //左
    [self.topContentBackgroundView addConstraint:[NSLayoutConstraint constraintWithItem:self.inputTextView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.topContentBackgroundView attribute:NSLayoutAttributeLeft multiplier:1 constant:5]];
    //右
    [self.topContentBackgroundView addConstraint:[NSLayoutConstraint constraintWithItem:self.inputTextView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.topContentBackgroundView attribute:NSLayoutAttributeRight multiplier:1 constant:-5]];
    //高
    [self.inputTextView addConstraint:[NSLayoutConstraint constraintWithItem:self.inputTextView attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:120]];
    
    /** 添加imageContentView */
    [self.topContentBackgroundView addSubview:self.imageContentView];
    //上
    [self.topContentBackgroundView addConstraint:[NSLayoutConstraint constraintWithItem:self.imageContentView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.inputTextView attribute:NSLayoutAttributeBottom multiplier:1 constant:5]];
    //左
    [self.topContentBackgroundView addConstraint:[NSLayoutConstraint constraintWithItem:self.imageContentView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.topContentBackgroundView attribute:NSLayoutAttributeLeft multiplier:1 constant:5]];
    //右
    [self.topContentBackgroundView addConstraint:[NSLayoutConstraint constraintWithItem:self.imageContentView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.topContentBackgroundView attribute:NSLayoutAttributeRight multiplier:1 constant:-5]];
    
    //下
    [self.topContentBackgroundView addConstraint:[NSLayoutConstraint constraintWithItem:self.imageContentView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.topContentBackgroundView attribute:NSLayoutAttributeBottom multiplier:1 constant:-10]];
    
    /** 添加tagButton */
    [self.view addSubview:self.tagButton];
    
    /** 布局tagButton */
    //上
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tagButton attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.topContentBackgroundView attribute:NSLayoutAttributeBottom multiplier:1 constant:15]];
    //宽
    [self.tagButton addConstraint:[NSLayoutConstraint constraintWithItem:self.tagButton attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:120]];
    //高
    [self.tagButton addConstraint:[NSLayoutConstraint constraintWithItem:self.tagButton attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:40]];
    //右
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tagButton attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    
    /** 添加tagButton */
    [self.view addSubview:self.issueButton];
    
    /** 布局issueButton */
    //上
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.issueButton attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.tagButton attribute:NSLayoutAttributeBottom multiplier:1 constant:15]];
    //左
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.issueButton attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.issueButton attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    //高
    [self.issueButton addConstraint:[NSLayoutConstraint constraintWithItem:self.issueButton attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:40]];
    
    [self.imageContentView reloadData];
}


#pragma mark - 懒加载
/** 包含留言描述inputTextView和图片 */
- (UIView *)topContentBackgroundView
{
    if (!_topContentBackgroundView) {
        _topContentBackgroundView = [[UIView alloc] init];
        _topContentBackgroundView.backgroundColor = [UIColor whiteColor];
        _topContentBackgroundView.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _topContentBackgroundView;
}
/** 物业留言描述 */
- (DDPlaceholderTextView *)inputTextView
{
    if (!_inputTextView) {
        _inputTextView = [[DDPlaceholderTextView alloc] init];
        _inputTextView.translatesAutoresizingMaskIntoConstraints = NO;
        _inputTextView.placeholder = @"请留言，140字以内...";
        _inputTextView.delegate = self;
        _inputTextView.returnKeyType = UIReturnKeyDone;
    }
    return _inputTextView;
}
/** 承载imageView */
- (DDContactPropertyImageContentView *)imageContentView
{
    if (!_imageContentView) {
        _imageContentView = [[DDContactPropertyImageContentView alloc] init];
        _imageContentView.superViewController = self;
        _imageContentView.translatesAutoresizingMaskIntoConstraints = NO;
        _imageContentView.maxNumber = 3;
        __weak typeof(self) weakSelf = self;
        _imageContentView.retrunRefreshBlock = ^{
            [weakSelf.view layoutIfNeeded];
        };
    }
    return _imageContentView;
}
/** 标签button */
- (UIButton *)tagButton
{
    if (!_tagButton) {
        _tagButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_tagButton setTitle:@"报修维护" forState:UIControlStateNormal];
        [_tagButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        _tagButton.translatesAutoresizingMaskIntoConstraints = NO;
        [_tagButton setImage:[UIImage imageNamed:@"DDCommonarrowdownImage"] forState:UIControlStateNormal];
        [_tagButton addTarget:self action:@selector(_tagButtonClicked) forControlEvents:UIControlEventTouchUpInside];
        _tagButton.backgroundColor = [UIColor whiteColor];
        _tagButton.layer.masksToBounds = YES;
        _tagButton.layer.cornerRadius = 3;
    }
    return _tagButton;
}
/** 发布按钮 */
- (UIButton *)issueButton
{
    if (!_issueButton) {
        _issueButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_issueButton setTitle:@"发布" forState:UIControlStateNormal];
        [_issueButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _issueButton.translatesAutoresizingMaskIntoConstraints = NO;
        _issueButton.backgroundColor = [UIColor colorWithRed:0.42 green:0.71 blue:0.11 alpha:1.00];
        [_issueButton addTarget:self action:@selector(_issueButtonClicked) forControlEvents:UIControlEventTouchUpInside];
        _issueButton.layer.masksToBounds = YES;
        _issueButton.layer.cornerRadius = 3;
    }
    return _issueButton;
}
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}

- (void)dealloc
{
    NSLog(@"\ndealloc: %@\n",NSStringFromClass([self class]));
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
