//
//  DDCallListener.m
//  DoorDuSDKDemo
//
//  Created by DoorDu on 2018/1/10.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDCallListener.h"
#import "DoorIncomingViewController.h"

@implementation DDCallListener


/**接收到门禁呼叫来电*/
- (void)callDidReceiveDoor:(DoorDuDoorCallModel *)model
{
    UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    DoorIncomingViewController *doorIncomingVC = [sb instantiateViewControllerWithIdentifier:@"DoorIncomingID"];
    doorIncomingVC.incomingImageObjectKey = model.incomingImageObjectKey;
    doorIncomingVC.doorName = model.doorName;
    doorIncomingVC.doorCallerNO = model.doorCallerNO;
    doorIncomingVC.doorGuid = model.doorGuid;
    doorIncomingVC.doorID = model.doorID;
    doorIncomingVC.appRoomID = model.appRoomID;
    doorIncomingVC.isStartAutoAccept = NO;
    
    doorIncomingVC.modalPresentationStyle = UIModalPresentationOverFullScreen;
    doorIncomingVC.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    
    UIViewController *topViewController = [self topViewControllerWithRootViewController:[UIApplication sharedApplication].keyWindow.rootViewController];
    [topViewController presentViewController:doorIncomingVC animated:YES completion:nil];
}

/**
 * 以下情况会接收到挂断通知：
 * 1.主叫方挂断了电话（取消电话呼叫）
 * 2.户户通和门禁打过来的时候同房间的人比你先接听
 * 3.呼叫超时
 */
- (void)callDidHangupMessage;
{
    [[DoorDuAudioPlayer sharedInstance] stopPlayAudioAndVibrate];
    
    UIViewController *topViewController = [self topViewControllerWithRootViewController:[UIApplication sharedApplication].keyWindow.rootViewController];
    [topViewController dismissViewControllerAnimated:YES completion:nil];
}
/** 物业通知 */
- (void)receivePropertyNoticeMessage:(DoorDuPropertyNotice *)model
{
    [DDProgressHUD showCenterWithText:@"收到--新的物业通知" duration:2.0];
}
/** 授权变更通知 */
- (void)receiveAuthorizationChangeMessage:(DoorDuAuthorizationChange *)model
{
    [DDProgressHUD showCenterWithText:@"收到--授权变更通知" duration:2.0];
}

- (UIViewController*)topViewControllerWithRootViewController:(UIViewController*)rootViewController
{
    if ([rootViewController isKindOfClass:[UITabBarController class]]) {
        UITabBarController *tabBarController = (UITabBarController *)rootViewController;
        return [self topViewControllerWithRootViewController:tabBarController.selectedViewController];
    } else if ([rootViewController isKindOfClass:[UINavigationController class]]) {
        UINavigationController* navigationController = (UINavigationController*)rootViewController;
        return [self topViewControllerWithRootViewController:navigationController.visibleViewController];
    } else if (rootViewController.presentedViewController) {
        UIViewController* presentedViewController = rootViewController.presentedViewController;
        return [self topViewControllerWithRootViewController:presentedViewController];
    } else {
        return rootViewController;
    }
}



@end
