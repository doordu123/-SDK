//
//  DDUserNoDisturbingSingleRoomViewController.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/31.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDUserNoDisturbingSingleRoomViewController.h"
#import "DDUserNoDisturbingHeaderFooterView.h"

@interface DDUserNoDisturbingSingleRoomViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) NSMutableArray * dataArray;

@property (nonatomic, strong) UITableView * tableView;


@end

@implementation DDUserNoDisturbingSingleRoomViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if (@available(iOS 11.0, *)){
        [[UIScrollView appearance] setContentInsetAdjustmentBehavior:UIScrollViewContentInsetAdjustmentNever];
    } else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }

    self.view.backgroundColor = [UIColor whiteColor];
    self.title = self.layoutModel.titleString;

    [self _configUI];
    
}

#pragma mark - 免打扰设置
- (void)_requestDisturbAPPStatus:(NSString *)appStatus callStatus:(NSString *)callStatus
{
    [SVProgressHUD showWithStatus:@"免打扰设置中..."];
    __weak typeof(self) weakSelf = self;
    [DoorDuDataManager setUserRoomDisturbInfoWithRoomId:self.layoutModel.model.room_id appStatus:appStatus callStatus:callStatus completion:^(DoorDuRoomDisturbSettingResult *disturbInfo, DoorDuError *error) {
        [SVProgressHUD dismiss];
        if (error) {
            [DDProgressHUD showCenterWithText:error.message duration:1.5];
            [weakSelf.tableView reloadData];
        } else {
            weakSelf.layoutModel.model.app_status = disturbInfo.app_status;
            weakSelf.layoutModel.model.call_status = disturbInfo.call_status;
            [weakSelf.layoutModel reloadData];
            [weakSelf.tableView reloadData];
        }
    }];
}

#pragma mark - tableView 代理

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 3;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"UITableViewCell" forIndexPath:indexPath];
    cell.textLabel.font = [UIFont systemFontOfSize:16];
    cell.textLabel.textColor = [UIColor blackColor];
    //0-关闭、1-开启、2-夜间开启*
    if (indexPath.row == 0) {
        cell.textLabel.text = @"关闭";
    } else if (indexPath.row == 1) {
        cell.textLabel.text = @"开启";
    } else if (indexPath.row == 2) {
        cell.textLabel.text = @"夜间开启";
    }
    cell.accessoryType = UITableViewCellAccessoryNone;
    //app
    if (indexPath.section == 0) {
        if (self.layoutModel.model.app_status.integerValue == indexPath.row) {
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
        }
    }
    //电话
    if (indexPath.section == 1) {
        if (self.layoutModel.model.call_status.integerValue == indexPath.row) {
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
        }
    }

    // 返回cell之前重新刷新约束，重新计算高度
    [cell setNeedsUpdateConstraints];
    [cell updateConstraintsIfNeeded];
    return cell;
    
    return nil;
    
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    DDUserNoDisturbingHeaderFooterView * headerView = [tableView dequeueReusableHeaderFooterViewWithIdentifier:@"DDUserNoDisturbingHeaderFooterView"];
    if (section == 0) {
        headerView.titleString = @"APP呼叫-开启后，呼叫开门不再APP通知您。在夜间开启：在22:00到次日8:00不通知您";
    }
    if (section == 1) {
        headerView.titleString = @"手机电话呼叫-关闭后，呼叫开门通过手机电话通知您，接通后按“0”可开门。在夜间开启：在22:00到次日8:00不通知您";
    }
    [headerView setNeedsUpdateConstraints];
    [headerView updateConstraintsIfNeeded];
    return headerView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return CGFLOAT_MIN;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 0) {
        if (self.layoutModel.model.app_status.integerValue == indexPath.row) {
            return;
        }
        NSString * status = [NSString stringWithFormat:@"%ld",indexPath.row];
        [self _requestDisturbAPPStatus:status callStatus:self.layoutModel.model.call_status];
    } else if (indexPath.section == 1) {
        if (self.layoutModel.model.call_status.integerValue == indexPath.row) {
            return;
        }
        NSString * status = [NSString stringWithFormat:@"%ld",indexPath.row];
        [self _requestDisturbAPPStatus:self.layoutModel.model.app_status callStatus:status];
    }
}


#pragma mark - 界面不去
- (void)_configUI
{
    [self.view addSubview:self.tableView];
    [self.tableView registerClass:UITableViewCell.class forCellReuseIdentifier:@"UITableViewCell"];
    [self.tableView registerClass:DDUserNoDisturbingHeaderFooterView.class forHeaderFooterViewReuseIdentifier:@"DDUserNoDisturbingHeaderFooterView"];
    /** 布局 tableView*/
    //上面top
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.topLayoutGuide attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
    //左边
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    //右边
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
    //底部
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.bottomLayoutGuide attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
    
}


#pragma mark - 懒加载
- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.backgroundColor = [UIColor colorWithRed:0.94 green:0.94 blue:0.96 alpha:1.00];
        _tableView.tableFooterView = [[UIView alloc]init];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        _tableView.translatesAutoresizingMaskIntoConstraints = NO;
        _tableView.rowHeight = UITableViewAutomaticDimension;
        _tableView.estimatedRowHeight = 60;
    }
    return _tableView;
}

- (NSMutableArray *)dataArray
{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

- (void)dealloc
{
    NSLog(@"\ndealloc: %@\n",NSStringFromClass([self class]));
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
