//
//  DDUserNoDisturbingSingleRoomViewController.h
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/31.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DDUserNoDisturbingTwoLayoutModel.h"

/** 单个房间 */
@interface DDUserNoDisturbingSingleRoomViewController : UIViewController

@property (nonatomic, strong) DDUserNoDisturbingTwoLayoutModel * layoutModel;

@end
