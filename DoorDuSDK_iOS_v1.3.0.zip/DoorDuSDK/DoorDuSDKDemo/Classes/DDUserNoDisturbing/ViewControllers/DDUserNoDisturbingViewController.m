//
//  DDUserNoDisturbingViewController.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/30.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDUserNoDisturbingViewController.h"
#import "DDUserNoDisturbingOneTableViewCell.h"
#import "DDUserNoDisturbingHeaderFooterView.h"
#import "DDUserNoDisturbingTwoTableViewCell.h"
#import "DDUserNoDisturbingSingleRoomViewController.h"

#import "AppDelegate.h"

@interface DDUserNoDisturbingViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) NSMutableArray * dataArray;
@property (nonatomic, strong) NSMutableArray * dataRoomArray;

@property (nonatomic, strong) UITableView * tableView;

/** 获取的免打扰数据 */
@property (nonatomic, strong) DoorDuCallDisturbInfo * disturbInfo;

@end

@implementation DDUserNoDisturbingViewController

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.tableView reloadData];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if (@available(iOS 11.0, *)){
        [[UIScrollView appearance] setContentInsetAdjustmentBehavior:UIScrollViewContentInsetAdjustmentNever];
    } else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }

    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"免打扰";
    
    [self _configUI];
    
    [self _requestCallDisturbData];
}

#pragma mark - 一键免打扰设置
- (void)_requestOnekeyDisturbAPPStatus:(NSString *)appStatus callStatus:(NSString *)callStatus
{
    [SVProgressHUD showWithStatus:@"免打扰设置中..."];
    __weak typeof(self) weakSelf = self;
    [DoorDuDataManager setAllRoomDisturbInfoWithAppStatus:appStatus callStatus:callStatus completion:^(DoorDuDisturbSettingResult *disturbInfo, DoorDuError *error) {
        [SVProgressHUD dismiss];
        if (error) {
            [DDProgressHUD showCenterWithText:error.message duration:1.5];
            [weakSelf.tableView reloadData];
        } else {
            weakSelf.disturbInfo.app_status = disturbInfo.app_status;
            weakSelf.disturbInfo.call_status = disturbInfo.call_status;
            [weakSelf _reloadData];
        }
    }];
}

#pragma mark - 获取免打扰数据
- (void)_requestCallDisturbData
{
    [SVProgressHUD showWithStatus:@"获取免打扰数据中..."];
    __weak typeof(self) weakSelf = self;
    [DoorDuDataManager getUserDisturbInfoWithCompletion:^(DoorDuCallDisturbInfo *disturbInfo, DoorDuError *error) {
        [SVProgressHUD dismiss];
        if (error) {
            [DDProgressHUD showCenterWithText:error.message duration:1.5];
        } else {
            weakSelf.disturbInfo = disturbInfo;
            [weakSelf _reloadData];
        }
    }];
}

#pragma mark - 刷新数据
- (void)_reloadData
{
    [self.dataArray removeAllObjects];
    /**  一键免打扰  */
    DDUserNoDisturbingOneLayoutModel * layoutModel = [[DDUserNoDisturbingOneLayoutModel alloc] init];
    layoutModel.titleString = @"一键免打扰";
    layoutModel.desString = @"开启后，app呼叫开门不再通知您。\n开启后，呼叫开门失败后不再通过手机电话通知您。";
    layoutModel.statusBool = NO;
    if (self.disturbInfo.app_status.integerValue == 1 && self.disturbInfo.call_status.integerValue == 1) {
        layoutModel.statusBool = YES;
    }
    [self.dataArray addObject:layoutModel];
    
    /** app免打扰 */
    layoutModel = [[DDUserNoDisturbingOneLayoutModel alloc] init];
    layoutModel.titleString = @"app呼叫打扰";
    layoutModel.desString = @"开启后，app呼叫开门不再通知您。";
    layoutModel.statusBool = self.disturbInfo.app_status.integerValue;
    [self.dataArray addObject:layoutModel];
    
    /** 手机电话呼叫免打扰 */
    layoutModel = [[DDUserNoDisturbingOneLayoutModel alloc] init];
    layoutModel.titleString = @"手机电话呼叫免打扰";
    layoutModel.desString = @"开启后，呼叫开门失败后不再通过手机电话通知您。";
    layoutModel.statusBool = self.disturbInfo.call_status.integerValue;
    [self.dataArray addObject:layoutModel];
    
    NSArray<DoorDuRoomInfo *> *roomList = ((AppDelegate *)[UIApplication sharedApplication].delegate).roomList;
    
    __weak typeof(self) weakSelf = self;
    [self.dataRoomArray removeAllObjects];
    [self.disturbInfo.room_disturb_list enumerateObjectsUsingBlock:^(DoorDuRoomCallDisturbInfo * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [roomList enumerateObjectsUsingBlock:^(DoorDuRoomInfo * _Nonnull obj1, NSUInteger idx, BOOL * _Nonnull stop1) {
            if ([obj.room_id isEqualToString:obj1.room_number_id]) {//相等
                DDUserNoDisturbingTwoLayoutModel * layoutModel = [[DDUserNoDisturbingTwoLayoutModel alloc] initWithModel:obj roomInfo:obj1];
                [weakSelf.dataRoomArray addObject:layoutModel];
                *stop1 = YES;
            }
        }];
        //刷新
        if (idx == weakSelf.disturbInfo.room_disturb_list.count-1) {
            [weakSelf.tableView reloadData];
        }
    }];
    
    [self.tableView reloadData];
}

#pragma mark - tableView 代理

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (self.dataArray.count == 0) {
        return 0;
    }
    DDUserNoDisturbingOneLayoutModel * layoutModel = self.dataArray[0];
    if (layoutModel.statusBool) {//一键免打扰了，下面的就
        return 1;
    }
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        return self.dataArray.count;
    }
    if (section == 1) {
        return self.dataRoomArray.count;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        DDUserNoDisturbingOneTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"DDUserNoDisturbingOneTableViewCell" forIndexPath:indexPath];
        cell.layoutMoel = self.dataArray[indexPath.row];
        cell.setSwitch.tag = indexPath.row;
        //点击
        __weak typeof(self) weakSelf = self;
        cell.switchValueChangeBlock = ^(BOOL on, NSInteger row) {
            if (row == 0) {//一键设置免打扰
                if (on) {
                    [weakSelf _requestOnekeyDisturbAPPStatus:@"1" callStatus:@"1"];
                } else {
                    [weakSelf _requestOnekeyDisturbAPPStatus:@"0" callStatus:@"0"];
                }
            } else if (row == 1) {//app
                NSString * status = [NSString stringWithFormat:@"%d", !weakSelf.disturbInfo.app_status.boolValue];
                [weakSelf _requestOnekeyDisturbAPPStatus:status callStatus:weakSelf.disturbInfo.call_status];
            } else if (row == 2) {//电话
                NSString * status = [NSString stringWithFormat:@"%d", !weakSelf.disturbInfo.call_status.boolValue];
                [weakSelf _requestOnekeyDisturbAPPStatus:weakSelf.disturbInfo.app_status callStatus:status];
            }
        };
        
        // 返回cell之前重新刷新约束，重新计算高度
        [cell setNeedsUpdateConstraints];
        [cell updateConstraintsIfNeeded];
        return cell;
    }
    if (indexPath.section == 1) {
        DDUserNoDisturbingTwoTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"DDUserNoDisturbingTwoTableViewCell" forIndexPath:indexPath];
        cell.layoutModel = self.dataRoomArray[indexPath.row];
        
        // 返回cell之前重新刷新约束，重新计算高度
        [cell setNeedsUpdateConstraints];
        [cell updateConstraintsIfNeeded];
        return cell;
    }
    
    return nil;

}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    DDUserNoDisturbingHeaderFooterView * headerView = [tableView dequeueReusableHeaderFooterViewWithIdentifier:@"DDUserNoDisturbingHeaderFooterView"];
    if (section == 0) {
        headerView.titleString = @"一键设置";
    }
    if (section == 1) {
        headerView.titleString = @"选择要设置的面打扰小区";
    }
    
    [headerView setNeedsUpdateConstraints];
    [headerView updateConstraintsIfNeeded];
    return headerView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return CGFLOAT_MIN;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 1) {
        DDUserNoDisturbingSingleRoomViewController * vc = [[DDUserNoDisturbingSingleRoomViewController alloc] init];
        vc.layoutModel = self.dataRoomArray[indexPath.row];
        [self.navigationController pushViewController:vc animated:YES];
    }
}


#pragma mark - 界面不去
- (void)_configUI
{
    [self.view addSubview:self.tableView];
    [self.tableView registerClass:DDUserNoDisturbingTwoTableViewCell.class forCellReuseIdentifier:@"DDUserNoDisturbingTwoTableViewCell"];
    [self.tableView registerClass:DDUserNoDisturbingOneTableViewCell.class forCellReuseIdentifier:@"DDUserNoDisturbingOneTableViewCell"];
    [self.tableView registerClass:DDUserNoDisturbingHeaderFooterView.class forHeaderFooterViewReuseIdentifier:@"DDUserNoDisturbingHeaderFooterView"];
    /** 布局 tableView*/
    //上面top
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.topLayoutGuide attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
    //左边
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    //右边
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
    //底部
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.bottomLayoutGuide attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
    
}


#pragma mark - 懒加载
- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.backgroundColor = [UIColor colorWithRed:0.94 green:0.94 blue:0.96 alpha:1.00];
        _tableView.tableFooterView = [[UIView alloc]init];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        _tableView.translatesAutoresizingMaskIntoConstraints = NO;
        _tableView.rowHeight = UITableViewAutomaticDimension;
        _tableView.estimatedRowHeight = 60;
    }
    return _tableView;
}

- (NSMutableArray *)dataArray
{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}
- (NSMutableArray *)dataRoomArray
{
    if (!_dataRoomArray) {
        _dataRoomArray = [NSMutableArray array];
    }
    return _dataRoomArray;
}

- (void)dealloc
{
    NSLog(@"\ndealloc: %@\n",NSStringFromClass([self class]));
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
