//
//  DDUserNoDisturbingOneLayoutModel.h
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/30.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DDUserNoDisturbingOneLayoutModel : NSObject

//标题
@property (nonatomic, strong) NSString * titleString;

//描述
@property (nonatomic, strong) NSString * desString;

//开关状态
@property (nonatomic, assign) BOOL statusBool;

@end
