//
//  DDUserNoDisturbingTwoLayoutModel.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/30.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDUserNoDisturbingTwoLayoutModel.h"

@interface DDUserNoDisturbingTwoLayoutModel ()

@property (nonatomic, strong) DoorDuRoomInfo * roomInfo;

@end

@implementation DDUserNoDisturbingTwoLayoutModel

- (instancetype)initWithModel:(DoorDuRoomCallDisturbInfo *)model roomInfo:(DoorDuRoomInfo *)roomInfo
{
    self = [super init];
    if (self) {
        self.model = model;
        self.roomInfo = roomInfo;
        [self reloadData];
    }
    return self;
}

- (void)reloadData
{
    NSString * titleStr = [NSString stringWithFormat:@"%@%@%@%@",self.roomInfo.dep_name,self.roomInfo.building_name,self.roomInfo.unit_name,self.roomInfo.room_number];
    self.titleString = titleStr;
    
    /**APP呼叫一键免打扰；0-关闭、1-开启、2-夜间开启*/
    NSString * appStatus = @"";
    if (self.model.app_status.integerValue == 0) {
        appStatus = @"APP呼叫一键免打扰状态：关闭";
    } else if (self.model.app_status.integerValue == 1) {
        appStatus = @"APP呼叫一键免打扰状态：开启";
    } else if (self.model.app_status.integerValue == 2) {
        appStatus = @"APP呼叫一键免打扰状态：夜间开启";
    }
    
    /**呼叫转接免打扰；0-关闭、1-开启、2-夜间开启*/
    NSString * callStatus = @"";
    if (self.model.call_status.integerValue == 0) {
        callStatus = @"电话呼叫转接免打扰状态：关闭";
    } else if (self.model.call_status.integerValue == 1) {
        callStatus = @"电话呼叫转接免打扰状态：开启";
    } else if (self.model.call_status.integerValue == 2) {
        callStatus = @"电话呼叫转接免打扰状态：夜间开启";
    }
    self.desString = [NSString stringWithFormat:@"%@\n%@",appStatus,callStatus];
    
}

@end
