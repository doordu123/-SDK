//
//  DDUserNoDisturbingTwoTableViewCell.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/30.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDUserNoDisturbingTwoTableViewCell.h"

@interface DDUserNoDisturbingTwoTableViewCell ()

/** 标题 */
@property (nonatomic, strong) UILabel * titleLabel;

/** 描述 */
@property (nonatomic, strong) UILabel * desLabel;


@end

@implementation DDUserNoDisturbingTwoTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self _configUI];
    }
    return self;
}

- (void)setLayoutModel:(DDUserNoDisturbingTwoLayoutModel *)layoutModel
{
    _layoutModel = layoutModel;
    self.titleLabel.text = layoutModel.titleString;
    self.desLabel.text = layoutModel.desString;
}

#pragma mark - 界面布局
- (void)_configUI
{
    [self.contentView addSubview:self.titleLabel];
    [self.contentView addSubview:self.desLabel];
    self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    /** 布局 titleLabel */
    //上
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.titleLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeTop multiplier:1 constant:10]];
    //左
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.titleLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.titleLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    
    /** 布局 desLabel */
    //上
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.desLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.titleLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:10]];
    //左
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.desLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.desLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.titleLabel attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
    //下
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.desLabel attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeBottom multiplier:1 constant:-10]];
    
}

#pragma mark - 懒加载
/** 标题 */
- (UILabel *)titleLabel
{
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc] init];
        _titleLabel.numberOfLines = 0;
        _titleLabel.font = [UIFont systemFontOfSize:16];
        _titleLabel.textColor = [UIColor blackColor];
        _titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _titleLabel;
}
/** 描述 */
- (UILabel *)desLabel
{
    if (!_desLabel) {
        _desLabel = [[UILabel alloc] init];
        _desLabel.numberOfLines = 0;
        _desLabel.font = [UIFont systemFontOfSize:13];
        _desLabel.textColor = [UIColor lightGrayColor];
        _desLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _desLabel;
}


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
