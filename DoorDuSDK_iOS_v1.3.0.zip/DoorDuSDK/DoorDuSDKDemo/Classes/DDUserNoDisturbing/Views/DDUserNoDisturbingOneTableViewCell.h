//
//  DDUserNoDisturbingOneTableViewCell.h
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/30.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DDUserNoDisturbingOneLayoutModel.h"

@interface DDUserNoDisturbingOneTableViewCell : UITableViewCell

/** 设置打扰switch */
@property (nonatomic, strong) UISwitch * setSwitch;

@property (nonatomic, strong) DDUserNoDisturbingOneLayoutModel * layoutMoel;

@property (nonatomic, copy) void (^switchValueChangeBlock)(BOOL on,NSInteger row) ;

@end
