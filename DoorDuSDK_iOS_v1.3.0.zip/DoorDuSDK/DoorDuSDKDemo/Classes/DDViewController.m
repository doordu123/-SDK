//
//  DDViewController.m
//  DoorDuSDKDemo
//
//  Created by DoorDu on 2018/1/9.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDViewController.h"
#import "CommunityListViewController.h"
#import "DoorVideoChatViewController.h"
#import <DoorDuSDK/DoorDuSDK.h>
#import "AppDelegate.h"
#import "DDContactPropertyViewController.h"
#import "DDAuthListViewController.h"
#import "DDVisitorRecordViewController.h"
#import "DDEntityCardViewController.h"
#import "DDCommunityNoticeListViewController.h"
#import "DDCallTransferViewController.h"
#import "DDUserNoDisturbingViewController.h"
#import "DDKeySortViewController.h"
#import "DDActionSheet.h"
#import "DDAlertView.h"
#import "DDPasswordListViewController.h"
#import "DDSelfHelpAuthorizationViewController.h"
#import "DoorDuContactAddressServer.h"

@interface DDViewController ()<UITableViewDelegate, UITableViewDataSource>

// 小区信息
@property (nonatomic, strong) DoorDuRoomInfo *roomInfo;
@property (nonatomic, strong) DoorDuCommunityNotice *notice;
// 钥匙数据
@property (nonatomic, strong) DoorDuKeyList *keyList;
// 钥匙列表
@property (weak, nonatomic) IBOutlet UITableView *keyListView;

/** 用于蓝牙开门 */
@property (nonatomic, strong) DoorDuBLEPeripheralManager * peripheralManager;


@end

@implementation DDViewController

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.keyListView reloadData];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    if (@available(iOS 11.0, *)){
        [[UIScrollView appearance] setContentInsetAdjustmentBehavior:UIScrollViewContentInsetAdjustmentNever];
    } else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }
    
    // Do any additional setup after loading the view.
#pragma mark - 开启蓝牙监听
    self.peripheralManager = [DoorDuBLEPeripheralManager startBLEPeripheralObserver:^(DoorDuBLEPeripheralManagerState state) {
        if (state == DoorDuBLEPeripheralManagerStatePoweredOn) {
            [DDProgressHUD showCenterWithText:@"手机蓝牙可用" duration:1.5];
        } else {
            [DDProgressHUD showCenterWithText:@"手机蓝牙不可用" duration:1.5];
        }
    }];
    
    //  获取房产列表
    self.roomInfo = [self getRoomInfo];
    if (!self.roomInfo) {
        [self getCommunityList:nil];
    }else {
        __weak typeof(self) weakSelf = self;
        self.navigationItem.title = [NSString stringWithFormat:@"%@(%@)", self.roomInfo.dep_name, self.roomInfo.room_number];
        [DoorDuDataManager getUserKeyListWithRoomId:self.roomInfo.room_number_id completion:^(DoorDuKeyList *keyList, DoorDuError *error) {
            if (!error) {
                weakSelf.keyList = keyList;
                [weakSelf.keyListView reloadData];
            } else {
                [weakSelf.keyListView reloadData];
                [DDProgressHUD showCenterWithText:error.message duration:1.5];
            }
        }];
    }
    
    [self __getCallTransferMobileListData];
}

#pragma mark - 获取转接号码数据
- (void)__getCallTransferMobileListData
{
    // 获取呼叫转接号码
    [DoorDuDataManager getCallTransferMobileListWithCompletion:^(NSArray<NSString *> *mobileList, DoorDuError *error) {
        if (!error) {
            if (mobileList.count > 0) {
                // 写通讯录
                DoorDuContactAddressServer *addressServer = [[DoorDuContactAddressServer alloc] init];
                // 获取第三方app名称,用于显示号码名称
                NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
                NSString *appNameStr = [infoDictionary objectForKey:@"CFBundleDisplayName"];
                if (!appNameStr) {
                    appNameStr = @"来电呼叫";
                }
                [addressServer addMobileToContactWithFirstName:appNameStr isClear:NO mobiles:mobileList];
            }
        }
    }];
}


- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

// 获取小区列表
- (IBAction)getCommunityList:(id)sender {
    
    UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    UINavigationController *nav = [sb instantiateViewControllerWithIdentifier:@"CommunityListViewControllerID"];
    [self presentViewController:nav animated:YES completion:nil];
    
    CommunityListViewController *communityListVC = nav.viewControllers[0];
    __weak typeof(self) weakSelf = self;
    [communityListVC setDdCallBackReturnObjectDataBlock:^(id objc) {
        weakSelf.roomInfo = objc;
        weakSelf.navigationItem.title = [NSString stringWithFormat:@"%@(%@)", weakSelf.roomInfo.dep_name, weakSelf.roomInfo.room_number];
        [DoorDuDataManager getUserKeyListWithRoomId:weakSelf.roomInfo.room_number_id completion:^(DoorDuKeyList *keyList, DoorDuError *error) {
            if (!error) {
                weakSelf.keyList = keyList;
                [weakSelf.keyListView reloadData];
            } else {
                [weakSelf.keyListView reloadData];
                [DDProgressHUD showCenterWithText:error.message duration:1.5];
            }
        }];
    }];
}

- (DoorDuRoomInfo *)getRoomInfo
{
    if (!_roomInfo) {
        NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
        NSString *accountName = [userDefaults objectForKey:@"accountName"];
        NSData *data = [userDefaults objectForKey:accountName];
        _roomInfo = [NSKeyedUnarchiver unarchiveObjectWithData:data];
    }
    return _roomInfo;
}

- (void)setRoomInfo:(DoorDuRoomInfo *)roomInfo
{
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:roomInfo];
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *accountName = [userDefaults objectForKey:@"accountName"];
    [userDefaults setObject:data forKey:accountName];
    
    _roomInfo = roomInfo;
}

#pragma mark -- 获取密码开门
- (IBAction)getDoorPassword:(id)sender {
    
    [SVProgressHUD showWithStatus:@"申请密码开门..."];
    [DoorDuDataManager getDoorPasswordWithRoomId:self.roomInfo.room_number_id completion:^(DoorDuDoorPassword *doorPwd, DoorDuError *error) {
        
        [SVProgressHUD dismiss];
        if (!error) {
            [DDProgressHUD showCenterWithText:[NSString stringWithFormat:@"密码:%@, 过期时间:%@", doorPwd.password, doorPwd.expired_time] duration:2.0];
        }else {
            [DDProgressHUD showCenterWithText:[NSString stringWithFormat:@"密码申请失败 -- Reason:%@", error.message] duration:2.0];
        }
    }];
    
}

// 用户退出
- (IBAction)loginout:(id)sender {
    
    // 用户退出登录必须调用sdk退出接口，用来完成音视频资源清理
    [SVProgressHUD showWithStatus:@"清理音视频资源..."];
    [DoorDuDataManager loginoutWithCompletion:^(BOOL isSuccess, DoorDuError *error) {
        [SVProgressHUD dismiss];
        if (isSuccess) {
            [DDProgressHUD showCenterWithText:@"资源清理成功" duration:1.0];
            
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                AppDelegate *appDelegate =  (AppDelegate *)[UIApplication sharedApplication].delegate;
                [appDelegate logoutSuccess];
                // 清除缓存信息
                NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
                NSString *accountName = [userDefaults objectForKey:@"accountName"];
                [userDefaults setObject:nil forKey:@"accountName"];
                [userDefaults setObject:nil forKey:accountName];
                [userDefaults synchronize];
            });
        }else {
            [DDProgressHUD showCenterWithText:[NSString stringWithFormat:@"资源清理失败  -- Reason:%@",error.message] duration:1.5];
        }
    }];
}
#pragma mark - wifi 开门
- (IBAction)WifiOpenDoor:(UIButton *)sender {
    NSString *titleStr = sender.titleLabel.text;
    NSArray *components = [titleStr componentsSeparatedByString:@"-"];
    NSString *indexStr = components[1];
    
    DoorDuKeyInfo *keyInfo = self.keyList.list[[indexStr integerValue]];
    
    NSString *ssidStr = [keyInfo.ssid stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    if (ssidStr.length == 0) {
        [DDProgressHUD showCenterWithText:[NSString stringWithFormat:@"设备不支持Wifi热点"] duration:1.5];
        return;
    }
    
    DoorDuWifiOpenDoor *wifiOperator = [DoorDuWifiOpenDoor new];
    // 判断当前连接wifi热点是否为门禁机热点
    if (![[wifiOperator getSSID] isEqualToString:keyInfo.ssid]) {
        [DDProgressHUD showCenterWithText:[NSString stringWithFormat:@"请连接门禁机AP : %@, 密码:%@", keyInfo.ssid, keyInfo.ssid_pwd] duration:1.5];
        return;
    }
    
    [wifiOperator openDoorWithRoomId:self.roomInfo.room_number_id ssidKey:keyInfo.ssid_secretkey completion:^(BOOL isSuccess, DoorDuError *error) {
        if (isSuccess) {
            [DDProgressHUD showCenterWithText:@"WIFI开门成功" duration:1.5];
        }else {
            [DDProgressHUD showCenterWithText:[NSString stringWithFormat:@"WIFI开门失败! Reason -- %@", error.message] duration:1.5];
        }
    }];
}

// 查看门口视频
- (IBAction)VideoOfDoor:(UIButton *)sender {
    NSString *titleStr = sender.titleLabel.text;
    NSArray *components = [titleStr componentsSeparatedByString:@"-"];
    NSString *indexStr = components[1];
    
    DoorDuKeyInfo *keyInfo = self.keyList.list[[indexStr integerValue]];
    
    UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    DoorVideoChatViewController *videoChatVC = [sb instantiateViewControllerWithIdentifier:@"DoorVideoChatID"];
    
    videoChatVC.modalPresentationStyle = UIModalPresentationOverFullScreen;
    videoChatVC.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    
    videoChatVC.roomID = self.roomInfo.room_number_id;
    videoChatVC.doorID = keyInfo.door_id;
    videoChatVC.doorGuid = keyInfo.door_guid;
    videoChatVC.doorName = keyInfo.door_name;
    videoChatVC.doorCallerNo = keyInfo.door_sip_no;
    
    [self presentViewController:videoChatVC animated:YES completion:nil];
}

// 获取totp pin码
- (IBAction)getTOTPPin:(UIButton *)sender {
    NSString *titleStr = sender.titleLabel.text;
    NSArray *components = [titleStr componentsSeparatedByString:@"-"];
    NSString *indexStr = components[1];
    
    DoorDuKeyInfo *keyInfo = self.keyList.list[[indexStr integerValue]];
    
    if (keyInfo.is_support_token) {
        DoorDuTOTPOpenDoor *totpOpen = [DoorDuTOTPOpenDoor new];
        // 生成秘钥
        [totpOpen generateWithDoorDynamicKey:keyInfo.totp_token result:^(NSString *pinStr, NSUInteger lastSecond) {
            [DDProgressHUD showCenterWithText:[NSString stringWithFormat:@"pin: %@, 剩余时间:%ld", pinStr, lastSecond] duration:2.0];
        }];
    }
}

#pragma mark --
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.keyList.list.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"keyCell" forIndexPath:indexPath];
    
    DoorDuKeyInfo *keyInfo = self.keyList.list[indexPath.row];
    cell.textLabel.text = keyInfo.door_alias;
    
    UIButton *lookVideoBtn = [cell viewWithTag:1000];
    [lookVideoBtn setTitle:[NSString stringWithFormat:@"门口视频-%ld", indexPath.row] forState:UIControlStateNormal];
    
    UIButton *totpBtn = [cell viewWithTag:2000];
    [totpBtn setTitle:[NSString stringWithFormat:@"TOTP-%ld", indexPath.row] forState:UIControlStateNormal];
    // 判断门禁机是否支持动态密码
    totpBtn.enabled = keyInfo.is_support_token;
    
    UIButton *wifiBtn = [cell viewWithTag:3000];
    [wifiBtn setTitle:[NSString stringWithFormat:@"Wifi-%ld", indexPath.row] forState:UIControlStateNormal];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    DoorDuKeyInfo *keyInfo = self.keyList.list[indexPath.row];
    
    [SVProgressHUD showSuccessWithStatus:@"开门中..."];
//    [DoorDuDataManager openDoorWithRoomId:self.roomInfo.room_number_id doorId:keyInfo.door_id completion:^(BOOL isSuccess, DoorDuError *error) {
//        [SVProgressHUD dismiss];
//        if (isSuccess) {
//            [DDProgressHUD showCenterWithText:@"开门成功" duration:1.5];
//        }else {
//            NSString *errorMsg = [NSString stringWithFormat:@"开门失败---reason:%@", error.message];
//            [DDProgressHUD showCenterWithText:errorMsg duration:1.5];
//        }
//    }];
    
    [DoorDuDataManager openDoorWithRoomId:self.roomInfo.room_number_id doorId:keyInfo.door_id openType:@"2" completion:^(BOOL isSuccess, DoorDuError *error) {
        [SVProgressHUD dismiss];
        if (isSuccess) {
            [DDProgressHUD showCenterWithText:@"开门成功" duration:1.5];
        }else {
            NSString *errorMsg = [NSString stringWithFormat:@"开门失败---reason:%@", error.message];
            [DDProgressHUD showCenterWithText:errorMsg duration:1.5];
        }
    }];
}

#pragma mark - 获取密码开门--密码列表
- (IBAction)getPasswordListButtonClicked:(id)sender {
    
    DDPasswordListViewController * vc = [[DDPasswordListViewController alloc] init];
    vc.roomInfo = self.roomInfo;
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - 联系物业
- (IBAction)contactPropertyButtonClicked:(UIButton *)sender {
    DDContactPropertyViewController * vc = [[DDContactPropertyViewController alloc] init];
    vc.roomInfo = self.roomInfo;
    [self.navigationController pushViewController:vc animated:YES];
    
}

#pragma mark - 自助授权
- (IBAction)authManagerButtonClicked:(UIButton *)sender {
    if (self.roomInfo.autu_type.integerValue != 0) {
        [DDAlertView alertShowWithVC:self title:@"提示" message:@"只有业主可以查看和管理授权" otherButtonTitle:@[@"确定"] clickedBlock:^(NSInteger index) {
            
        }];
        return;
    }
    DDAuthListViewController * vc = [[DDAuthListViewController alloc] init];
    vc.roomInfo = self.roomInfo;
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - 访客留影
- (IBAction)visitorRecordButtonClicked:(UIButton *)sender {
    __weak typeof(self) weakSelf = self;
    [DDActionSheet showWithVC:self title:nil cancel:@"取消" message:nil otherButtonTitle:@[@"当前用户在这个房间的访客留影",@"当前房间的访客留影"] clickedBlock:^(NSInteger index) {
        DDVisitorRecordViewController * vc = [[DDVisitorRecordViewController alloc] init];
        vc.type = index;
        vc.roomInfo = weakSelf.roomInfo;
        [weakSelf.navigationController pushViewController:vc animated:YES];
    }];
}

#pragma mark - 实体卡
- (IBAction)entityCardButtonClicked:(UIButton *)sender {
    DDEntityCardViewController * vc = [[DDEntityCardViewController alloc] init];
    vc.roomInfo = self.roomInfo;
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - 小区公告
- (IBAction)communityNoticeButtonClicked:(UIButton *)sender {
    DDCommunityNoticeListViewController * vc = [[DDCommunityNoticeListViewController alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - 呼叫转接
- (IBAction)callTransferButtonClicked:(UIButton *)sender {
    DDCallTransferViewController * vc = [[DDCallTransferViewController alloc] init];
    vc.roomInfo = self.roomInfo;
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - 免打扰设置
- (IBAction)noDisturbingButtonClicked:(UIButton *)sender {
    
    DDUserNoDisturbingViewController * vc = [[DDUserNoDisturbingViewController alloc] init];
    vc.roomInfo = self.roomInfo;
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - 钥匙排序
- (IBAction)keySortButtonClicked:(UIButton *)sender {
    DDKeySortViewController * vc = [[DDKeySortViewController alloc] init];
    vc.keyList = self.keyList.list;
    vc.roomInfo = self.roomInfo;
    __weak typeof(self) weakSelf = self;
    vc.returnDataBlock = ^(NSArray<DoorDuKeyInfo *> *keyList) {
        weakSelf.keyList.list = keyList;
        [weakSelf.keyListView reloadData];
    };
    [self.navigationController pushViewController:vc animated:YES];
}
#pragma mark - 蓝牙开门
- (IBAction)bluetoothOpenDoorClicked:(UIButton *)sender {
    if (!self.keyList.isBluetooth) {
        [DDProgressHUD showCenterWithText:@"不支持蓝牙开门" duration:1.5];
        return;
    }
    AppDelegate *appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    /** 发送蓝牙广播 */
    [self.peripheralManager sendAdvertisingWithMobile:appDelegate.mobileNo nationCode:@"86" depID:self.roomInfo.dep_id timeInterval:1.0 stateBlock:^(DoorDuBLEPeripheralManagerAdvertisingState AdvertisingState) {
        if (AdvertisingState == DoorDuBLEPeripheralManagerAdvertisingStateSuccess) {
            [DDProgressHUD showCenterWithText:@"蓝牙广播发送--成功" duration:1.5];
        } else {
            [DDProgressHUD showCenterWithText:@"蓝牙广播失败，请检测蓝牙是否开启" duration:1.5];
            /** 提示是否开启蓝牙 */
            [DDAlertView alertShowWithVC:self title:@"蓝牙未开启" message:@"当前检测到您的蓝牙处于关闭状态是否开启蓝牙？" otherButtonTitle:@[@"取消",@"去设置"] clickedBlock:^(NSInteger index) {
                /** 蓝牙跳转设置 */
                NSString *settingUrlStr = @"";
                if (@available(iOS 10.0, *)) {
                    settingUrlStr = @"App-Prefs:root=Bluetooth";
                }else {
                    settingUrlStr = @"prefs:root=Bluetooth";
                }
                /** 进入蓝牙设置场景 */
                NSURL *settingUrl = [NSURL URLWithString:settingUrlStr];
                if ([[UIApplication sharedApplication] canOpenURL:settingUrl]) {
                    [[UIApplication sharedApplication] openURL:settingUrl];
                }
            }];
        }
    } completeBlock:^{
        [DDProgressHUD showCenterWithText:@"蓝牙开门广播发送--完成" duration:1.5];
    }];
}
- (IBAction)selfHelpAuthorizationClicked:(UIButton *)sender {
    DDSelfHelpAuthorizationViewController * vc = [[DDSelfHelpAuthorizationViewController alloc] init];
    vc.roomInfo = self.roomInfo;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
