//
//  DDCompleteIdentityTableViewCell.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/3/7.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDCompleteIdentityTableViewCell.h"

@interface DDCompleteIdentityTableViewCell ()

@end

@implementation DDCompleteIdentityTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self _configUI];
    }
    return self;
}

- (void)_configUI
{
    // 256 160
    [self.contentView addSubview:self.identifyCardFrontImageView];
    [self.contentView addSubview:self.identifyCardBehindImageView];
    [self.contentView addSubview:self.handCardImageView];
    
    CGFloat space = 20;
    CGFloat cardWidth = ([UIScreen mainScreen].bounds.size.width - space*3)/2.0;
    CGFloat cardHeight = cardWidth*0.625;
    
    self.identifyCardFrontImageView.frame = CGRectMake(space, space, cardWidth, cardHeight);
    
    self.identifyCardBehindImageView.frame = CGRectMake(space*2+cardWidth, space, cardWidth, cardHeight);
    
    self.handCardImageView.frame = CGRectMake(space, space*2+cardHeight, [UIScreen mainScreen].bounds.size.width - space*2, ([UIScreen mainScreen].bounds.size.width - space*2)*0.53);
    
    
}

- (void)_imageClicked:(UITapGestureRecognizer *)tap
{
    UIView * view = tap.view;
    if (self.returnDataBlock) {
        self.returnDataBlock(view.tag);
    }
}

/**身份证正面*/
- (UIImageView *)identifyCardFrontImageView
{
    if (!_identifyCardFrontImageView) {
        _identifyCardFrontImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"DDLandlordSelfHelpAuthorizationIdentifyCardFront"]];
        _identifyCardFrontImageView.userInteractionEnabled = YES;
        _identifyCardFrontImageView.tag = 1;
        UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(_imageClicked:)];
        [_identifyCardFrontImageView addGestureRecognizer:tap];
    }
    return _identifyCardFrontImageView;
}
/**身份证反面照片*/
- (UIImageView *)identifyCardBehindImageView
{
    if (!_identifyCardBehindImageView) {
        _identifyCardBehindImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"DDLandlordSelfHelpAuthorizationIdentifyCardBehind"]];
        _identifyCardBehindImageView.userInteractionEnabled = YES;
        _identifyCardBehindImageView.tag = 2;
        UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(_imageClicked:)];
        [_identifyCardBehindImageView addGestureRecognizer:tap];
    }
    return _identifyCardBehindImageView;
}

- (UIImageView *)handCardImageView
{
    if (!_handCardImageView) {
        _handCardImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"手持身份证"]];
        _handCardImageView.clipsToBounds = YES;
        _handCardImageView.contentMode = UIViewContentModeScaleAspectFit;
        _handCardImageView.userInteractionEnabled = YES;
        _handCardImageView.tag = 3;
        UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(_imageClicked:)];
        [_handCardImageView addGestureRecognizer:tap];
    }
    return _handCardImageView;
}

+ (CGFloat)cellHeight
{
    CGFloat cardWidth = ([UIScreen mainScreen].bounds.size.width - 20*3)/2.0;
    CGFloat cardHeight = cardWidth*0.625;
    
    
    return cardHeight + 80 +  ([UIScreen mainScreen].bounds.size.width - 20*2)*0.53;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
