//
//  DDCompleteIdentityTableViewCell.h
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/3/7.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DDCompleteIdentityTableViewCell : UITableViewCell

/**身份证正面*/
@property (nonatomic,strong) UIImageView * identifyCardFrontImageView;
/**身份证反面照片*/
@property (nonatomic,strong) UIImageView * identifyCardBehindImageView;
/**手持身份证照片*/
@property (nonatomic,strong) UIImageView * handCardImageView;

@property (nonatomic, strong) void (^returnDataBlock)(NSInteger tag);


+ (CGFloat)cellHeight;

@end
