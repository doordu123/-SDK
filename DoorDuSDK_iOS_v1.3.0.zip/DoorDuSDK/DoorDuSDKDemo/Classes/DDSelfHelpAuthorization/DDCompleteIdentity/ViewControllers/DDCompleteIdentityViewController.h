//
//  DDCompleteIdentityViewController.h
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/3/7.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DDCompleteIdentityViewController : UIViewController

/** 姓名 */
@property (nonatomic, strong) NSString * nameString;

/** 手机号 */
@property (nonatomic, strong) NSString * phoneString;

/** 自助登记卡状态,自助登录卡:1不开通，2申请开通 */
@property (nonatomic, assign) NSInteger  selfHelpStatus;

/** 城市列表 */
@property (nonatomic, strong) DoorDuEstateCity * city;

/** 小区列表 */
@property (nonatomic, strong) DoorDuEstateDepartment * department;

/** 楼栋单元 */
@property (nonatomic, strong) DoorDuEstateBuildingUnit * buildingUnit;

/** 房间列表 */
@property (nonatomic, strong) DoorDuEstateRoomNumber * roomNumber;


@end
