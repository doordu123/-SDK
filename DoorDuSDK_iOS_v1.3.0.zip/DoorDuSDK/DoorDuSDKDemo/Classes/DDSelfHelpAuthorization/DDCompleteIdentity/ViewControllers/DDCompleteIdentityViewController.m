//
//  DDCompleteIdentityViewController.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/3/7.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDCompleteIdentityViewController.h"
#import "DDCompleteIdentityTableViewCell.h"
#import "DDActionSheet.h"
#import "LHDCusstomCameraViewController.h"
#import "UIImage+scale.h"

@interface DDCompleteIdentityViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView * tableView;

/**身份证正面*/
@property (nonatomic, strong) UIImage * identifyCardFrontImage;

/**身份证反面照片*/
@property (nonatomic, strong) UIImage * identifyCardBehindImage;

/**手持身份证照片*/
@property (nonatomic, strong) UIImage * handCardImage;

@property (nonatomic, strong) NSArray * authTypeArray;//0业主，1家人，2租客，3临时客人

@property (nonatomic, assign) NSInteger authType;//授权身份(0:业主，1:家人，2:租客，3:临时客人)

/** 身份证正面信息 数据模型*/
@property (nonatomic, strong) DoorDuFaceplusplusIdentifyCardSideFront * cardFront;

/** 身份证反面信息 数据模型*/
@property (nonatomic, strong) DoorDuFaceplusplusIdentifyCardSideBack * cardBack;

/** 身份证正面图片 在多度服务器唯一标识符*/
@property (nonatomic, strong) NSString * cardFrontImageObjectKey;

/** 身份证反面图片 在多度服务器唯一标识符*/
@property (nonatomic, strong) NSString * cardBackImageObjectKey;

/** 手持身份证图片 在多度服务器唯一标识符*/
@property (nonatomic, strong) NSString * handCardImageObjectKey;


@end

@implementation DDCompleteIdentityViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if (@available(iOS 11.0, *)){
        [[UIScrollView appearance] setContentInsetAdjustmentBehavior:UIScrollViewContentInsetAdjustmentNever];
    } else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }

    self.authType = 1;
    self.authTypeArray = @[@"业主",@"家人",@"租客",@"临时客人"];
    self.identifyCardFrontImage = [UIImage imageNamed:@"DDLandlordSelfHelpAuthorizationIdentifyCardFront"];
    self.identifyCardBehindImage = [UIImage imageNamed:@"DDLandlordSelfHelpAuthorizationIdentifyCardBehind"];
    self.handCardImage = [UIImage imageNamed:@"手持身份证"];
    
    self.view.backgroundColor = [UIColor colorWithRed:0.94 green:0.94 blue:0.96 alpha:1.00];
    self.title = @"补全身份信息";
    UIBarButtonItem * rightItem = [[UIBarButtonItem alloc] initWithTitle:@"提交" style:UIBarButtonItemStylePlain target:self action:@selector(_submitClicked)];
    self.navigationItem.rightBarButtonItem = rightItem;
    
    [self _configUI];
}

#pragma mark - 数据交互
/** 提交自助授权 */
- (void)_requestSelfAuthApplyData
{
    __weak typeof(self) weakSelf = self;
    [SVProgressHUD showWithStatus:@"提交授权中..."];
    [DoorDuDataManager selfAuthApplyWithRoomNumberId:self.roomNumber.room_number_id
                                              cityId:self.city.city_id
                                               depId:self.department.dep_id
                                            realName:self.nameString
                                            mobileNo:self.phoneString
                                      selfHelpStatus:[NSString stringWithFormat:@"%ld",self.selfHelpStatus]
                                            authType:[NSString stringWithFormat:@"%ld",self.authType]
                                            cardImg1:self.cardFrontImageObjectKey
                                            cardImg2:self.cardBackImageObjectKey
                                            cardImg3:self.handCardImageObjectKey
                                              cardNo:self.cardFront.id_card_number
                                            cardName:self.cardFront.name
                                              nation:self.cardFront.race
                                             address:self.cardFront.address
                                          government:self.cardBack.issued_by
                                            validity:self.cardBack.valid_date
                                          nationCode:@"86"
                                          completion:^(BOOL isSuccess, DoorDuError *error) {
                                                  [SVProgressHUD dismiss];
                                                  if (isSuccess) {
                                                      [DDProgressHUD showCenterWithText:@"自助授权成功" duration:1.5];
                                                      [weakSelf.navigationController popToRootViewControllerAnimated:YES];
                                                  } else {
                                                      [DDProgressHUD showCenterWithText:error.message duration:1.5];
                                                  }
                                              }];
}

/** 检测并上传身份证正面照片 */
- (void)_requestetectionAndUploadIdentifyCardFrontImageData
{
    __weak typeof(self) weakSelf = self;
    NSData * imageData = [self.identifyCardFrontImage pressImage2DataWithScale:0.5];
    [SVProgressHUD showWithStatus:@"检测并上传身份证正面照片..."];
    [DoorDuDataManager detectionAndUploadIdentifyImageData:imageData realName:self.nameString uploadImageDataType:kDoorDuUploadImageDataIdentifyCardSideFrontType completion:^(DoorDuFaceplusplusIdentifyCardSideFront *cardFront, DoorDuFaceplusplusIdentifyCardSideBack *cardBack, NSString *imageObjectKey, DoorDuError *error) {
        [SVProgressHUD dismiss];
        if (!error) {
            weakSelf.cardFront = cardFront;
            weakSelf.cardFrontImageObjectKey = imageObjectKey;
            [DDProgressHUD showCenterWithText:@"检测并上传身份证正面照片成功" duration:1.5];
        } else {
            weakSelf.cardFront = nil;
            weakSelf.cardFrontImageObjectKey = nil;
            weakSelf.identifyCardFrontImage = [UIImage imageNamed:@"DDLandlordSelfHelpAuthorizationIdentifyCardFront"];
            [weakSelf.tableView reloadData];
            [DDProgressHUD showCenterWithText:error.message duration:1.5];
        }
    }];
}
/** 检测并上传身份证反面照片 */
- (void)_requestetectionAndUploadIdentifyCardBackImageData
{
    __weak typeof(self) weakSelf = self;
    [SVProgressHUD showWithStatus:@"检测并上传身份证反面照片..."];
    NSData * imageData = [self.identifyCardBehindImage pressImage2DataWithScale:0.5];
    [DoorDuDataManager detectionAndUploadIdentifyImageData:imageData realName:self.nameString uploadImageDataType:kDoorDuUploadImageDataIdentifyCardSideBackType completion:^(DoorDuFaceplusplusIdentifyCardSideFront *cardFront, DoorDuFaceplusplusIdentifyCardSideBack *cardBack, NSString *imageObjectKey, DoorDuError *error) {
        [SVProgressHUD dismiss];
        if (!error) {
            weakSelf.cardBack = cardBack;
            weakSelf.cardBackImageObjectKey = imageObjectKey;
            [DDProgressHUD showCenterWithText:@"检测并上传身份证反面照片成功" duration:1.5];
        } else {
            weakSelf.cardBack = nil;
            weakSelf.cardBackImageObjectKey = nil;
            weakSelf.identifyCardBehindImage = [UIImage imageNamed:@"DDLandlordSelfHelpAuthorizationIdentifyCardBehind"];
            [weakSelf.tableView reloadData];
            [DDProgressHUD showCenterWithText:error.message duration:1.5];
        }
    }];
}
/** 上传手持照片 */
- (void)_requestetectionAndUploadIdentifyCardHandCardData
{
    __weak typeof(self) weakSelf = self;
    [SVProgressHUD showWithStatus:@"上传手持照片..."];
    NSData * imageData = [self.handCardImage pressImage2DataWithScale:0.5];
    [DoorDuDataManager detectionAndUploadIdentifyImageData:imageData realName:self.nameString uploadImageDataType:kDoorDuUploadImageDataHandIdentifyCardPictureType completion:^(DoorDuFaceplusplusIdentifyCardSideFront *cardFront, DoorDuFaceplusplusIdentifyCardSideBack *cardBack, NSString *imageObjectKey, DoorDuError *error) {
        [SVProgressHUD dismiss];
        if (!error) {
            weakSelf.handCardImageObjectKey = imageObjectKey;
            [DDProgressHUD showCenterWithText:@"上传手持照片成功" duration:1.5];
        } else {
            weakSelf.handCardImageObjectKey = nil;
            weakSelf.handCardImage = [UIImage imageNamed:@"手持身份证"];
            [weakSelf.tableView reloadData];
            [DDProgressHUD showCenterWithText:error.message duration:1.5];
        }
    }];
}

#pragma mark - 点击事件
/** 提交 */
- (void)_submitClicked
{
    if (!self.cardFront) {
        [DDProgressHUD showCenterWithText:@"请上传身份证正面照片" duration:1.5];
        return;
    }
    if (!self.cardBack) {
        [DDProgressHUD showCenterWithText:@"请上传身份证反面照片" duration:1.5];
        return;
    }
    if (!self.handCardImageObjectKey) {
        [DDProgressHUD showCenterWithText:@"请上传手持身份证照片" duration:1.5];
        return;
    }
    [self _requestSelfAuthApplyData];
}
/** 点击身份证正面照片 */
- (void)_identifyCardFrontImageClicked
{
    LHDCusstomCameraViewController * vc = [[LHDCusstomCameraViewController alloc] init];
    vc.fromeViewController = self;
    __weak typeof(self) weakSelf = self;
    [vc cusstomCameraGetPhotoImageBlock:^(LHDCusstomCameraViewController *cameraVC, UIImage *image) {
        weakSelf.identifyCardFrontImage = image;
        [weakSelf.tableView reloadData];
        [weakSelf _requestetectionAndUploadIdentifyCardFrontImageData];
    }];
    [vc show];
}
/** 点击身份证反面照片 */
- (void)_identifyCardBehindImageClicked
{
    LHDCusstomCameraViewController * vc = [[LHDCusstomCameraViewController alloc] init];
    vc.fromeViewController = self;
    __weak typeof(self) weakSelf = self;
    [vc cusstomCameraGetPhotoImageBlock:^(LHDCusstomCameraViewController *cameraVC, UIImage *image) {
        weakSelf.identifyCardBehindImage = image;
        [weakSelf.tableView reloadData];
        [weakSelf _requestetectionAndUploadIdentifyCardBackImageData];
    }];
    [vc show];
}
/** 点击身份证手持照片 */
- (void)_handCardImageClicked
{
    LHDCusstomCameraViewController * vc = [[LHDCusstomCameraViewController alloc] init];
    vc.fromeViewController = self;
    __weak typeof(self) weakSelf = self;
    [vc cusstomCameraGetPhotoImageBlock:^(LHDCusstomCameraViewController *cameraVC, UIImage *image) {
        weakSelf.handCardImage = image;
        [weakSelf.tableView reloadData];
        [weakSelf _requestetectionAndUploadIdentifyCardHandCardData];
    }];
    [vc show];
}

#pragma mark - 代理方法
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        return 10;
    } else if (section == 1) {
        return 40;
    } else if (section == 2) {
        return CGFLOAT_MIN;
    }
    return CGFLOAT_MIN;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return CGFLOAT_MIN;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UITableViewHeaderFooterView * view = [tableView dequeueReusableHeaderFooterViewWithIdentifier:@"UITableViewHeaderFooterView"];
    if (!view) {
        view = [[UITableViewHeaderFooterView alloc] initWithReuseIdentifier:@"UITableViewHeaderFooterView"];
    }
    view.backgroundColor = [UIColor clearColor];
    if (section == 0) {
        view.textLabel.text = @"";
    } else if (section == 1) {
        view.textLabel.text = @"您的信息仅供审核，不做其他用途，我们将为您保密";
    } else if (section == 2) {
        view.textLabel.text = @"";
    }
    return view;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    UITableViewHeaderFooterView * view = [tableView dequeueReusableHeaderFooterViewWithIdentifier:@"UITableViewHeaderFooterView"];
    if (!view) {
        view = [[UITableViewHeaderFooterView alloc] initWithReuseIdentifier:@"UITableViewHeaderFooterView"];
    }
    view.backgroundColor = [UIColor clearColor];
    view.textLabel.text = @"";
    return view;
}



- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        return 66;
    } else if (indexPath.section == 1) {
        return [DDCompleteIdentityTableViewCell cellHeight];
    } else if (indexPath.section == 3) {
        return 120;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (indexPath.section == 0) {
        /**  身份选择 */
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"tableView"];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"tableView"];
        }
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        cell.textLabel.text = @"选择申请身份";
        cell.detailTextLabel.text = self.authTypeArray[self.authType];
        return cell;
        
    } else if (indexPath.section == 1) {
        /** 身份证信息 */
        DDCompleteIdentityTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"tableView1"];
        if (!cell) {
            cell = [[DDCompleteIdentityTableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"tableView1"];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
        }
        cell.identifyCardFrontImageView.image = self.identifyCardFrontImage;
        cell.identifyCardBehindImageView.image = self.identifyCardBehindImage;
        cell.handCardImageView.image = self.handCardImage;
        __weak typeof(self) weakSelf = self;
        cell.returnDataBlock = ^(NSInteger tag) {
            if (tag == 1) {
                [weakSelf _identifyCardFrontImageClicked];
            }  else if (tag == 2) {
                [weakSelf _identifyCardBehindImageClicked];
            }  else if (tag == 3) {
                [weakSelf _handCardImageClicked];
            }
        };
        return cell;
    } else if (indexPath.section == 2) {
        /** 照片要求展示 */
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"tableView2"];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"tableView2"];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            UILabel * label = [[UILabel alloc] initWithFrame:CGRectMake(0, 10, self.view.frame.size.width, [UIFont systemFontOfSize:13].lineHeight)];
            label.font = [UIFont systemFontOfSize:13];
            label.textColor = [UIColor colorWithRed:0.62 green:0.61 blue:0.62 alpha:1.00];
            label.text = @"———————   拍摄照片要求   ———————";
            label.textAlignment = NSTextAlignmentCenter;
            [cell.contentView addSubview:label];
            
            /**添加照片要求图片*/
            NSArray * photographDemandImageArray = @[@"DDLandlordSelfHelpAuthorizationPhotoRequireOne",@"DDLandlordSelfHelpAuthorizationPhotoRequireTwo",@"DDLandlordSelfHelpAuthorizationPhotoRequireThree",@"DDLandlordSelfHelpAuthorizationPhotoRequireFour"];
            CGFloat photographDemandImageWidth = self.view.frame.size.width/4.0;
            for (NSInteger i = 0; i < photographDemandImageArray.count; i++) {
                UIImageView * imageView  = [[UIImageView alloc] initWithFrame:CGRectMake(i*photographDemandImageWidth, [UIFont systemFontOfSize:13].lineHeight + 20, photographDemandImageWidth, 60)];
                imageView.clipsToBounds = YES;
                imageView.contentMode = UIViewContentModeScaleAspectFit;
                imageView.image = [UIImage imageNamed:photographDemandImageArray[i]];
                [cell.contentView addSubview:imageView];
            }
        }
        
        return cell;
    }
    return nil;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 0 && indexPath.section == 0) {
        __weak typeof(self) weakSelf = self;
        [DDActionSheet showWithVC:self title:@"身份选择" cancel:@"取消" message:nil otherButtonTitle:self.authTypeArray clickedBlock:^(NSInteger index) {
            weakSelf.authType = index;
            [weakSelf.tableView reloadData];
        }];
    }
}

#pragma mark - 界面布局
- (void)_configUI
{
    [self.view addSubview:self.tableView];
    /** tableView 布局 */
    //top
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.topLayoutGuide attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
    //左
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    //右
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
    //下面
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.bottomLayoutGuide attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
    
}
#pragma mark -懒加载
- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.translatesAutoresizingMaskIntoConstraints = NO;
        _tableView.backgroundColor = [UIColor colorWithRed:0.94 green:0.94 blue:0.96 alpha:1.00];
        _tableView.delegate = self;
        _tableView.bounces = NO;
        _tableView.dataSource = self;
        _tableView.tableFooterView = [[UIView alloc] init];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLineEtched;
    }
    return _tableView;
}

- (void)dealloc
{
    NSLog(@"\ndealloc: %@\n",NSStringFromClass([self class]));
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
