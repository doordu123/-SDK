//
//  DDCompleteInformationViewController.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/3/6.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDCompleteInformationViewController.h"
#import "DDCompleteInformationTableViewCell.h"
#import "DDInputTextViewController.h"
#import "DDCompleteIdentityViewController.h"
#import "DDActionSheet.h"

@interface DDCompleteInformationViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView * tableView;

/** 姓名 */
@property (nonatomic, strong) NSString * nameString;

/** 手机号 */
@property (nonatomic, strong) NSString * phoneString;

/** 当前选中的手机号 */
@property (nonatomic, strong) NSString * selectedMobile;

/** 当前选中的手机号 */
@property (nonatomic, strong) NSString * inputString;

/** 自助登记卡状态,自助登录卡:1不开通，2申请开通 */
@property (nonatomic, assign) NSInteger  selfHelpStatus;

@end

@implementation DDCompleteInformationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if (@available(iOS 11.0, *)){
        [[UIScrollView appearance] setContentInsetAdjustmentBehavior:UIScrollViewContentInsetAdjustmentNever];
    } else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }

    self.view.backgroundColor = [UIColor colorWithRed:0.94 green:0.94 blue:0.96 alpha:1.00];
    self.title = @"补全信息";
    self.selfHelpStatus = 2;
    [self _configUI];
    self.nameString = @"";
    self.phoneString = @"";
    UIBarButtonItem * rightItem = [[UIBarButtonItem alloc] initWithTitle:@"提交" style:UIBarButtonItemStylePlain target:self action:@selector(_submitClicked)];
    self.navigationItem.rightBarButtonItem = rightItem;

}

#pragma mark - 点击事件
/** 提交 */
- (void)_submitClicked
{
    if (self.nameString.length == 0) {
        [DDProgressHUD showCenterWithText:@"请输入姓名" duration:1.5];
        return;
    }
    if (self.phoneString.length == 0) {
        [DDProgressHUD showCenterWithText:@"请输入手机号" duration:1.5];
        return;
    }
    
    if (self.ownerMobileArray.count > 0) {
        if (![[self.selectedMobile substringFromIndex:7] isEqualToString:self.inputString]) {
            [DDProgressHUD showCenterWithText:@"业主手机号码不匹配" duration:1.5];
            return;
        }
    }
    DDCompleteIdentityViewController * vc = [[DDCompleteIdentityViewController alloc] init];
    vc.city = self.city;
    vc.department = self.department;
    vc.buildingUnit = self.buildingUnit;
    vc.roomNumber = self.roomNumber;
    vc.nameString = self.nameString;
    vc.phoneString = self.phoneString;
    vc.selfHelpStatus = self.selfHelpStatus;
    [self.navigationController pushViewController:vc animated:YES];
    
}

#pragma mark - tableView 代理

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (self.ownerMobileArray.count == 0) {
        return 1;
    }
    return 2;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        return 40;
    }else if (section == 1) {
        return 40;
    }
    return CGFLOAT_MIN;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    if (section == 0) {
        return CGFLOAT_MIN;
    }else if (section == 1) {
        return 40;
    }
    return CGFLOAT_MIN;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UITableViewHeaderFooterView * view = [tableView dequeueReusableHeaderFooterViewWithIdentifier:@"UITableViewHeaderFooterView"];
    if (!view) {
        view = [[UITableViewHeaderFooterView alloc] initWithReuseIdentifier:@"UITableViewHeaderFooterView"];
    }
    view.backgroundColor = [UIColor clearColor];
    if (section == 0) {
        view.textLabel.text = @"选择房屋信息";
    } else if (section == 1) {
        view.textLabel.text = @"补齐业主预留的手机号后4位";
    }
    return view;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    UITableViewHeaderFooterView * view = [tableView dequeueReusableHeaderFooterViewWithIdentifier:@"UITableViewHeaderFooterView"];
    if (!view) {
        view = [[UITableViewHeaderFooterView alloc] initWithReuseIdentifier:@"UITableViewHeaderFooterView"];
    }
    view.backgroundColor = [UIColor clearColor];
    if (section == 0) {
        view.textLabel.text = @"";
    } else if (section == 1) {
        view.textLabel.text = @"如业主已更换手机，需业主前往物业管理处更新";
    }
    return view;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        return 3;
    } else if (section == 1) {
        return 1;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (indexPath.section == 0) {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"tableView"];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"tableView"];
        }
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        if (indexPath.row == 0) {
            cell.textLabel.text = @"真实姓名";
            cell.detailTextLabel.text = self.nameString;
        } else if (indexPath.row == 1) {
            cell.textLabel.text = @"手机号码";
            cell.detailTextLabel.text = self.phoneString;
        } else if (indexPath.row == 2) {
            cell.textLabel.text = @"自助登记卡（身份证卡）";
            /** 自助登记卡状态,自助登录卡:1不开通，2申请开通 */
            cell.detailTextLabel.text = [@[@"不开通",@"申请开通"] objectAtIndex:self.selfHelpStatus-1];;
        }
        return cell;
    } else if (indexPath.section == 1) {
        DDCompleteInformationTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"DDCompleteInformationTableViewCell"];
        if (!cell) {
            cell = [[DDCompleteInformationTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"DDCompleteInformationTableViewCell"];
        }
        cell.ownerMobileArray = self.ownerMobileArray;
        
        __weak typeof(self) weakSelf = self;
        cell.returnDataBlock = ^(NSString *selectedMobile, NSString *inputString) {
            weakSelf.selectedMobile = selectedMobile;
            weakSelf.inputString = inputString;
        };
        return cell;
    }
    return nil;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {//输入姓名
            DDInputTextViewController * vc = [[DDInputTextViewController alloc] init];
            vc.title = @"请输入真实姓名";
            vc.text = self.nameString;
            __weak typeof(self) weakSelf = self;
            vc.returnDataBlock = ^(NSString *inputString) {
                weakSelf.nameString = inputString;
                [weakSelf.tableView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationNone];
            };
            [self.navigationController pushViewController:vc animated:YES];
        }
        if (indexPath.row == 1) {//输入手机号
            DDInputTextViewController * vc = [[DDInputTextViewController alloc] init];
            vc.title = @"请输入手机号";
            vc.text = self.phoneString;
            vc.keyboardType = UIKeyboardTypeNumberPad;
            __weak typeof(self) weakSelf = self;
            vc.returnDataBlock = ^(NSString *inputString) {
                weakSelf.phoneString = inputString;
                [weakSelf.tableView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationNone];
            };
            [self.navigationController pushViewController:vc animated:YES];
        }
        if (indexPath.row == 2) {
            __weak typeof(self) weakSelf = self;
            [DDActionSheet showWithVC:self title:@"自助登记卡状态选择（身份证）" cancel:@"取消" message:nil otherButtonTitle:@[@"不开通",@"申请开通"] clickedBlock:^(NSInteger index) {
                weakSelf.selfHelpStatus = index+1;
                [weakSelf.tableView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationNone];
            }];
        }
    }
}

#pragma mark - 界面布局
- (void)_configUI
{
    [self.view addSubview:self.tableView];
    /** tableView 布局 */
    //top
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.topLayoutGuide attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
    //左
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    //右
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
    //下面
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.bottomLayoutGuide attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
    
}

#pragma mark -懒加载
- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.translatesAutoresizingMaskIntoConstraints = NO;
        _tableView.backgroundColor = [UIColor colorWithRed:0.94 green:0.94 blue:0.96 alpha:1.00];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.bounces = NO;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLineEtched;
        _tableView.rowHeight = [DDCompleteInformationTableViewCell cellHeight];
    }
    return _tableView;
}

- (void)dealloc
{
    NSLog(@"\ndealloc: %@\n",NSStringFromClass([self class]));
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
