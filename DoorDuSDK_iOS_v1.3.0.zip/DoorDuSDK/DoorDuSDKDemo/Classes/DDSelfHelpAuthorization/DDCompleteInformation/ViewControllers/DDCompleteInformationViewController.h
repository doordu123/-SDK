//
//  DDCompleteInformationViewController.h
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/3/6.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import <UIKit/UIKit.h>

/** 补全信息 */
@interface DDCompleteInformationViewController : UIViewController

/** 城市列表 */
@property (nonatomic, strong) DoorDuEstateCity * city;

/** 小区列表 */
@property (nonatomic, strong) DoorDuEstateDepartment * department;

/** 楼栋单元 */
@property (nonatomic, strong) DoorDuEstateBuildingUnit * buildingUnit;

/** 房间列表 */
@property (nonatomic, strong) DoorDuEstateRoomNumber * roomNumber;

/** 业主手机号 */
@property (nonatomic, strong) NSArray * ownerMobileArray;

@end
