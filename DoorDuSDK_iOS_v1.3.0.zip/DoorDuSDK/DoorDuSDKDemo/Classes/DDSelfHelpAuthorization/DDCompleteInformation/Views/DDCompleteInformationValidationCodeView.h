//
//  DDCompleteInformationValidationCodeView.h
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/3/6.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DDCompleteInformationValidationCodeView : UIView

@property (nonatomic, strong) void (^returnDataBlock)(NSString * inputString);

- (instancetype)initWithFrame:(CGRect)frame codeNumber:(NSInteger)codeNumber;

- (instancetype)initWithFrame:(CGRect)frame codeNumber:(NSInteger)codeNumber horizontalLineColor:(UIColor *)horizontalLineColor verticalLineColor:(UIColor *)verticalLineColor;

/** 重置 */
- (void)reset;

@end
