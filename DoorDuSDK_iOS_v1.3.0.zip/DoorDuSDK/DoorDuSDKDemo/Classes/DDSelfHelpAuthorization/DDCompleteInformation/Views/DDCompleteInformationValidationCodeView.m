//
//  DDCompleteInformationValidationCodeView.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/3/6.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDCompleteInformationValidationCodeView.h"

@interface DDCompleteInformationValidationCodeView ()<UITextFieldDelegate>

@property (nonatomic, assign) NSInteger codeNumber;


/* 输入文本框 **/
@property (nonatomic, strong) UITextField *codeTextField;

/** 存放标签 */
@property (nonatomic, strong) NSMutableArray * labelArray;

/** 横线颜色 */
@property (nonatomic, strong) UIColor * horizontalLineColor;

/** 垂直颜色 */
@property (nonatomic, strong) UIColor * verticalLineColor;

@end

@implementation DDCompleteInformationValidationCodeView

- (instancetype)initWithFrame:(CGRect)frame codeNumber:(NSInteger)codeNumber horizontalLineColor:(UIColor *)horizontalLineColor verticalLineColor:(UIColor *)verticalLineColor
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        
        self.codeNumber = codeNumber;
        
        self.horizontalLineColor = horizontalLineColor;
        
        self.verticalLineColor = verticalLineColor;
        
        [self _configSubViews];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame codeNumber:(NSInteger)codeNumber
{
    self = [self initWithFrame:frame codeNumber:codeNumber horizontalLineColor:[UIColor colorWithRed:0.76 green:0.76 blue:0.77 alpha:1.00] verticalLineColor:[UIColor colorWithRed:0.76 green:0.76 blue:0.77 alpha:1.00]];
    return self;
}

- (void)_configSubViews
{
    CGFloat labelWidth = self.codeTextField.frame.size.width / self.codeNumber;
    for (int i = 0; i < self.codeNumber; i++) {
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(i*labelWidth, 0, labelWidth, self.frame.size.height)];
        [self addSubview:label];
        label.text = @"*";
        label.textAlignment = NSTextAlignmentCenter;
        [self.labelArray addObject:label];
        
        UIView * verticalLineView = [[UIView alloc] initWithFrame:CGRectMake(i*labelWidth, 0, 0.5, self.frame.size.height)];
        verticalLineView.backgroundColor = self.verticalLineColor;
        [self addSubview:verticalLineView];
    }
    UIView * verticalLineView = [[UIView alloc] initWithFrame:CGRectMake(self.codeNumber*labelWidth, 0, 0.5, self.frame.size.height)];
    verticalLineView.backgroundColor = self.verticalLineColor;
    [self addSubview:verticalLineView];
    
    UIView * horizontalLineTopView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, 0.5)];
    horizontalLineTopView.backgroundColor = self.horizontalLineColor;
    [self addSubview:horizontalLineTopView];
    
    UIView * horizontalLineBottomView = [[UIView alloc] initWithFrame:CGRectMake(0, self.frame.size.height-0.5, self.frame.size.width, 0.5)];
    horizontalLineBottomView.backgroundColor = self.horizontalLineColor;
    [self addSubview:horizontalLineBottomView];

    
}

- (void)textFieldDidChange:(UITextField *)textField {
    NSInteger i = textField.text.length;
    if (i == 0) {
        ((UILabel *)[self.labelArray objectAtIndex:0]).text = @"*";
    } else {
        ((UILabel *)[self.labelArray objectAtIndex:i - 1]).text = [NSString stringWithFormat:@"%C", [textField.text characterAtIndex:i - 1]];
        if (self.codeNumber > i) {
            ((UILabel *)[self.labelArray objectAtIndex:i]).text = @"*";
        }
    }
    if (self.returnDataBlock) {
        self.returnDataBlock(textField.text);
    }
}

/** 重置 */
- (void)reset
{
    self.codeTextField.text = @"";
    for (UILabel * label in self.labelArray) {
        label.text = @"*";
    }
}

#pragma mark - UITextFieldDelegate
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    if ([string isEqualToString:@"\n"]) {
        [textField resignFirstResponder];
        return NO;
    } else if (string.length == 0) {
        return YES;
    } else if (textField.text.length >= self.codeNumber) {
        return NO;
    } else {
        return YES;
    }
}

#pragma mark - 懒加载
- (UITextField *)codeTextField {
    if (!_codeTextField) {
        _codeTextField = [[UITextField alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
        _codeTextField.backgroundColor = [UIColor clearColor];
        _codeTextField.textColor = [UIColor clearColor];
        _codeTextField.tintColor = [UIColor clearColor];
        _codeTextField.delegate = self;
        _codeTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;
        _codeTextField.keyboardType = UIKeyboardTypeNumberPad;
        _codeTextField.layer.borderColor = [[UIColor grayColor] CGColor];
        [_codeTextField addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
        [self addSubview:_codeTextField];
    }
    return _codeTextField;
}

- (NSMutableArray *)labelArray {
    if (!_labelArray) {
        _labelArray = [NSMutableArray array];
    }
    return _labelArray;
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
