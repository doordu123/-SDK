//
//  DDCompleteInformationTableViewCell.h
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/3/6.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DDCompleteInformationTableViewCell : UITableViewCell

/** 业主手机号 */
@property (nonatomic, strong) NSArray * ownerMobileArray;

@property (nonatomic, strong) void (^returnDataBlock)(NSString * selectedMobile,NSString * inputString);

+ (CGFloat)cellHeight;

@end
