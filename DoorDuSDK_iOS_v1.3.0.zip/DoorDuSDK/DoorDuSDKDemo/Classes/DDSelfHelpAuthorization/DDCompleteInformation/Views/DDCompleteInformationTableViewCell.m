//
//  DDCompleteInformationTableViewCell.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/3/6.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDCompleteInformationTableViewCell.h"
#import "DDCompleteInformationValidationCodeView.h"

@interface DDCompleteInformationTableViewCell ()

/** 手机号 */
@property (nonatomic, strong) UILabel * mobileLabel;

/** 验证码 */
@property (nonatomic, strong) DDCompleteInformationValidationCodeView * codeView;

/** 换一个 */
@property (nonatomic, strong) UIButton * exchangeButton;

/** 当前选中的手机号 */
@property (nonatomic, strong) NSString * selectedMobile;

/** 当前第几个,默认0 */
@property (nonatomic, assign) NSInteger selectedIndex;

@end

@implementation DDCompleteInformationTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self _configUI];
    }
    return self;
}

#pragma mark - 界面布局
- (void)_configUI
{
    [self.contentView addSubview:self.mobileLabel];
    [self.contentView addSubview:self.codeView];
    [self.contentView addSubview:self.exchangeButton];
    self.selectedMobile = 0;
    __weak typeof(self) weakSelf = self;
    self.codeView.returnDataBlock = ^(NSString *inputString) {
        if (weakSelf.returnDataBlock) {
            weakSelf.returnDataBlock(weakSelf.selectedMobile, inputString);
        }
    };
    
}

/** 换一个点击事件 */
- (void)_exchangeButtonClicked
{
    if (self.selectedIndex == self.ownerMobileArray.count-1) {
        self.selectedIndex = 0;
    } else {
        self.selectedIndex +=1 ;
    }
    [self.codeView reset];
    self.selectedMobile = self.ownerMobileArray[self.selectedIndex];
    if (self.returnDataBlock) {
        self.returnDataBlock(self.selectedMobile, @"");
    }
    self.mobileLabel.text = [self.selectedMobile substringToIndex:7];
}

- (void)setOwnerMobileArray:(NSArray *)ownerMobileArray
{
    _ownerMobileArray = ownerMobileArray;
    [self.codeView reset];
    self.selectedMobile = ownerMobileArray[0];
    self.mobileLabel.text = [self.selectedMobile substringToIndex:7];
    if (ownerMobileArray.count > 1) {
        self.exchangeButton.hidden = NO;
    } else {
        self.exchangeButton.hidden = YES;
    }
    if (self.returnDataBlock) {
        self.returnDataBlock(self.selectedMobile, @"");
    }
}

#pragma mark - 懒加载
- (UILabel *)mobileLabel
{
    if (!_mobileLabel) {
        CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
        _mobileLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, screenWidth*0.3, [self.class cellHeight])];
        _mobileLabel.font = [UIFont systemFontOfSize:15];
        _mobileLabel.textColor = [UIColor blackColor];
        _mobileLabel.textAlignment = NSTextAlignmentCenter;
        _mobileLabel.text = @"1369334";
    }
    return _mobileLabel;
}

- (DDCompleteInformationValidationCodeView *)codeView
{
    if (!_codeView) {
        CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
        _codeView = [[DDCompleteInformationValidationCodeView alloc] initWithFrame:CGRectMake(screenWidth*0.3, 0, screenWidth*0.4, [self.class cellHeight]) codeNumber:4 horizontalLineColor:[UIColor clearColor] verticalLineColor:[UIColor colorWithRed:0.91 green:0.90 blue:0.92 alpha:1.00]];
    }
    return _codeView;
}

- (UIButton *)exchangeButton
{
    if (!_exchangeButton) {
        _exchangeButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_exchangeButton setTitle:@"换一个" forState:UIControlStateNormal];
        [_exchangeButton setTitleColor:[UIColor colorWithRed:0.49 green:0.74 blue:0.20 alpha:1.00] forState:UIControlStateNormal];
        _exchangeButton.titleLabel.font = [UIFont systemFontOfSize:18];
        CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
        _exchangeButton.frame = CGRectMake(screenWidth*0.7, 0, screenWidth*0.3, [self.class cellHeight]);
        [_exchangeButton addTarget:self action:@selector(_exchangeButtonClicked) forControlEvents:UIControlEventTouchUpInside];
    }
    return _exchangeButton;
}

+ (CGFloat)cellHeight
{
    return 60.0;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
