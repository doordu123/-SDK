//
//  DDSelfHelpAuthorizationViewController.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/3/5.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDSelfHelpAuthorizationViewController.h"
#import "DDCityViewController.h"
#import "DDDepartmentViewController.h"
#import "DDBuildingUnitViewController.h"
#import "DDCompleteInformationViewController.h"
#import "DDSelfHelpAuthorizationListViewController.h"
#import "DDSearchController.h"
#import "DDSearchController.h"
#import "DDSearchResultTableViewController.h"

@interface DDSelfHelpAuthorizationViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView * tableView;

/** 下一步按钮 */
@property (nonatomic, strong) UIButton * nextButton;

/** 描述标签 */
@property (nonatomic, strong) UILabel * desLabel;

/** 保存搜索结果 */
@property (nonatomic, strong) NSMutableArray * searchResultDataArray;

/**搜索结果展示页*/
@property (nonatomic,strong) DDSearchResultTableViewController * resultViewController;

/**搜索框*/
@property (nonatomic,strong) DDSearchController *  searchController;

@end

@implementation DDSelfHelpAuthorizationViewController

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.tableView reloadData];
    [self _reloadNextButtonState];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if (@available(iOS 11.0, *)){
        [[UIScrollView appearance] setContentInsetAdjustmentBehavior:UIScrollViewContentInsetAdjustmentNever];
    } else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }

    self.view.backgroundColor = [UIColor colorWithRed:0.94 green:0.94 blue:0.96 alpha:1.00];
    self.title = @"自助授权";
    [self _configUI];
    
    UIBarButtonItem * rightItem = [[UIBarButtonItem alloc] initWithTitle:@"申请记录" style:UIBarButtonItemStylePlain target:self action:@selector(_selfHelpAuthorizationClicked)];
    self.navigationItem.rightBarButtonItem = rightItem;
    
}

/** 搜索，text搜索的关键字 */
- (void)_searchRequestResultDataWithText:(NSString *)text
{
    if (text.length == 0) {
        return;
    }
    __weak typeof(self) weakSelf = self;
    [DoorDuDataManager getEstateDepartmentSearchWithKeyword:text startPage:1 pageSize:20 completion:^(NSArray<DoorDuEstateDepartmentSearch *> *departmentList, DoorDuError *error) {
        if (!error) {
            [weakSelf.searchResultDataArray removeAllObjects];
            [weakSelf.searchResultDataArray addObjectsFromArray:departmentList];
            [weakSelf.resultViewController.tableView reloadData];
            if (weakSelf.searchResultDataArray.count == 0) {
                [DDProgressHUD showCenterWithText:@"搜索结果为空" duration:1.5];
            }
        } else {
            [DDProgressHUD showCenterWithText:error.message duration:1.5];
        }
    }];
}

#pragma mark - 点击事件
/** 自助授权列表 */
- (void)_selfHelpAuthorizationClicked
{
    DDSelfHelpAuthorizationListViewController * vc = [[DDSelfHelpAuthorizationListViewController alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}

/** 下一步点击事件 */
- (void)_nextButtonClicked
{
    if (self.nextButton.selected) {//选中时才进入下一页
        __weak typeof(self) weakSelf = self;
        [DoorDuDataManager getMobileOfProprietorWithRoomId:self.roomInfo.room_number_id completion:^(NSArray<NSString *> *mobiles, DoorDuError *error) {
            if (!error) {
                DDCompleteInformationViewController * vc = [[DDCompleteInformationViewController alloc] init];
                vc.city = weakSelf.city;
                vc.department = weakSelf.department;
                vc.buildingUnit = weakSelf.buildingUnit;
                vc.roomNumber = weakSelf.roomNumber;
                vc.ownerMobileArray = mobiles;
                [weakSelf.navigationController pushViewController:vc animated:YES];
            } else {
                [DDProgressHUD showCenterWithText:error.message duration:1.5];
            }
        }];
    }
}

/**刷新 nextButton 状态*/
- (void)_reloadNextButtonState
{
    if (self.city && self.department && self.buildingUnit && self.roomNumber) {
        self.nextButton.backgroundColor = [UIColor colorWithRed:0.42 green:0.71 blue:0.11 alpha:1.00];//高亮
        self.nextButton.selected = YES;
    } else {
        self.nextButton.backgroundColor = [UIColor colorWithRed:0.73 green:0.73 blue:0.73 alpha:1.00];//灰色
        self.nextButton.selected = NO;
    }
}

#pragma mark - tableView 代理

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 3;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"tableView"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"tableView"];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    switch (indexPath.row) {
        case 0:
        {
            cell.textLabel.text = @"城市";
            if (self.city) {
                cell.detailTextLabel.text = self.city.city_name;
            } else {
                cell.detailTextLabel.text = @"";
            }
        }
            break;
        case 1:
        {
            cell.textLabel.text = @"小区";
            if (self.department) {
                cell.detailTextLabel.text = self.department.dep_name;
            } else {
                cell.detailTextLabel.text = @"";
            }
        }
            break;
        case 2:
        {
            cell.textLabel.text = @"楼栋房号";
            if (self.buildingUnit && self.roomNumber) {
                cell.detailTextLabel.text = [NSString stringWithFormat:@"%@%@",self.buildingUnit.full_name,self.roomNumber.room_number];
            } else {
                cell.detailTextLabel.text = @"";
            }
        }
            break;
            
        default:
            break;
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.row) {
        case 0:
        {
            DDCityViewController * vc = [[DDCityViewController alloc] init];
            [self.navigationController pushViewController:vc animated:YES];
        }
            break;
        case 1:
        {
            if (!self.city) {
                return;
            }
            DDDepartmentViewController * vc = [[DDDepartmentViewController alloc] init];
            vc.city = self.city;
            [self.navigationController pushViewController:vc animated:YES];
        }
            break;
        case 2:
        {
            if (!self.department && !self.city) {
                return;
            }
            DDBuildingUnitViewController * vc = [[DDBuildingUnitViewController alloc] init];
            vc.city = self.city;
            vc.department = self.department;
            [self.navigationController pushViewController:vc animated:YES];
        }
            break;
            
        default:
            break;
    }

}


#pragma mark - 界面布局
- (void)_configUI
{
    [self.view addSubview:self.tableView];
    [self.view addSubview:self.desLabel];
    [self.view addSubview:self.nextButton];
    self.tableView.tableHeaderView = self.searchController.searchBar;
    /** tableView 布局 */
    //top
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.topLayoutGuide attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
    //左
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    //右
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
    //下面
    [self.tableView addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:60*4+5]];
    
    /** desLabel 布局 */
    //top
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.desLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.tableView attribute:NSLayoutAttributeBottom multiplier:1 constant:10]];
    //左
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.desLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.desLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    
    /** nextButton 布局 */
    //top
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.nextButton attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.desLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:15]];
    //左
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.nextButton attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.nextButton attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    //高
    [self.nextButton addConstraint:[NSLayoutConstraint constraintWithItem:self.nextButton attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:40]];

}
#pragma mark -懒加载
#pragma mark - 搜索控制器，一些代理方法也在这类
- (DDSearchController *)searchController
{
    if (!_searchController) {
        _searchController = [[DDSearchController alloc]    initWithSearchResultsController:self.resultViewController];
        _searchController.searchBar.placeholder = @"请输入小区名称";
        self.definesPresentationContext = YES;
        __weak typeof(self) weakSelf = self;
        /** 时时更新搜索 */
        [_searchController realTimeSearchResultsBlock:^(UISearchController *searchVC, NSString *searchText) {
            
        }];
        /**键盘的搜索按钮 点击事件*/
        [_searchController searchButtonClickedBlock:^(UISearchController *searchVC, UISearchBar *searchBar) {
            [weakSelf _searchRequestResultDataWithText:searchBar.text];
        }];
        /**UISearchBar 取消按钮被点击了*/
        [_searchController cancelButtonClickedBlock:^(UISearchController *searchVC, UISearchBar *searchBar) {
            [weakSelf.searchController.searchBar resignFirstResponder];
            [weakSelf.searchResultDataArray removeAllObjects];
            [weakSelf.resultViewController reloadData];
        }];
        [_searchController presentSearchControllerBlock:^(UISearchController *searchVC) {
            
        }];
        [_searchController didDismissSearchControllerBlock:^(UISearchController *searchVC) {
            [weakSelf.searchResultDataArray removeAllObjects];
            [weakSelf.resultViewController.tableView reloadData];
        }];
    }
    return _searchController;
}

#pragma mark - 显示结果的控制器
- (DDSearchResultTableViewController *)resultViewController
{
    if (!_resultViewController) {
        _resultViewController = [[DDSearchResultTableViewController alloc] init];
        _resultViewController.tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        _resultViewController.tableView.separatorInset = UIEdgeInsetsMake(0, 15, 0, 0);
        /**返回搜索结果的个数*/
        __weak typeof(self) weakSelf = self;
        [_resultViewController setDdSearchNumberOfRowsInSection:^NSInteger(UITableView * tableView, NSInteger section) {
            return weakSelf.searchResultDataArray.count;
        }];
        /**返回cell*/
        [_resultViewController setDdSearchCellForRowAtIndexPath:^UITableViewCell *(UITableView * tableView, NSIndexPath *indexPath) {
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
            if (!cell) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
            }
            DoorDuEstateDepartmentSearch * dep = weakSelf.searchResultDataArray[indexPath.row];
            cell.textLabel.text = dep.dep_name;
            cell.detailTextLabel.text = [NSString stringWithFormat:@"%@  %@  %@",dep.province_name,dep.district_name,dep.city_name];
            return cell;
        }];
        /**cell的高度*/
        [_resultViewController setDdSearchHeightForRowAtIndexPath:^CGFloat(UITableView *tableView, NSIndexPath *indexPath) {
            return 50;
        }];
        /**搜索框的点击事件*/
        [_resultViewController setDdSearchDidSelectRowAtIndexPath:^(UITableView *tableView, NSIndexPath *indexPath) {
            [weakSelf.searchController.searchBar resignFirstResponder];
            DoorDuEstateDepartmentSearch * dep = weakSelf.searchResultDataArray[indexPath.row];
            DoorDuEstateCity * city = [[DoorDuEstateCity alloc] init];
            city.city_name = dep.city_name;
            city.city_id = dep.city_id;
            DoorDuEstateDepartment * department = [[DoorDuEstateDepartment alloc] init];
            department.dep_name = dep.dep_name;
            department.dep_id = dep.dep_id;
            weakSelf.city = city;
            weakSelf.department = department;
            weakSelf.buildingUnit = nil;
            weakSelf.roomNumber = nil;
            [weakSelf.tableView reloadData];
            weakSelf.searchController.active = NO;
        }];
        /**开始拖拽的时候，这时可以做一些操作，比如：用于隐藏键盘*/
        [_resultViewController setDdSearchWillBeginDragging:^{
            if (weakSelf.searchController.searchBar.isFirstResponder) {
                [weakSelf.searchController.searchBar resignFirstResponder];
            }
        }];
        /**清空数据*/
        [_resultViewController setDdSearchClearData:^{
            [weakSelf.searchResultDataArray removeAllObjects];
            [weakSelf.resultViewController reloadData];
        }];
    }
    return _resultViewController;
}


- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.translatesAutoresizingMaskIntoConstraints = NO;
        _tableView.backgroundColor = [UIColor colorWithRed:0.94 green:0.94 blue:0.96 alpha:1.00];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.bounces = NO;
        _tableView.scrollEnabled = NO;
        _tableView.tableFooterView = [[UIView alloc] init];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLineEtched;
    }
    return _tableView;
}
/** 完成按钮 */
- (UIButton *)nextButton
{
    if (!_nextButton) {
        _nextButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_nextButton setTitle:@"下一步" forState:UIControlStateNormal];
        [_nextButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _nextButton.translatesAutoresizingMaskIntoConstraints = NO;
        [_nextButton addTarget:self action:@selector(_nextButtonClicked) forControlEvents:UIControlEventTouchUpInside];
        _nextButton.layer.masksToBounds = YES;
        _nextButton.layer.cornerRadius = 3;
    }
    return _nextButton;
}
/** 描述标签 */
- (UILabel *)desLabel
{
    if (!_desLabel) {
        _desLabel = [[UILabel alloc] init];
        _desLabel.translatesAutoresizingMaskIntoConstraints = NO;
        _desLabel.textColor = [UIColor colorWithRed:0.59 green:0.59 blue:0.60 alpha:1.00];
        _desLabel.font = [UIFont systemFontOfSize:14];
        _desLabel.numberOfLines = 0;
        _desLabel.text = @"将提交至物业管理处审核，审核结果将APP消息通知您，请留意";
        [_desLabel sizeToFit];
    }
    return _desLabel;
}
/**搜索结果数据源*/
- (NSMutableArray *)searchResultDataArray
{
    if (!_searchResultDataArray) {
        _searchResultDataArray = [NSMutableArray array];
    }
    return _searchResultDataArray;
}

- (void)dealloc
{
    NSLog(@"\ndealloc: %@\n",NSStringFromClass([self class]));
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
