//
//  DDInputTextViewController.h
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/3/7.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import <UIKit/UIKit.h>

/** 输入框 complement*/
@interface DDInputTextViewController : UIViewController

@property (nonatomic, strong) void (^returnDataBlock)(NSString * inputString);


@property (nonatomic, strong) NSString * text;
/**文本输入框*/
@property (nonatomic,strong) UITextField * inputTextField;

@property(nonatomic) UIKeyboardType keyboardType; 

@end
