//
//  DDRoomNumberViewController.h
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/3/5.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DDRoomNumberViewController : UIViewController

@property (nonatomic, strong) DoorDuEstateCity * city;

@property (nonatomic, strong) DoorDuEstateDepartment * department;

@property (nonatomic, strong) DoorDuEstateBuildingUnit * buildingUnit;

@end
