//
//  DDRoomNumberViewController.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/3/5.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDRoomNumberViewController.h"
#import "DDSelfHelpAuthorizationViewController.h"
#import "DDAlertView.h"

@interface DDRoomNumberViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView * tableView;

@property (nonatomic, strong) NSMutableArray * dataArray;

@property (nonatomic, strong) DoorDuEstateRoomNumber * roomNumber;

@end

@implementation DDRoomNumberViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if (@available(iOS 11.0, *)){
        [[UIScrollView appearance] setContentInsetAdjustmentBehavior:UIScrollViewContentInsetAdjustmentNever];
    } else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }

    self.view.backgroundColor = [UIColor colorWithRed:0.94 green:0.94 blue:0.96 alpha:1.00];
    self.title = @"房间";
    
    [self _configUI];
    [self _requestRoomNumberData];

    
    UIBarButtonItem * rightItem = [[UIBarButtonItem alloc] initWithTitle:@"提交" style:UIBarButtonItemStylePlain target:self action:@selector(_submitClicked)];
    self.navigationItem.rightBarButtonItem = rightItem;
    
}

#pragma mark - 请求接口
- (void)_requestRoomNumberData
{
    __weak typeof(self) weakSelf = self;
    [DoorDuDataManager getEstateRoomNumberWithKeyword:nil unitId:self.buildingUnit.unit_id startPage:1 pageSize:20 completion:^(NSArray<DoorDuEstateRoomNumber *> *roomNumberList, DoorDuError *error) {
        if (!error) {
            [weakSelf.dataArray addObjectsFromArray:roomNumberList];
            [weakSelf.tableView reloadData];
        }
    }];
    
}

#pragma mark - 点击事件
/** 提交 */
- (void)_submitClicked
{
    if (self.roomNumber) {
        __weak typeof(self) weakSelf = self;
        [self.navigationController.viewControllers enumerateObjectsUsingBlock:^(__kindof UIViewController * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            if ([obj isKindOfClass:[DDSelfHelpAuthorizationViewController class]]) {
                DDSelfHelpAuthorizationViewController * vc = (DDSelfHelpAuthorizationViewController *)obj;
                vc.city = weakSelf.city;
                vc.department = weakSelf.department;
                vc.buildingUnit = weakSelf.buildingUnit;
                vc.roomNumber = weakSelf.roomNumber;
                [weakSelf.navigationController popToViewController:vc animated:YES];
                *stop = YES;
            }
        }];
    }
}

#pragma mark - tableView 代理

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        return CGFLOAT_MIN;
    }else if (section == 1) {
        return 10;
    }
    return CGFLOAT_MIN;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    if (section == 0) {
        return CGFLOAT_MIN;
    }else if (section == 1) {
        return 10;
    }
    return CGFLOAT_MIN;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UITableViewHeaderFooterView * view = [tableView dequeueReusableHeaderFooterViewWithIdentifier:@"UITableViewHeaderFooterView"];
    if (!view) {
        view = [[UITableViewHeaderFooterView alloc] initWithReuseIdentifier:@"UITableViewHeaderFooterView"];
    }
    view.backgroundColor = [UIColor clearColor];
    return view;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    UITableViewHeaderFooterView * view = [tableView dequeueReusableHeaderFooterViewWithIdentifier:@"UITableViewHeaderFooterView"];
    if (!view) {
        view = [[UITableViewHeaderFooterView alloc] initWithReuseIdentifier:@"UITableViewHeaderFooterView"];
    }
    view.backgroundColor = [UIColor clearColor];
    return view;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        return 1;
    }
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"tableView"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"tableView"];
    }
    
    if (indexPath.section == 0) {
        cell.accessoryType = UITableViewCellAccessoryNone;
        cell.textLabel.text = @"楼栋单元";
        cell.detailTextLabel.text = self.buildingUnit.full_name;
    } else if (indexPath.section == 1) {
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        DoorDuEstateRoomNumber * roomNumber = self.dataArray[indexPath.row];
        cell.textLabel.text = roomNumber.room_number;
        cell.accessoryType = UITableViewCellAccessoryNone;
        if (self.roomNumber && [roomNumber.room_number_id isEqualToString:self.roomNumber.room_number_id]) {
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
        }
        if (roomNumber.is_open_card.integerValue == 0) {
            cell.detailTextLabel.text = @"该房间尚未开卡";
        } else {
            cell.detailTextLabel.text = @"该房间已开卡，可申请自助授权";
        }
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (indexPath.section == 0) {
        return;
    }
    
    DoorDuEstateRoomNumber * roomNumber = self.dataArray[indexPath.row];
    if (roomNumber.is_open_card.integerValue == 0) {
        [DDAlertView alertShowWithVC:self title:@"该房间尚未开卡" message:@"为安全起见,请先申请实体卡再进行app授权" otherButtonTitle:@[@"好,我知道了"] clickedBlock:^(NSInteger index) {

        }];
        return;
    }
    self.roomNumber = roomNumber;
    [self.tableView reloadData];
}

#pragma mark - 界面布局
- (void)_configUI
{
    [self.view addSubview:self.tableView];
    /** tableView 布局 */
    //top
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.topLayoutGuide attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
    //左
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    //右
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
    //下面
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.bottomLayoutGuide attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
    
}
#pragma mark -懒加载
- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.translatesAutoresizingMaskIntoConstraints = NO;
        _tableView.backgroundColor = [UIColor colorWithRed:0.94 green:0.94 blue:0.96 alpha:1.00];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.tableFooterView = [[UIView alloc] init];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLineEtched;
        _tableView.rowHeight = 66;
    }
    return _tableView;
}

- (NSMutableArray *)dataArray
{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

- (void)dealloc
{
    NSLog(@"\ndealloc: %@\n",NSStringFromClass([self class]));
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
