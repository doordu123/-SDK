//
//  DDCommunityNoticeDetailViewController.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/29.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDCommunityNoticeDetailViewController.h"
#import <WebKit/WebKit.h>

@interface DDCommunityNoticeDetailViewController ()

/** 标题 */
@property (nonatomic, strong) UILabel * titleLabel;

/** 发布者 */
@property (nonatomic, strong) UILabel * publisherLabel;

/** 时间 */
@property (nonatomic, strong) UILabel * timeLabel;

/** 小区名 */
@property (nonatomic, strong) UILabel * depNameLabel;

/** 加载内容 */
@property (nonatomic, strong) WKWebView * webView;

@end

@implementation DDCommunityNoticeDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if (@available(iOS 11.0, *)){
        [[UIScrollView appearance] setContentInsetAdjustmentBehavior:UIScrollViewContentInsetAdjustmentNever];
    } else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }

    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"公告详情";
    
    [self _configUI];
    if (!self.model) {//不是从列表过来的时候
        [self _requestCommunityNoticeDetailData];
    } else {
        [self _reloadCommunityNoticeDetailUIData:self.model];
    }
    
}

#pragma mark - 获取公告详情数据
- (void)_requestCommunityNoticeDetailData
{
    [SVProgressHUD showWithStatus:@"小区公告获取中..."];
    __weak typeof(self) weakSelf = self;
    [DoorDuDataManager getNoticeDetailWithNoticeId:self.notice_id completion:^(DoorDuCommunityNotice *noticeDetail, DoorDuError *error) {
        [SVProgressHUD dismiss];
        if (!error) {
            [weakSelf _reloadCommunityNoticeDetailUIData:noticeDetail];
        } else {
            [DDProgressHUD showCenterWithText:error.message duration:1.5];
        }
    }];
}

#pragma mark - 刷新UI数据
- (void)_reloadCommunityNoticeDetailUIData:(DoorDuCommunityNotice *)model
{
    NSString * titleString = model.title;
//    if (model.is_urgent.integerValue == 1) {
//        titleString = [titleString stringByAppendingFormat:@"    紧急"];
//    }
    self.titleLabel.text = titleString;
    self.publisherLabel.text = model.publisher;
    self.depNameLabel.text = model.dep_name;
    self.timeLabel.text = model.add_time;
    if (model.content_remark.length) {
        [self.webView loadHTMLString:model.content_remark baseURL:nil];
    } else {
        [self.webView loadHTMLString:model.content baseURL:nil];
    }
}

- (void)_configUI
{
    [self.view addSubview:self.titleLabel];
    [self.view addSubview:self.publisherLabel];
    [self.view addSubview:self.depNameLabel];
    [self.view addSubview:self.timeLabel];
    [self.view addSubview:self.webView];
    /** 布局 titleLabel */
    //高
    [self.titleLabel addConstraint:[NSLayoutConstraint constraintWithItem:self.titleLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.titleLabel.font.lineHeight]];
    //左
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.titleLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.titleLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    //上
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.titleLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.topLayoutGuide attribute:NSLayoutAttributeBottom multiplier:1 constant:10]];
    
    /** 布局 publisherLabel */
    //高
    [self.publisherLabel addConstraint:[NSLayoutConstraint constraintWithItem:self.publisherLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.publisherLabel.font.lineHeight]];
    //上
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.publisherLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.titleLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:10]];
    //左
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.publisherLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.publisherLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    
    /** 布局 depNameLabel */
    //高
    [self.depNameLabel addConstraint:[NSLayoutConstraint constraintWithItem:self.depNameLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.depNameLabel.font.lineHeight]];
    //左
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.depNameLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.depNameLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    //上
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.depNameLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.publisherLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:10]];
    
    /** 布局 timeLabel */
    //高
    [self.timeLabel addConstraint:[NSLayoutConstraint constraintWithItem:self.timeLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.timeLabel.font.lineHeight]];
    //左
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.timeLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.timeLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    //上
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.timeLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.depNameLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:10]];
    
    /** 布局 webView */
    //左
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.webView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    //右
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.webView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
    //上
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.webView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.timeLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:10]];
    //下
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.webView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
    
}

#pragma mark - 懒加载

/** dep */
- (UILabel *)titleLabel
{
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc] init];
        _titleLabel.textColor = [UIColor blackColor];
        _titleLabel.font = [UIFont systemFontOfSize:15];
        _titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _titleLabel;
}
/** 发布者 */
- (UILabel *)publisherLabel
{
    if (!_publisherLabel) {
        _publisherLabel = [[UILabel alloc] init];
        _publisherLabel.textColor = [UIColor blackColor];
        _publisherLabel.font = [UIFont systemFontOfSize:15];
        _publisherLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _publisherLabel;
}

/** 小区名 */
- (UILabel *)depNameLabel
{
    if (!_depNameLabel) {
        _depNameLabel = [[UILabel alloc] init];
        _depNameLabel.textColor = [UIColor lightGrayColor];
        _depNameLabel.font = [UIFont systemFontOfSize:15];
        _depNameLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _depNameLabel;
}
/** 时间 */
- (UILabel *)timeLabel
{
    if (!_timeLabel) {
        _timeLabel = [[UILabel alloc] init];
        _timeLabel.textColor = [UIColor lightGrayColor];
        _timeLabel.font = [UIFont systemFontOfSize:15];
        _timeLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _timeLabel;
}
/** 加载内容 */
- (WKWebView *)webView
{
    if (!_webView) {
        
        NSString *jScript = @"var meta = document.createElement('meta'); meta.setAttribute('name', 'viewport'); meta.setAttribute('content', 'width=device-width'); document.getElementsByTagName('head')[0].appendChild(meta);";
        WKUserScript *wkUScript = [[WKUserScript alloc] initWithSource:jScript injectionTime:WKUserScriptInjectionTimeAtDocumentEnd forMainFrameOnly:YES];
        WKUserContentController *wkUController = [[WKUserContentController alloc] init];
        [wkUController addUserScript:wkUScript];
        WKWebViewConfiguration *config = [WKWebViewConfiguration new];
        config.userContentController = wkUController;
        _webView = [[WKWebView alloc] initWithFrame:CGRectZero configuration:config];
        _webView.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _webView;
}

- (void)dealloc
{
    NSLog(@"\ndealloc: %@\n",NSStringFromClass([self class]));
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
