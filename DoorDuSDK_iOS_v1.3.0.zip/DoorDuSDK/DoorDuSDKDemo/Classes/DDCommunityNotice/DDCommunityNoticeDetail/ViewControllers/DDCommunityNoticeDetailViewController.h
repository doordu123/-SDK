//
//  DDCommunityNoticeDetailViewController.h
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/29.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DDCommunityNoticeDetailViewController : UIViewController

@property (nonatomic, strong) DoorDuCommunityNotice * model;

/** 物业通知ID , 如果为空说明 是从列表过来的，就不用请求数据*/
@property (nonatomic,copy) NSString *notice_id;

@end
