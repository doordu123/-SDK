//
//  DDCommunityNoticeListTableViewCell.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/29.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDCommunityNoticeListTableViewCell.h"

@interface DDCommunityNoticeListTableViewCell ()

/** 标题 */
@property (nonatomic, strong) UILabel * titleLabel;

/** 发布者 */
@property (nonatomic, strong) UILabel * publisherLabel;

/** 内容 */
@property (nonatomic, strong) UILabel * contentLabel;

/** 小区名 */
@property (nonatomic, strong) UILabel * depNameLabel;

/** 时间 */
@property (nonatomic, strong) UILabel * timeLabel;

@end


@implementation DDCommunityNoticeListTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self _configUI];
    }
    return self;
}

- (void)setModel:(DoorDuCommunityNotice *)model
{
    _model = model;
    NSString * titleString = model.title;
    if (model.is_urgent.integerValue == 1) {
        titleString = [titleString stringByAppendingFormat:@"    紧急"];
    }
    self.titleLabel.text = titleString;
    self.publisherLabel.text = model.publisher;
    self.contentLabel.text = model.content;
    self.depNameLabel.text = model.dep_name;
    self.timeLabel.text = model.add_time;
}


#pragma mark - 界面布局
- (void)_configUI
{
    [self.contentView addSubview:self.titleLabel];
    [self.contentView addSubview:self.publisherLabel];
    [self.contentView addSubview:self.contentLabel];
    [self.contentView addSubview:self.depNameLabel];
    [self.contentView addSubview:self.timeLabel];
    
    /** 布局 titleLabel */
    //高
    [self.titleLabel addConstraint:[NSLayoutConstraint constraintWithItem:self.titleLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.titleLabel.font.lineHeight]];
    //左
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.titleLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.titleLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    //上
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.titleLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeTop multiplier:1 constant:15]];
    
    /** 布局 publisherLabel */
    //高
    [self.publisherLabel addConstraint:[NSLayoutConstraint constraintWithItem:self.publisherLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.publisherLabel.font.lineHeight]];
    //上
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.publisherLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.titleLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:10]];
    //左
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.publisherLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.publisherLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    
    /** 布局 contentLabel */
    //左
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.contentLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.contentLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    //上
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.contentLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.publisherLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:10]];
    //下
    NSLayoutConstraint * depNameBottom = [NSLayoutConstraint constraintWithItem:self.contentLabel attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.depNameLabel attribute:NSLayoutAttributeTop multiplier:1 constant:0];
    depNameBottom.priority = 999;
    [self.contentView addConstraint:depNameBottom];
    
    /** 布局 depNameLabel */
    //高
    [self.depNameLabel addConstraint:[NSLayoutConstraint constraintWithItem:self.depNameLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.depNameLabel.font.lineHeight]];
    //左
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.depNameLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.depNameLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    //上
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.depNameLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.contentLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:10]];
    
    /** 布局 timeLabel */
    //高
    [self.timeLabel addConstraint:[NSLayoutConstraint constraintWithItem:self.timeLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.timeLabel.font.lineHeight]];
    //左
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.timeLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //右
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.timeLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    //上
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.timeLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.depNameLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:10]];
    //下
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.timeLabel attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeBottom multiplier:1 constant:-15]];
    
}

#pragma mark - 懒加载

/** dep */
- (UILabel *)titleLabel
{
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc] init];
        _titleLabel.textColor = [UIColor blackColor];
        _titleLabel.font = [UIFont systemFontOfSize:15];
        _titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _titleLabel;
}
/** 发布者 */
- (UILabel *)publisherLabel
{
    if (!_publisherLabel) {
        _publisherLabel = [[UILabel alloc] init];
        _publisherLabel.textColor = [UIColor blackColor];
        _publisherLabel.font = [UIFont systemFontOfSize:15];
        _publisherLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _publisherLabel;
}
/** 内容 */
- (UILabel *)contentLabel
{
    if (!_contentLabel) {
        _contentLabel = [[UILabel alloc] init];
        _contentLabel.numberOfLines = 0;
        _contentLabel.textColor = [UIColor lightGrayColor];
        _contentLabel.font = [UIFont systemFontOfSize:13];
        _contentLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _contentLabel;
}
/** 小区名 */
- (UILabel *)depNameLabel
{
    if (!_depNameLabel) {
        _depNameLabel = [[UILabel alloc] init];
        _depNameLabel.textColor = [UIColor lightGrayColor];
        _depNameLabel.textAlignment = NSTextAlignmentRight;
        _depNameLabel.font = [UIFont systemFontOfSize:15];
        _depNameLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _depNameLabel;
}
/** 时间 */
- (UILabel *)timeLabel
{
    if (!_timeLabel) {
        _timeLabel = [[UILabel alloc] init];
        _timeLabel.textAlignment = NSTextAlignmentRight;
        _timeLabel.textColor = [UIColor lightGrayColor];
        _timeLabel.font = [UIFont systemFontOfSize:15];
        _timeLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _timeLabel;
}


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
