//
//  DDVisitorRecordTableViewCell.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/26.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDVisitorRecordTableViewCell.h"
#import "UIImageView+DDImageCache.h"

@interface DDVisitorRecordTableViewCell ()

/** 访客留影图片 */
@property (nonatomic, strong) UIImageView * visitorImageView;

/** 开门类型 */
@property (nonatomic, strong) UILabel * openTypeLabel;

/** 描述 */
@property (nonatomic, strong) UILabel * desLabel;

/** 时间 */
@property (nonatomic, strong) UILabel * timeLabel;

@end

@implementation DDVisitorRecordTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self _configUI];
    }
    return self;
}

- (void)setModel:(DoorDuVistorHistoryInfo *)model
{
    _model = model;
    self.openTypeLabel.text = model.open_type_info;
    self.desLabel.text = model.des;
    self.timeLabel.text = [NSString stringWithFormat:@"%@  %@",model.date,model.time];
    [self.visitorImageView dd_setImageWithURL:[NSURL URLWithString:model.thumbnail_url]];
}

#pragma mark - 界面布局
- (void)_configUI
{
    [self.contentView addSubview:self.visitorImageView];
    [self.contentView addSubview:self.openTypeLabel];
    [self.contentView addSubview:self.desLabel];
    [self.contentView addSubview:self.timeLabel];
    self.visitorImageView.backgroundColor = [UIColor orangeColor];
    
    /** 布局 visitorImageView */
    //高
    [self.visitorImageView addConstraint:[NSLayoutConstraint constraintWithItem:self.visitorImageView attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:100]];
    //宽
    [self.visitorImageView addConstraint:[NSLayoutConstraint constraintWithItem:self.visitorImageView attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:100]];
    //左
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.visitorImageView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeLeft multiplier:1 constant:15]];
    //上
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.visitorImageView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeTop multiplier:1 constant:15]];
    //下
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.visitorImageView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeBottom multiplier:1 constant:-15]];
    
    /** 布局 openTypeLabel */
    //高
    [self.openTypeLabel addConstraint:[NSLayoutConstraint constraintWithItem:self.openTypeLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.openTypeLabel.font.lineHeight]];
    //左
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.openTypeLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.visitorImageView attribute:NSLayoutAttributeRight multiplier:1 constant:15]];
    //右
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.openTypeLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    //上
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.openTypeLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.visitorImageView attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
    
    /** 布局 desLabel */
    //高
    [self.desLabel addConstraint:[NSLayoutConstraint constraintWithItem:self.desLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.desLabel.font.lineHeight]];
    //左
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.desLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.visitorImageView attribute:NSLayoutAttributeRight multiplier:1 constant:15]];
    //右
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.desLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    //centerY
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.desLabel attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.visitorImageView attribute:NSLayoutAttributeCenterY multiplier:1 constant:0]];
    
    /** 布局 timeLabel */
    //高
    [self.timeLabel addConstraint:[NSLayoutConstraint constraintWithItem:self.timeLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:self.timeLabel.font.lineHeight]];
    //左
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.timeLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.visitorImageView attribute:NSLayoutAttributeRight multiplier:1 constant:15]];
    //右
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.timeLabel attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeRight multiplier:1 constant:-15]];
    //下
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.timeLabel attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.visitorImageView attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
    
    
}

#pragma mark - 懒加载
/** 访客留影图片 */
- (UIImageView *)visitorImageView
{
    if (!_visitorImageView) {
        _visitorImageView = [[UIImageView alloc] init];
        _visitorImageView.contentMode = UIViewContentModeScaleAspectFill;
        _visitorImageView.clipsToBounds = YES;
        _visitorImageView.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _visitorImageView;
}
/** 开门类型 */
- (UILabel *)openTypeLabel
{
    if (!_openTypeLabel) {
        _openTypeLabel = [[UILabel alloc] init];
        _openTypeLabel.textColor = [UIColor blackColor];
        _openTypeLabel.font = [UIFont systemFontOfSize:15];
        _openTypeLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _openTypeLabel;
}
/** 描述 */
- (UILabel *)desLabel
{
    if (!_desLabel) {
        _desLabel = [[UILabel alloc] init];
        _desLabel.textColor = [UIColor blackColor];
        _desLabel.font = [UIFont systemFontOfSize:15];
        _desLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _desLabel;
}
/** 时间 */
- (UILabel *)timeLabel
{
    if (!_timeLabel) {
        _timeLabel = [[UILabel alloc] init];
        _timeLabel.textColor = [UIColor blackColor];
        _timeLabel.font = [UIFont systemFontOfSize:15];
        _timeLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _timeLabel;
}


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
