//
//  DDVisitorRecordViewController.h
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/26.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import <UIKit/UIKit.h>

/** 访客留影 */
@interface DDVisitorRecordViewController : UIViewController

@property (nonatomic, assign) NSInteger type;//0 代表当前用户在这个房间的访客留影，1代表当前房间的访客留影
@property (nonatomic, strong) DoorDuRoomInfo *roomInfo;


@end
