//
//  DDVisitorRecordViewController.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/26.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "DDVisitorRecordViewController.h"
#import "DDVisitorRecordTableViewCell.h"
#import "DDPopMenuView.h"
#import "UIView+DDFrame.h"

@interface DDVisitorRecordViewController ()<UITableViewDelegate,UITableViewDataSource>

//留影类型
@property (nonatomic, assign) NSInteger openType;

@property (nonatomic, strong) NSMutableArray * dataArray;

@property (nonatomic, strong) UITableView * tableView;

@property (nonatomic, weak) DDPopMenuView * menuView;

@end

@implementation DDVisitorRecordViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if (@available(iOS 11.0, *)){
        [[UIScrollView appearance] setContentInsetAdjustmentBehavior:UIScrollViewContentInsetAdjustmentNever];
    } else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }

    self.openType = 0;
    self.title = @"访客留影";
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self _configUI];
    
    [self _requestVisitorRecordData];
}

- (void)_rightItemButtonClicked:(UIButton *)sender
{
    if (self.menuView) {
        __weak typeof(self) weakSelf = self;
        [self.menuView dismissComplete:^{
            weakSelf.menuView = nil;
        }];
        return;
    }
    //开门类型 0-所有记录 1-IC卡开门 2-APP开门 3-呼叫开门 4-密码开门 5-未接通
    DDPopMenuView * menuView = [[DDPopMenuView alloc] initWithFrame:CGRectMake(0, 0, 150, 45*6)];
    menuView.titlesArray = @[@"所有记录",@"IC卡开门",@"APP开门",@"呼叫开门",@"密码开门",@"未接通"];
    menuView.selectedRow = self.openType;
    __weak typeof(self) weakSelf = self;
    menuView.returnSelectedBlock = ^(NSInteger row, NSString *title) {
        weakSelf.openType = row;
        [weakSelf _setRightItemWithTitle:title];
        [weakSelf _requestVisitorRecordData];
    };
    //判断是不是iPhone X
    CGFloat menuViewPointY = [[UIApplication sharedApplication] statusBarFrame].size.height + 44;
    if (([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1125, 2436), [[UIScreen mainScreen] currentMode].size) : NO)) {
        
    }
    [menuView showFromPoint:CGPointMake(self.view.width-60, menuViewPointY) superView:self.view];
    self.menuView = menuView;
}

#pragma mark - 接口请求
- (void)_requestVisitorRecordData
{
    //0 代表当前用户在这个房间的访客留影，1代表当前房间的访客留影
    //self.openType 开门类型 0-所有记录 1-IC卡开门 2-APP开门 3-呼叫开门 4-密码开门 5-未接通
    if (self.type == 0) {
        __weak typeof(self) weakSelf = self;
        [SVProgressHUD showWithStatus:@"用户访客留影请求中..."];
        [DoorDuDataManager getUserVistorsHistoryWithRoomId:self.roomInfo.room_number_id openType:self.openType startPage:1 pageSize:20 completion:^(NSArray<DoorDuVistorHistoryInfo *> *vistorHistoryList, DoorDuError *error) {
            [SVProgressHUD dismiss];
            if (error) {
                [DDProgressHUD showCenterWithText:error.message duration:1.5];
            } else {
                [weakSelf.dataArray removeAllObjects];
                [weakSelf.dataArray addObjectsFromArray:vistorHistoryList];
                [weakSelf.tableView reloadData];
            }
        }];
    } else {
        __weak typeof(self) weakSelf = self;
        [SVProgressHUD showWithStatus:@"房间访客留影请求中..."];
        [DoorDuDataManager getRoomVistorsHistoryWithRoomId:self.roomInfo.room_number_id openType:self.openType startPage:1 pageSize:20 completion:^(NSArray<DoorDuVistorHistoryInfo *> *vistorHistoryList, DoorDuError *error) {
            [SVProgressHUD dismiss];
            if (error) {
                [DDProgressHUD showCenterWithText:error.message duration:1.5];
            } else {
                [weakSelf.dataArray removeAllObjects];
                [weakSelf.dataArray addObjectsFromArray:vistorHistoryList];
                [weakSelf.tableView reloadData];
            }
        }];
    }
}

#pragma mark - tableView 代理
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    DDVisitorRecordTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"DDVisitorRecordTableViewCell" forIndexPath:indexPath];
    
    cell.model = self.dataArray[indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}


#pragma mark - 界面不去
- (void)_configUI
{
    [self.view addSubview:self.tableView];
    [self.tableView registerClass:DDVisitorRecordTableViewCell.class forCellReuseIdentifier:@"DDVisitorRecordTableViewCell"];
    
    /** 布局 tableView*/
    //上面top
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.topLayoutGuide attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
    //左边
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    //右边
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
    //底部
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.bottomLayoutGuide attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
    [self _setRightItemWithTitle:@"全部记录"];
}

#pragma mark - 设置rightItem
- (void)_setRightItemWithTitle:(NSString *)title
{
    UIButton * rightItemButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [rightItemButton setTitle:title forState:UIControlStateNormal];
    [rightItemButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [rightItemButton setImage:[UIImage imageNamed:@"DDCommonarrowdownImage"] forState:UIControlStateNormal];
    [rightItemButton addTarget:self action:@selector(_rightItemButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [rightItemButton sizeToFit];
    CGRect rightItemButtonFrame = rightItemButton.frame;
    rightItemButtonFrame.size.width += 5;
    rightItemButton.frame = rightItemButtonFrame;
    rightItemButton.titleEdgeInsets = UIEdgeInsetsMake(0, -rightItemButton.imageView.frame.size.width-2, 0, rightItemButton.imageView.frame.size.width);
    rightItemButton.imageEdgeInsets = UIEdgeInsetsMake(0, rightItemButton.titleLabel.frame.size.width, 0, -rightItemButton.titleLabel.frame.size.width-2);
    UIBarButtonItem * rightItem = [[UIBarButtonItem alloc] initWithCustomView:rightItemButton];
    self.navigationItem.rightBarButtonItem = rightItem;
}

#pragma mark - 懒加载
- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.backgroundColor = [UIColor colorWithRed:0.94 green:0.94 blue:0.96 alpha:1.00];
        _tableView.tableFooterView = [[UIView alloc]init];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        _tableView.translatesAutoresizingMaskIntoConstraints = NO;
        _tableView.rowHeight = UITableViewAutomaticDimension;
        _tableView.estimatedRowHeight = 60;
    }
    return _tableView;
}

- (NSMutableArray *)dataArray
{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

- (void)dealloc
{
    NSLog(@"\ndealloc: %@\n",NSStringFromClass([self class]));
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
