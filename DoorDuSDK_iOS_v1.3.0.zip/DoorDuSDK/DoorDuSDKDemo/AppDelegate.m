//
//  AppDelegate.m
//  DoorDuSDKDemo
//
//  Created by DoorDu on 2018/1/5.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "AppDelegate.h"
#import <DoorDuSDK/DoorDuSDK.h>
#import <AVFoundation/AVFoundation.h>
#import <AddressBook/AddressBook.h>
#import <AssetsLibrary/AssetsLibrary.h>
#import <UserNotifications/UserNotifications.h>
#import "DDCallListener.h"
#import "SDImageCache.h"

@interface AppDelegate ()

// 来电监听
@property (nonatomic, strong) DDCallListener *callListener;

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    DoorDuOptions *options = [[DoorDuOptions alloc] init];
//    options.mode = DoorDuTestMode;//测试(内网)
//    options.mode = DoorDuPreDistributeMode;//预发布
    options.mode = DoorDuDistributeMode;//发布
    options.requestTimeout = 15.0;
    options.isShowLog = YES;
    // 注册SDK
    // 预发布环境/发布环境 测试
    [DoorDuDataManager registSDKWithAppId:@"Q4gpNSIJdv81TGTIMnVTYvtztbQIb8B9"
                                secretKey:@"dowoECgNwHcitHjl1hjsbcwjPpud7d8i"
                                  options:options
                               completion:^(BOOL isSuccess, DoorDuError *error) {
                                   if (isSuccess) {
                                       NSLog(@"注册成功");
                                   } else {
                                       NSLog(@"注册失败");
                                   }
                               }];
    
    // 设置来电监听
    self.callListener = [[DDCallListener alloc] init];
    [DoorDuClient registClientDelegate:self.callListener];
    
    // 注册远程推送
    [self registerRemoteNotifications];
    
    // 判断用户是否已经登录过
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *accountName = [userDefaults objectForKey:@"accountName"];
    // 第三方记住用户名、密码的情况下做自动登录，必须判断SDK是否登录，没有登录必须调用sdk登录接口。
    // 导致SDK退出登录的情况:
    // 1.退出登录
    // 2.代理商账号/密码修改
    // 3.SDK环境切换
    if (accountName && [DoorDuClient isDoorDuSDKLogin]) {
        [self loginSuccess];
        self.mobileNo = accountName;
    } else {
        // 清除缓存信息
        NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
        NSString *accountName = [userDefaults objectForKey:@"accountName"];
        if (accountName) {
            [userDefaults setObject:nil forKey:accountName];
            [userDefaults setObject:nil forKey:@"accountName"];
        }
    }
    [userDefaults synchronize];
    
    return YES;
}

- (void)clearAllTempData
{
    // 用户退出登录必须调用sdk退出接口，用来完成音视频资源清理
    [SVProgressHUD showWithStatus:@"清理音视频资源..."];
    [DoorDuDataManager loginoutWithCompletion:^(BOOL isSuccess, DoorDuError *error) {
        [SVProgressHUD dismiss];
        if (isSuccess) {
            [DDProgressHUD showCenterWithText:@"资源清理成功" duration:1.0];
            
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [self logoutSuccess];
                
                // 清除缓存信息
                NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
                [userDefaults setObject:nil forKey:@"accountName"];
                [userDefaults synchronize];
            });
        }else {
            [DDProgressHUD showCenterWithText:[NSString stringWithFormat:@"资源清理失败  -- Reason:%@",error.message] duration:1.5];
        }
    }];
}

- (void)loginSuccess
{
    UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    UINavigationController *nav = [sb instantiateViewControllerWithIdentifier:@"rootNavViewController"];
    self.window.rootViewController = nav;
    [self.window makeKeyWindow];
}

- (void)logoutSuccess
{
    UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    UINavigationController *nav = [sb instantiateViewControllerWithIdentifier:@"LoginViewControllerID"];
    self.window.rootViewController = nav;
    [self.window makeKeyWindow];
}

/**申请系统权限*/
- (void)requestAccess {
    
    /** 请求相机权限 */
    [AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo completionHandler:^(BOOL granted) {

    }];
    /** 请求麦克风权限 */
    [AVCaptureDevice requestAccessForMediaType:AVMediaTypeAudio completionHandler:^(BOOL granted) {

    }];
}

#pragma mark - UIApplicationDelegate(推送)
/** 注册远程推送 */
- (void)registerRemoteNotifications {
    
    if ([UIDevice currentDevice].systemVersion.floatValue < 10.0) {
        
        /** iOS8-iOS9 */
        [[UIApplication sharedApplication] registerForRemoteNotifications];
        UIUserNotificationType type = UIUserNotificationTypeBadge | UIUserNotificationTypeSound | UIUserNotificationTypeAlert;
        UIUserNotificationSettings *setting = [UIUserNotificationSettings settingsForTypes:type categories:nil];
        [[UIApplication sharedApplication] registerUserNotificationSettings:setting];
        
        /** 权限申请 */
        [self requestAccess];
        
    }else {
        
        /** iOS10及以上 */
        UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
        center.delegate = self;
        UNAuthorizationOptions options = UNAuthorizationOptionAlert | UNAuthorizationOptionBadge | UNAuthorizationOptionSound;
        [center requestAuthorizationWithOptions:options completionHandler:^(BOOL granted, NSError * _Nullable error) {
            
            /** 权限申请 */
            [self requestAccess];
        }];
        
        [[UIApplication sharedApplication] registerForRemoteNotifications];
    }
}

- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
    // 注册推送令牌
    [DoorDuDataManager registerDeviceToken:deviceToken];
    
    NSString *deviceTokenStr = [[[[deviceToken description] stringByReplacingOccurrencesOfString:@"<"withString:@""]
                                 stringByReplacingOccurrencesOfString:@">" withString:@""]
                                stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
    pasteboard.string = deviceTokenStr;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


@end
