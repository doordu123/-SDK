//
//  AppDelegate.h
//  DoorDuSDKDemo
//
//  Created by DoorDu on 2018/1/5.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (nonatomic, strong) NSString * mobileNo;

@property (nonatomic, strong) NSArray<DoorDuRoomInfo *> *roomList;

- (void)loginSuccess;

- (void)logoutSuccess;

@end

