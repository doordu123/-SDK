//
//  ViewController.m
//  DoorDuSDKDemo
//
//  Created by DoorDu on 2018/1/5.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "LoginViewController.h"
#import <DoorDuSDK/DoorDuSDK.h>
#import "AppDelegate.h"

@interface LoginViewController ()
// 用户账号输入框
@property (weak, nonatomic) IBOutlet UITextField *accountField;
@end

@implementation LoginViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)login:(id)sender {
    
    [SVProgressHUD showWithStatus:@"初始化中..."];
    // 登录成功之后，初始化sdk信息
    __weak typeof(self) weakSelf = self;
    [DoorDuDataManager loginSDKWithNationCode:@"86" mobileNo:self.accountField.text openId:nil completion:^(BOOL isSuccess, DoorDuError *error) {
        [SVProgressHUD dismiss];
        if (isSuccess) {
            AppDelegate *appDelegate = [UIApplication sharedApplication].delegate;
            appDelegate.mobileNo = weakSelf.accountField.text;
            [appDelegate loginSuccess];
            
            // 保存登录用户信息
            NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
            [userDefaults setObject:self.accountField.text forKey:@"accountName"];
            [userDefaults synchronize];
        }else {
            [DDProgressHUD showCenterWithText:[NSString stringWithFormat:@"SDK初始化失败 -- Reason:%@", error.message] duration:2.0];
        }
    }];
}

- (void)dealloc
{
    NSLog(@"\ndealloc: %@\n",NSStringFromClass([self class]));
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
