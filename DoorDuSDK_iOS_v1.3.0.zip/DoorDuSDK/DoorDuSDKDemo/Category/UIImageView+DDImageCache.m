//
//  UIImageView+DDImageCache.m
//  DoorDuSDKDemo
//
//  Created by 刘和东 on 2018/1/26.
//  Copyright © 2018年 DoorDu. All rights reserved.
//

#import "UIImageView+DDImageCache.h"
#import <objc/runtime.h>
#import <DoorDuSDK/DoorDuDataManager.h>
#import "UIImage+MultiFormat.h"

static char ddImageCacheImageURLKey;


@implementation UIImageView (DDImageCache)

- (nullable NSURL *)dd_imageURL {
    if (self) {
        return objc_getAssociatedObject(self, &ddImageCacheImageURLKey);
    }
    return nil;
}

- (void)dd_setImageWithURL:(nullable NSURL *)url {
    [self dd_setImageWithURL:url placeholderImage:nil options:0 progress:nil completed:nil];
}

- (void)dd_setImageWithURL:(nullable NSURL *)url placeholderImage:(nullable UIImage *)placeholder {
    [self dd_setImageWithURL:url placeholderImage:placeholder options:0 progress:nil completed:nil];
}

- (void)dd_setImageWithURL:(nullable NSURL *)url placeholderImage:(nullable UIImage *)placeholder options:(SDWebImageOptions)options {
    [self dd_setImageWithURL:url placeholderImage:placeholder options:options progress:nil completed:nil];
}

- (void)dd_setImageWithURL:(nullable NSURL *)url completed:(nullable SDExternalCompletionBlock)completedBlock {
    [self dd_setImageWithURL:url placeholderImage:nil options:0 progress:nil completed:completedBlock];
}

- (void)dd_setImageWithURL:(nullable NSURL *)url placeholderImage:(nullable UIImage *)placeholder completed:(nullable SDExternalCompletionBlock)completedBlock {
    [self dd_setImageWithURL:url placeholderImage:placeholder options:0 progress:nil completed:completedBlock];
}

- (void)dd_setImageWithURL:(nullable NSURL *)url placeholderImage:(nullable UIImage *)placeholder options:(SDWebImageOptions)options completed:(nullable SDExternalCompletionBlock)completedBlock {
    [self dd_setImageWithURL:url placeholderImage:placeholder options:options progress:nil completed:completedBlock];
}

- (void)dd_setImageWithURL:(nullable NSURL *)url
          placeholderImage:(nullable UIImage *)placeholder
                   options:(SDWebImageOptions)options
                  progress:(nullable SDWebImageDownloaderProgressBlock)progressBlock
                 completed:(nullable SDExternalCompletionBlock)completedBlock {
    
    NSString * urlString = @"";
    if ([url isKindOfClass:NSURL.class]) {
        urlString = url.absoluteString;
    }
    if ([url isKindOfClass:NSString.class]) {
        urlString = (NSString *)url;
    }
    //网址无效
    if (urlString.length == 0) {
        //        (UIImage * _Nullable image, NSError * _Nullable error, SDImageCacheType cacheType, NSURL * _Nullable imageURL)
        if (placeholder) {
            dispatch_main_async_safe(^{
                [self dd_setImage:placeholder];
            });
        }
        if (completedBlock) {
            completedBlock(nil,[NSError errorWithDomain:NSURLErrorDomain code:NSURLErrorFileDoesNotExist userInfo:nil],SDImageCacheTypeNone,url);
        }
        return;
    }
    url = [NSURL URLWithString:urlString];
    
    NSString *key = [[SDWebImageManager sharedManager] cacheKeyForURL:url];
    /** 判断 本地 是否存在 */
    UIImage * image =  [[SDWebImageManager sharedManager].imageCache imageFromCacheForKey:key];
    if (image) {
        dispatch_main_async_safe(^{
            [self dd_setImage:image];
        });
        if (completedBlock) {
            completedBlock(image,nil,SDImageCacheTypeMemory,url);
        }
        return;
    }
    
    /**缓存中不存在 ， 这里先显示 placeholder*/
    if (placeholder) {
        dispatch_main_async_safe(^{
            [self dd_setImage:placeholder];
        });
    } else {
        dispatch_main_async_safe(^{
            self.image = nil;
        });
    }
    
    
    objc_setAssociatedObject(self, &ddImageCacheImageURLKey, url, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    
    
    __weak typeof(self)weakSelf = self;
    [DoorDuDataManager downloadWithImageObjectKey:key success:^(NSData *imageData,NSString * imageObjectKey) {
        __strong __typeof (weakSelf) strongSelf = weakSelf;
        UIImage * dImage = [UIImage sd_imageWithData:imageData];
        [[SDWebImageManager sharedManager] saveImageToCache:dImage forURL:[NSURL URLWithString:imageObjectKey]];
        
        NSURL * cacheUrl = [strongSelf dd_imageURL];
        if (cacheUrl) {
            NSString * cacheUrlKey = [[SDWebImageManager sharedManager] cacheKeyForURL:cacheUrl];
            if ([cacheUrlKey isEqualToString:imageObjectKey]) {
                if (strongSelf) {
                    dispatch_main_async_safe(^{
                        [strongSelf dd_setImage:dImage];
                        if (completedBlock) {
                            completedBlock(dImage,nil,SDImageCacheTypeMemory,cacheUrl);
                        }
                    });
                }
            }
        }
        
    } failure:^(NSString *imageObjectKey) {
        __strong __typeof (weakSelf) strongSelf = weakSelf;
        NSURL * cacheUrl = [strongSelf dd_imageURL];
        if (cacheUrl) {
            NSString * cacheUrlKey = [[SDWebImageManager sharedManager] cacheKeyForURL:cacheUrl];
            if ([cacheUrlKey isEqualToString:imageObjectKey]) {
                if (strongSelf) {
                    dispatch_main_async_safe(^{
                        if (completedBlock) {
                            completedBlock(nil,[NSError errorWithDomain:NSURLErrorDomain code:NSURLErrorUnknown userInfo:nil],SDImageCacheTypeNone,cacheUrl);
                        }
                    });
                    objc_setAssociatedObject(strongSelf, &ddImageCacheImageURLKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
                }
            }
        }
    }];
    
}
- (void)dd_setImage:(UIImage *)image {
    if ([self isKindOfClass:[UIImageView class]]) {
        UIImageView *imageView = (UIImageView *)self;
        imageView.image = image;
    }
    if ([self isKindOfClass:[UIButton class]]) {
        UIButton *button = (UIButton *)self;
        [button setImage:image forState:UIControlStateNormal];
    }
}


@end
