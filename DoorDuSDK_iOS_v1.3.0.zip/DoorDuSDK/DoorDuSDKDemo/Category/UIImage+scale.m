//
//  UIImage+scale.m
//  DoorduSDK
//
//  Created by Doordu on 2017/4/17.
//  Copyright © 2017年 深圳市多度科技有限公司. All rights reserved.
//

#import "UIImage+scale.h"

@implementation UIImage (scale)

+ (UIImage *)scaleImageToScale:(float)scale image:(UIImage *)image {
    CGFloat w = image.size.width;
    CGFloat h = image.size.height;
    UIGraphicsBeginImageContext(CGSizeMake(w * scale, h * scale));
    [image drawInRect:CGRectMake(0, 0, w * scale, h * scale)];
    UIImage *scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return scaledImage;
}

/**返回压之后的NSData，这里没有缩放，只是像素压缩*/
- (NSData *)pressImage2DataWithScale:(CGFloat)scale
{
    NSData *d = UIImageJPEGRepresentation(self, scale);
    if (!d) {
        d = UIImagePNGRepresentation(self);
    }
    return d;
}

/**返回压之后的image，这里是对长宽压缩，像素无压缩*/
- (UIImage *)resizeImageWithScale:(CGFloat)scale
{
    CGFloat imageWidth = self.size.width;
    CGFloat imageHeight = self.size.height;
    NSInteger width = imageWidth*scale;
    NSInteger height = imageHeight*scale;
    CGSize size = CGSizeMake(width, height);
    UIGraphicsBeginImageContext(size);
    //获取上下文内容
    CGContextRef ctx= UIGraphicsGetCurrentContext();
    CGContextTranslateCTM(ctx, 0.0, size.height);
    CGContextScaleCTM(ctx, 1.0, -1.0);
    //重绘image
    CGContextDrawImage(ctx,CGRectMake(0.0f, 0.0f, size.width, size.height), self.CGImage);
    //根据指定的size大小得到新的image
    UIImage* scaled= UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return scaled;
}

/**返回压之后的NSData，这里是对长宽、像素同时压缩*/
- (NSData *)resizePressImage2DataScale:(CGFloat)scale
{
    return [[self resizeImageWithScale:scale] pressImage2DataWithScale:scale];
}

@end
