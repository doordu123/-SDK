//
//  UIImage+scale.h
//  DoorduSDK
//
//  Created by Doordu on 2017/4/17.
//  Copyright © 2017年 深圳市多度科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (scale)


+ (UIImage *)scaleImageToScale:(float)scale image:(UIImage *)image;

/**返回压之后的NSData，这里没有缩放，只是像素压缩*/
- (NSData *)pressImage2DataWithScale:(CGFloat)scale;

/**返回压之后的image，这里是对长宽压缩，像素无压缩*/
- (UIImage *)resizeImageWithScale:(CGFloat)scale;

/**返回压之后的NSData，这里是对长宽、像素同时压缩*/
- (NSData *)resizePressImage2DataScale:(CGFloat)scale;

@end
