﻿#ifndef SIP_ENGINE_FACTORY_HXX
#define SIP_ENGINE_FACTORY_HXX

#include "sip_engine_types.hxx"

/**
\mainpage 欢迎使用捷智云SIP 客户端SDK, (适用范围:Win32,iOS,Mac,Linux 平台)。
协议标准:\n
  SIP RFC3261\n
  RTP/RTCP/RTCP-fb音视频传输\n
  SIP SIMPLE 文字消息\n
  STUN (协助P2P穿透)\n
  TLSv1 SIP信令加密（保护信令传输层安全）\n
  DTLS-SRTP 媒体加密基于Cisco媒体加密标准\n
  ICE (Interactive Connectivity Establishment) 媒体流P2P协商\n
  TURN 媒体流转发\n
  FEC (Forward error correction) 在3G或较差网络传输环境中进行丢包保护\n
*/

namespace client {

class SipEngine;

/**
@brief 用于创建 SipEngine 对象.

SipEngineFactory::Create 创建SipEngine对象\n
SipEngineFactory::Delete 销毁SipEngine对象\n

调用范例:
@code
client::Config s_config;

SipEngine* sip_engine = SipEngineFactory::Create(s_config);
// ... do stuff ...
SipEngineFactory::Delete(sip_engine);

@endcode 
*/
class SipEngineFactory
{
public:
    /**@brief 用于创建 SipEngine 对象.
    * \param config 客户端唯一 Config 配置项实例，注意: 请确保该对象在整个程序生命周期中可用.
    * \return 返回 SipEngine 指针对象.
    */
    static ENGINE_API SipEngine* Create(Config& config);
    /**@brief 用于销毁 SipEngine 对象.
    * \param engine 传入 SipEngine 对象指针,由工厂类销毁.
    * \return 返回true为成功.
    */
    static ENGINE_API bool Delete(SipEngine*& engine);
};

}; //namespace client

#endif
