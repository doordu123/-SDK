﻿#ifndef SIP_PROFILE_MANAGER_HXX
#define SIP_PROFILE_MANAGER_HXX

#include <string>
#include <list>

namespace client
{
class SipProfile;

typedef std::list<SipProfile *> SipProfileList;

class SipProfileManager {
public:
    /** 创建一个SipProfile*/
    virtual SipProfile* createSipProfile(const char *profile_name) = 0;
    /** 选取一个SipProfile*/
    virtual SipProfile* selectSipProfile(const char *profile_name) = 0;
    /** 删除一个SipProfile*/
    virtual bool deleteSipProfile(SipProfile* profile) = 0;
    /** 获取当前SipProfileMap*/
    virtual SipProfileList& getSipProfileMaps() = 0;

protected:
    ~SipProfileManager(){}
};

}; //namespace client

#endif

