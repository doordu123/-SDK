﻿#ifndef B2BUA_TRANSPORT_LAYER_HXX
#define B2BUA_TRANSPORT_LAYER_HXX

#include "MediaParams.hxx"

#include <map>
#include <string>

namespace client
{
    class MediaEncryptFilter;

    enum IceState {
        kIceNone = 0,
        kIceNew,
        kIceGathering,
        kIceWaiting,
        kIceChecking,
        kIceConnected,
        kIceCompleted,
        kIceUpdated,
        kIceFailed,
        kIceClosed,
    };

    class DataConsumer
    {
    public:
        /**收到RTP数据*/
        virtual void OnIncomingRTPPacket(const char *buf, int len){};

        /**收到RTCP数据*/
        virtual void OnIncomingRTCPPacket(const char *buf, int len){};
        
        /**收到DTLS裸数据*/
        virtual void OnIncomingRawPacket(const char *buf, int len){};

        /**数据传输超时*/
        virtual void OnDataReceviedTimeout() = 0;
    };

class ChannelTransport
{
public:
    virtual int SendRTPPacket(const char *buf, int len) = 0;

    virtual int SendRTCPPacket(const char *buf, int len) = 0;

    virtual bool DtlsHandshakeCompleted() = 0;

    virtual int SendRawPacket(const char *buf, int len) = 0;

    virtual void RegisterDataConsumer(DataConsumer *data_callback) = 0;

    virtual bool Start() = 0;

    virtual bool Stop() = 0;

protected:
    ~ChannelTransport(){}
};

class IceTransportObserver
{
public:
    /**回调ICE状态*/
    virtual void OnIceStateChange(IceState state) = 0;
protected:
    ~IceTransportObserver(){}
};

class DtlsTransportObserver
{
public:
    /**回调DTLS 协商成功*/
    virtual void OnDtlsTransportReady() = 0;
protected:
    ~DtlsTransportObserver(){}
};

class TransportLayer
{
public:
    virtual int RegisterIceTransportObserver(IceTransportObserver *ice_cb) = 0;

    virtual void DeRegisterIceTransportObserver() = 0;

    virtual int Initialize(IceConfig *ice_cfg = NULL) = 0;

    virtual int Terminate() = 0;

    virtual ChannelTransport *CreateChannelTransport(
        std::string label,
        TransportLayerParams& local_params,
        TransportLayerParams& remote_params,
        bool data_channel = false) = 0;

    virtual void DeleteChannelTransport(ChannelTransport *channel_transport) = 0;

    virtual int Start() = 0;

    virtual int Stop() = 0;

    virtual bool IceStartNegotiation() = 0;

    virtual IceState GetIceState() = 0;

protected:
    ~TransportLayer(void){}

};

class TransportLayerFactory
{
public:
    static TransportLayer *Create(MediaParams& media_params, MediaEncryptFilter *enc_filter = NULL);
    static void Delete(TransportLayer *trans);
};

}; //namespace client
#endif

