﻿#ifndef CLIENT_AUDIO_STREAM_INFTER_FACE_HXX
#define CLIENT_AUDIO_STREAM_INFTER_FACE_HXX

#include "media_common_types.h"
#include "RTCVoiceEngine.hxx"

namespace client
{
    /** @brief DTMF 按键事件监听器
    *   用于监听对方发过来的dtmf按键信号。
    */
class TelephoneEventListener
{
public:
    /** @brief 收到按键信号
    *\param tone 信号为 [1-9,*,0,#,A,B,C,D] 其中之一
    */
    virtual void TelephoneEvent(const char *tone) = 0;

protected:
    ~TelephoneEventListener(){};
};

/** @brief 当前音频流网络质量统计信息.
* 音频呼叫统计数据结构,
* 用来描述当前音频通道的
* 丢包率，延迟，抖动等信息。
*/
struct CallStatistics
{
    unsigned short fractionLost; /**<瞬时丢包*/
    unsigned int cumulativeLost; /**<累计丢包*/
    unsigned int extendedMax;
    unsigned int jitterSamples;
    int rttMs;/**<语音数据包延迟，单位毫秒*/
    size_t bytesSent;/**<语音数据发送字节数*/
    int packetsSent;/**<语音数据发送包个数*/
    size_t bytesReceived;/**<语音数据接收字节数*/
    int packetsReceived;/**<语音数据接收包个数*/
    int64_t capture_start_ntp_time_ms_; /**< The capture ntp time (in local timebase) of the first played out audio frame.*/
};

/**@brief 音频流对象,无法被外部创建,仅可由 client::MediaStream::audio_stream(); 方法获取
*/
class AudioStream
{
public:
    /**@brief 设置当前音频收发状态
    * \param direction 媒体流状态
    */
    virtual int SetMediaDirection(StreamParams::MediaDirection direction) = 0;

    /**@brief 获取当前媒体流状态
    * \return 媒体流状态
    */
    virtual StreamParams::MediaDirection GetMediaDirection() = 0;

    /**@brief 发送DTMF信号
    * \param tone 为[0-9,*,#]的字符串.
    * \param outBand 是否带外(RFC2833)发送
    * \param play_dtmf_tone_locally 是否同时本地播放
    * \return void
    */
    virtual void SendDtmf(const char *tone, bool outBand, bool play_dtmf_tone_locally) = 0;
    /**播放DTMF按键音*/
    virtual int PlayDtmfTone(const char *tone, int lengthMs = 200, int attenuationDb = 10) = 0;
    /**调整输出音量，软件增益 [0.1 - 9.9] 默认为1.0*/
    virtual int SetOutputVolumeScaling(float scaling) = 0;
    /**获取当前音频的电平值，用于音量示波器*/
    virtual unsigned int GetSpeechOutputLevel() = 0;
    /**保持音频*/
    virtual int SetOnHoldStatus(bool enabled, RTCVoiceEngine::OnHoldModes mode) = 0;
    /**获取当前音频保持状态*/
    virtual int GetOnHoldStatus(bool& enabled, RTCVoiceEngine::OnHoldModes& mode) = 0;
    /**麦克风静音*/
    virtual int MuteMic( bool yesno) = 0;
    /**获取麦克风静音状态*/
    virtual int GetMicMute(bool& enabled) = 0;
    /**扬声器静音*/
    virtual int MuteSpk(bool yesno) = 0;
    /**获取扬声器静音状态*/
    virtual int GetSpkMute(bool& enabled) = 0;
    /**获取呼叫统计信息*/
    virtual int GetCallStatistics(CallStatistics &stats) = 0;
    /**获取当前通话编码*/
    virtual int GetCodecDesc(CodecDesc &codec) = 0;
    /**注册RFC2833 DTMF监听器*/
    virtual void RegisterTelephoneEventListener(TelephoneEventListener *telephone_event_listener) = 0;
    /**移除RFC2833 DTMF监听器*/
    virtual void DeRegisterTelephoneEventListener() = 0;
    /**检查当前音频通道是否可用*/
    virtual bool AudioStreamIsAvailable() = 0;
protected:
    ~AudioStream(){}
};

};//namespace client

#endif