﻿#ifndef SIP_ENGINE_API_TYPES_HXX
#define SIP_ENGINE_API_TYPES_HXX

#ifdef ENGINE_API_EXPORTS
#define ENGINE_API __declspec(dllexport)
#elif ENGINE_API_DLL
#define ENGINE_API __declspec(dllimport)
#elif defined(ANDROID) || defined(__APPLE__) || defined(__linux__)
#define ENGINE_API __attribute__ ((visibility("default")))
#else
#define ENGINE_API extern
#endif

#include <string>
#include <vector>

namespace client {

    enum { kNumOfStringLength = 64 };
    enum { kNumOfLogStringLength = 512 };
    enum { kMaxNumOfTlsCertificatesSize = 8 };
    /**
    * SipEngine 全局配置对象
    */
    struct Config
    {
        Config()
        {
            strcpy(user_agent, "Client v2.0");
        }
        /** 本地监听端口，地址等信息*/
        struct Transport {
            Transport()
                : udp_port(5060)
                , tcp_port(5060)
                , tls_port(5061)
                , ws_port(5080)
                , wss_port(5081)
                , use_ipv4(true)
                , use_ipv6(true)
            {
                strcpy(bind_addr, "0.0.0.0");
                strcpy(bind_ipv6_addr, "::");
            }
            int udp_port;
            int tcp_port;
            int tls_port;
            int ws_port;
            int wss_port;
            bool use_ipv4;
            bool use_ipv6;

            char bind_addr[kNumOfStringLength];
            char bind_ipv6_addr[kNumOfStringLength];
        } transport;
        /** TLS 传输加密信息*/
        struct Security {
            Security()
            {
                memset(certificate_path, 0, kNumOfStringLength);
                memset(ca_directory, 0, kNumOfStringLength);
                memset(ca_file, 0, kNumOfStringLength);
            }
            char certificate_path[kNumOfStringLength];
            char ca_directory[kNumOfStringLength];
            char ca_file[kNumOfStringLength];

            struct TlsCertificate {
                TlsCertificate()
                {
                    memset(tls_domain, 0, kNumOfStringLength);
                    memset(tls_cert, 0, kNumOfStringLength);
                    memset(tls_private_key, 0, kNumOfStringLength);
                    memset(tls_private_key_password, 0, kNumOfStringLength);
                }
                char tls_domain[kNumOfStringLength];
                char tls_cert[kNumOfStringLength];
                char tls_private_key[kNumOfStringLength];
                char tls_private_key_password[kNumOfStringLength];
            };
            TlsCertificate tls_certificates[kMaxNumOfTlsCertificatesSize];
        } security;
        /**媒体信息设置，编解码器
        *  音频端口范围,stun/turn 服务器
        */
        struct MediaOptions {
            MediaOptions()
                :
                stun_port(19302),
                rtp_port_start(10000),
                rtp_port_end(65535),
                mtu(1200),
                rtp_packet_timeout_ms(5000),
                use_turn_for_callee(false),
                video_bandwidth(512),
                audio_bandwidth(128)
            {
                strcpy(audio_codecs, "opus,isac,g729,pcma,pcmu");
                strcpy(video_codecs, "vp8,vp9,h264,red,ulpfec,rtx");
                strcpy(stun_server, "stun.l.google.com");
                memset(turn_username, 0, kNumOfStringLength);
                memset(turn_password, 0, kNumOfStringLength);
            }

            int rtp_port_start;
            int rtp_port_end;
            int rtp_packet_timeout_ms;

            /**
            * SDP 带宽描述
            * b=AS:带宽
            * audio 默认 128kbps
            * video 默认 512kpbs
            */
            int audio_bandwidth;
            int video_bandwidth;

            char stun_server[kNumOfStringLength];
            unsigned short stun_port;

            char turn_username[kNumOfStringLength];
            char turn_password[kNumOfStringLength];

            char audio_codecs[kNumOfStringLength];
            char video_codecs[kNumOfStringLength];
            int mtu;

            bool use_turn_for_callee;
        } media_options;

        /** SIP UserAgent 用户代理名称配置*/
        char user_agent[kNumOfStringLength];
        /**日志系统*/
        struct Log
        {
            enum Level
            {
                None = -1,
                Crit = 0,
                Err = 1,
                Warning = 2,
                Info = 3,
                Notice = 4,
                Debug = 5,
                Stack = 6,
                StdErr = 7,
                All = 99
            };

            Log() :
                log_level(Info),
                log_on(false)
            {
                strcpy(sip_trac_file, "sip_trac.txt");
            }
            Level log_level;
            bool log_on;
            char sip_trac_file[kNumOfLogStringLength];
        } log_settings;
    };

};//namespace 



#endif
