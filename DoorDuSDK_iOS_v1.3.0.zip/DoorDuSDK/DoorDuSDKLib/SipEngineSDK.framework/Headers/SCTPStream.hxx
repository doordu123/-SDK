﻿#ifndef CLIENT_DATA_CHANNEL_STREAM_INFTER_FACE_HXX
#define CLIENT_DATA_CHANNEL_STREAM_INFTER_FACE_HXX

#include "MediaParams.hxx"

namespace client {

    enum DataType
    {
        kText = 0,
        kBinary
    };

    /**数据通道数据接收监听
    */
    class SCTPDataReceiver
    {
    public:
        /**收到来自对端的数据*/
        virtual void OnPacketReceived(unsigned int sid, DataType type, const char *buf, int len) = 0;
    protected:
        ~SCTPDataReceiver(){}
    };

    class SCTPStream {
    public:
        /**发送数据*/
        virtual int SendPacket(unsigned int sid, DataType type, const char *buf, int len) = 0;
        /**注册数据接收器*/
        virtual int RegisterSCTPDataReceiver(SCTPDataReceiver *receiver) = 0;
        /**移除数据接收器*/
        virtual void DeRegisterSCTPDataReceiver() = 0;

        virtual int SetMediaDirection(StreamParams::MediaDirection direction) = 0;

        virtual StreamParams::MediaDirection GetMediaDirection() = 0;

    protected:
        ~SCTPStream(){}
    };

};//namespace client

#endif