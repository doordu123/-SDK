#ifndef MEDIA_ENGINE_FACTORY_HXX
#define MEDIA_ENGINE_FACTORY_HXX

#include "media_common_types.h"

namespace client {

class MediaEngine;

class MediaEngineFactory
{
public:
    MEDIA_ENGINE_API static MediaEngine *Create();
    MEDIA_ENGINE_API static bool Delete(MediaEngine*& media_stream);
};

};// namespace client

#endif
