﻿#ifndef TRANSPORT_LAYER_TYPES_HXX
#define TRANSPORT_LAYER_TYPES_HXX

#include <iostream>
#include <list>
#include <sstream>
#include <map>

#ifdef WIN32
#ifndef snprintf
#define snprintf _snprintf_s
#endif
#endif

namespace client {

#define DEFAULT_RTP_TIMEOUT 120 // second

    enum SecureMediaCryptoSuite
    {
        SRTP_AES_CM_128_HMAC_SHA1_32,
        SRTP_AES_CM_128_HMAC_SHA1_80
    };

    class IceConfig
    {
    public:
        typedef enum IceSessionRole
        {
            ICE_SESS_ROLE_UNKNOWN = 0,
            ICE_SESS_ROLE_CONTROLLED, //被控
            ICE_SESS_ROLE_CONTROLLING //主控
        } IceSessionRole;

        typedef enum IceMode
        {
            ICE_SESS_MODE_FULL = 0,
            ICE_SESS_MODE_LITE,
        } IceMode;

    public:
        IceConfig()
        {
            role = ICE_SESS_ROLE_CONTROLLING;
            mode = ICE_SESS_MODE_FULL;
            max_host = 1;
            comp_cnt = 1;
            stun_port = 0;
            memset(stun_srv, 0, sizeof(stun_srv));
            memset(turn_user, 0, sizeof(turn_user));
            memset(turn_passwd, 0, sizeof(turn_passwd));
            use_turn = false;
        }

        IceSessionRole role; //主控或被控
        char stun_srv[80];
        int  stun_port;
        char turn_user[80];
        char turn_passwd[80];
        int max_host; /*收集的最大host 数量*/
        unsigned int comp_cnt; /*子通道数量 rtp+rtcp = 2*/
        bool regular;
        bool use_turn;
        IceMode mode;
    };

    class IceCandidate {
    public:
        typedef enum {
            CANDIDATE_TRANSPORT_TYPE_NONE = 0,
            CANDIDATE_TRANSPORT_TYPE_TCP,
            CANDIDATE_TRANSPORT_TYPE_UDP,      // "udp"
        } CandidateTransportType;

        typedef enum {
            CANDIDATE_TYPE_NONE,
            CANDIDATE_TYPE_HOST,        // "host"  - host address
            CANDIDATE_TYPE_SRFLX,       // "srflx" - server reflexive
            CANDIDATE_TYPE_PRFLX,       // "prflx" - peer reflexive
            CANDIDATE_TYPE_RELAY,       // "relay" - relay server
        } CandidateType;
    public:
        char foundation[80];
        unsigned int comp_id;
        CandidateTransportType transport;
        unsigned int priority;
        char address[80];
        int port;
        CandidateType type;
        char related_address[80];
        int related_port;
        //for webrtc
        int generation;

    public:
        IceCandidate()
            : related_port(0)
            , comp_id(0)
            , priority(0)
            , port(0)
            , generation(0)
        {
            memset(foundation, 0, sizeof(foundation));
            memset(address, 0, sizeof(address));
            memset(related_address, 0, sizeof(related_address));
        }

        IceCandidate(IceCandidate *cand){
            copy(*cand);
        };

        IceCandidate& operator=(IceCandidate& cand)
        {
            if (&cand == this)
                return *this;
            return copy(cand);
        };

        IceCandidate& copy(IceCandidate &rhs){
            snprintf(address, sizeof(address), "%s", rhs.address);
            snprintf(foundation, sizeof(foundation), "%s", rhs.foundation);
            snprintf(related_address, sizeof(related_address), "%s", rhs.related_address);
            comp_id = rhs.comp_id;
            port = rhs.port;
            priority = rhs.priority;
            related_port = rhs.related_port;
            transport = rhs.transport;
            type = rhs.type;
            generation = rhs.generation;
            return *this;
        }
    };

    class IceSessionDescription {
    public:
        char ufrag[80];
        char pwd[80];
        std::list<IceCandidate> candidate_list;
        int comp_cnt;
    public:
        IceSessionDescription()
            : comp_cnt(0)
        {
            memset(ufrag, 0, sizeof(ufrag));
            memset(pwd, 0, sizeof(pwd));
        }
        ~IceSessionDescription(){
            candidate_list.clear();
        }
        IceSessionDescription(const IceSessionDescription *desc){
            copy(*desc);
        }

        virtual int AddIceCandidate(IceCandidate *cand)
        {
            /*跳过重复候选*/
            std::list<IceCandidate>::const_iterator it;
            for (it = candidate_list.begin(); it != candidate_list.end(); it++)
            {
                if (strcmp(cand->foundation, (*it).foundation) == 0)
                    return (int)candidate_list.size();
            }
            candidate_list.push_back(*cand);
            return (int)candidate_list.size();
        }

        IceSessionDescription& copy(const IceSessionDescription &desc) {
            snprintf(ufrag, sizeof(ufrag), "%s", desc.ufrag);
            snprintf(pwd, sizeof(pwd), "%s", desc.pwd);
            comp_cnt = desc.comp_cnt;
            candidate_list.clear();
            std::list<IceCandidate>::const_iterator it;
            for (it = desc.candidate_list.begin(); it != desc.candidate_list.end(); it++){
                candidate_list.push_back((*it));
            }
            return *this;
        }

        IceSessionDescription& operator=(const IceSessionDescription& desc) {
            if (&desc == this)
                return *this;
            return copy(desc);
        }

        bool operator==(IceSessionDescription &rhs){
            return (toString() == rhs.toString());
        }

        bool operator!=(IceSessionDescription &rhs){
            return (toString() != rhs.toString());
        }

        std::string  toString() {
            std::ostringstream sdp;
            sdp << "ufrag=" << ufrag << std::endl;
            sdp << "pwd=" << pwd << std::endl;
            sdp << "comp_cnt=" << comp_cnt << std::endl;

            std::list<IceCandidate>::iterator it;
            for (it = candidate_list.begin(); it != candidate_list.end(); it++){
                sdp << "candidate:" << (*it).foundation
                    << " " << (*it).comp_id
                    << " " << (*it).transport
                    << " " << (*it).priority
                    << " " << (*it).address
                    << " " << (*it).port
                    << " " << (*it).type
                    << " " << (*it).related_address
                    << " " << (*it).related_port
                    << " generation " << (*it).generation
                    << std::endl;
            }
            return sdp.str();
        }
    };


    class TransportLayerParams
    {
    public:
        std::list<unsigned int> ssrc;
        unsigned int rtx_payload;
        char srtp_key[256];
        SecureMediaCryptoSuite crypto_type;
        unsigned int rtp_port;
        unsigned int rtcp_port;
        char address[80];
        IceSessionDescription ice_desc;
        char fingerprint[256];
    public:
        TransportLayerParams()
            :rtp_port(0), rtcp_port(0), rtx_payload(96), crypto_type(SRTP_AES_CM_128_HMAC_SHA1_80)
        {
            memset(srtp_key, 0, sizeof(srtp_key));
            memset(address, 0, sizeof(address));
            memset(fingerprint, 0, sizeof(fingerprint));
        }
        ~TransportLayerParams(){}

        TransportLayerParams(const TransportLayerParams *params){
            copy(*params);
        }

        TransportLayerParams& operator=(const TransportLayerParams& rhs){
            if (&rhs == this)
                return *this;
            return copy(rhs);
        }

        TransportLayerParams& copy(const TransportLayerParams &rhs){
            ssrc = rhs.ssrc;
            rtx_payload = rhs.rtx_payload;
            rtcp_port = rhs.rtcp_port;
            rtp_port = rhs.rtp_port;
            strncpy(srtp_key, rhs.srtp_key, sizeof(srtp_key));
            strncpy(address, rhs.address, sizeof(address));
            strncpy(fingerprint, rhs.srtp_key, sizeof(fingerprint));
            ice_desc = rhs.ice_desc;
            crypto_type = rhs.crypto_type;
            return *this;
        }
    };

}; //namespace client

#endif
