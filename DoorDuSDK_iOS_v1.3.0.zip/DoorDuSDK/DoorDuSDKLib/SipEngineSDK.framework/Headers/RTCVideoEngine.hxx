#ifndef RTC_VIDEO_ENGINE_H
#define RTC_VIDEO_ENGINE_H

#include "media_common_types.h"
#include "MediaParams.hxx"

namespace client 
{

class RTCVideoEngine {

public:
    RTCVideoEngine(){}
    ~RTCVideoEngine(){}

    /**��ȡ�����б�*/
	virtual int BuildValidCodecList(CodecDescList& codecList) = 0;

    /**��ȡ����ͷ����*/
    virtual int NumberOfCaptureDevices() = 0;

    /**��ȡ����ͷ����*/
    virtual int GetCaptureDeviceOfIndex(int index,
        char* deviceNameUTF8,
        const unsigned int deviceNameUTF8Length,
        char* uniqueIdUTF8,
        const unsigned int uniqueIdUTF8Length) = 0;

    /**��ȡ�ƶ��豸����ͷ��ת�Ƕ�*/
    virtual int GetCameraOrientation(int cam_index) = 0;

    /**����MTU����䵥Ԫ*/
    virtual int SetMTU(unsigned int mtu) = 0;
};

class RTCVideoEngineFactory
{
public:
    RTCVideoEngineFactory(){}
    ~RTCVideoEngineFactory(){}
#ifdef ANDROID
    MEDIA_ENGINE_API static int SetAndroidObjects(void* javaVM, void* env, void* context);
#endif
    MEDIA_ENGINE_API static RTCVideoEngine* Create(const char *logfile = NULL);
    MEDIA_ENGINE_API static void Delete(RTCVideoEngine*& voice_engine);
};

}; // namespace client

#endif
