﻿#ifndef MEDIA_STREAM_TYPES_HXX
#define MEDIA_STREAM_TYPES_HXX

#ifdef MEDIA_MANAGER_EXPORTS
#define MEDIA_ENGINE_API __declspec(dllexport)
#elif MEDIA_MANAGER_DLL
#define MEDIA_ENGINE_API __declspec(dllimport)
#elif defined(ANDROID) || defined(__APPLE__) || defined(__linux__)
#define MEDIA_ENGINE_API __attribute__ ((visibility("default")))
#else
#define MEDIA_ENGINE_API
#endif

#endif
