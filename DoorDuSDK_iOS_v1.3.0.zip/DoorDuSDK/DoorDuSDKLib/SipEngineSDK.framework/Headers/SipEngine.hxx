﻿#ifndef SIP_CLIENT_ENGINE_V2_API_HXX
#define SIP_CLIENT_ENGINE_V2_API_HXX

#include "sip_engine_types.hxx"

namespace client {

class Call;
class CallManager;
class CallStateObserver;
class SipProfileManager;
class RegistrationManager;
class PagerMessager;
class MediaEngine;

/**
* SipEngine 主接口对象
* SipEngine::RunEventLoop(); 为异步主事件循环
*/
class SipEngine {
public:
    /**初始化*/
    virtual bool Initialize() = 0;
    /**销毁*/
    virtual bool Terminate() = 0;
    /**异步事件，请在主线程中使用Timer执行,间隔 10 - 200 ms*/
    virtual bool RunEventLoop() = 0;
    /**获取账号管理器*/
    virtual SipProfileManager* GetSipProfileManager() = 0;
    /**获取呼叫管理器*/
    virtual CallManager* GetCallManager() = 0;
    /**获取消息管理器*/
    virtual RegistrationManager* GetRegistrationManager() = 0;
    /**获取媒体引擎接口*/
    virtual MediaEngine* GetMediaEngine() = 0;
    /**获取IM消息接口*/
    virtual PagerMessager* GetPagerMessager() = 0;
    /**重置传输模块*/
    virtual void ResetTransport() = 0;
    /**修改log输出级别*/
    virtual void SetLogLevel(Config::Log::Level level) = 0;
    /**添加自定义DNS服务器*/
    virtual void AddDnsServer(const char* dns) = 0;
protected:
    ~SipEngine(){}
};

};// namespace client

#endif
