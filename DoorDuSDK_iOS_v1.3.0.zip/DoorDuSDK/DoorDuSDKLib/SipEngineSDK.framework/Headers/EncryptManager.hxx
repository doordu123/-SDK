﻿#ifndef CUSTOM_ENCRYPT_MANAGER_HXX
#define CUSTOM_ENCRYPT_MANAGER_HXX

#include "sip_engine_types.hxx"

namespace client {
    
    enum EncryptMethod
    {
        kEncryptNone = 0,
        kEncryptRC4,
    };

	class EncryptManager
    {
    public:
        static ENGINE_API EncryptManager* instance();

        virtual void SetEncryptMethod(EncryptMethod method) = 0;

        virtual EncryptMethod GetEncryptMethod() = 0;

        virtual void SetRC4Key(const char *key, int length) = 0;

    protected:
        ~EncryptManager(){}
    };

};//namespace client

#endif