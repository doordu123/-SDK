﻿#ifndef RTC_VOICE_ENGINE_H
#define RTC_VOICE_ENGINE_H

#include "media_common_types.h"
#include "MediaParams.hxx"

namespace client {

class RTCVoiceEngine 
{
public:
    enum NsModes    // type of Noise Suppression
    {
        kNsUnchanged = 0,   // previously set mode
        kNsDefault,         // platform default
        kNsConference,      // conferencing default
        kNsLowSuppression,  // lowest suppression
        kNsModerateSuppression,
        kNsHighSuppression,
        kNsVeryHighSuppression,     // highest suppression
    };

    enum AgcModes                  // type of Automatic Gain Control
    {
        kAgcUnchanged = 0,        // previously set mode
        kAgcDefault,              // platform default
        kAgcAdaptiveAnalog,
        kAgcAdaptiveDigital,
        kAgcFixedDigital
    };

    // EC modes
    enum EcModes                   // type of Echo Control
    {
        kEcUnchanged = 0,          // previously set mode
        kEcDefault,                // platform default
        kEcConference,             // conferencing default (aggressive AEC)
        kEcAec,                    // Acoustic Echo Cancellation
        kEcAecm,                   // AEC mobile
    };

    // AECM modes
    enum AecmModes                 // mode of AECM
    {
        kAecmQuietEarpieceOrHeadset = 0,
        // Quiet earpiece or headset use
        kAecmEarpiece,             // most earpiece use
        kAecmLoudEarpiece,         // Loud earpiece or quiet speakerphone use
        kAecmSpeakerphone,         // most speakerphone use (default)
        kAecmLoudSpeakerphone      // Loud speakerphone
    };

    enum OnHoldModes            // On Hold direction
    {
        kHoldSendAndPlay = 0,    // Put both sending and playing in on-hold state.
        kHoldSendOnly,           // Put only sending in on-hold state.
        kHoldPlayOnly            // Put only playing in on-hold state.
    };
public:
    RTCVoiceEngine(){}
    ~RTCVoiceEngine(){}
    /**获取可用的音频编码列表*/
	virtual int BuildValidCodecList(CodecDescList& codecList) = 0;
    /**设置回声消除模式*/
    virtual int SetAECMode(int enabled, EcModes mode) = 0;
    /**设置自动增益控制*/
    virtual int SetAGCMode(int enabled, AgcModes mode) = 0;
    /**获取降噪模式*/
    virtual int SetNSMode(int enabled, NsModes mode) = 0;
    /**设置扬声器输出音量*/
    virtual int SetSpeakerVolume(int volume) = 0;
    /**获取Mic滑竿位置*/
    virtual int SetMicVolume(int volume) = 0;
    /**获取输入滑竿位置*/
    virtual unsigned int GetSpeakerVolume() = 0;
    /**获取Mic滑竿位置*/
    virtual unsigned int GetMicVolume() = 0;
    /**获取输入音量电平*/
    virtual unsigned int GetSpeechInputLevel() = 0;
    /**获取播放设备列表*/
    virtual int GetNumOfPlayoutDevices() = 0;
    /**获取录音设备列表*/
    virtual int GetNumOfRecordingDevices() = 0;
    /**获取录音设备名称*/
    virtual int GetRecordingDeviceName(int index, char strNameUTF8[128], char strGuidUTF8[128]) = 0;
    /**获取播放设备名称*/
    virtual int GetPlayoutDeviceName(int index, char strNameUTF8[128], char strGuidUTF8[128]) = 0;
    /**获取播放设备是否可用*/
    virtual int GetPlayoutDeviceStatus(bool& isAvailable) = 0;
    /**获取录音设备是否可用*/
    virtual int GetRecordingDeviceStatus(bool& isAvailable) = 0;
    /**设置当前播放设备*/
    virtual int SetPlayoutDevice(int index) = 0;
    /**设置当前录音设备*/
    virtual int SetRecordingDevice(int index) = 0;
    /**设置免提开启/关闭*/
    virtual int SetLoudspeakerStatus(bool yesno) = 0;
};

class RTCVoiceEngineFactory
{
public:
    RTCVoiceEngineFactory(){}
    ~RTCVoiceEngineFactory(){}
#ifdef ANDROID
    MEDIA_ENGINE_API static int SetAndroidObjects(void* javaVM, void* env, void* context);
#endif
    MEDIA_ENGINE_API static RTCVoiceEngine* Create(const char *logfile = NULL);
    MEDIA_ENGINE_API static void Delete(RTCVoiceEngine*& voice_engine);
};

}; // namespace client

#endif
