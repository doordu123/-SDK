﻿#ifndef CLIENT_MEDIA_STREAM_HXX
#define CLIENT_MEDIA_STREAM_HXX

#include "MediaParams.hxx"
#include "TransportLayer.hxx"

namespace client {

    class RTCTransport
    {
    public:
        virtual int SendPacket(int channel, const void *data, int len) = 0;

        virtual int SendRTCPPacket(int channel, const void *data, int len) = 0;

    protected:
        virtual ~RTCTransport() {}
        RTCTransport() {}
    };

    class MediaEncryptFilter
    {
    public:
        virtual int MediaEncrypt(char *data, int length) = 0;

        virtual int MediaDecrypt(char *data, int length) = 0;

    protected:
        virtual ~MediaEncryptFilter() {}
    };

class MediaParams;
class AudioStream;
class VideoStream;
class SCTPStream;

/**媒体超市事件监听*/
class MediaStreamTimeOutEventListener{
public:
    virtual void OnPacketTimeout(void* user_ptr, bool video_channel, const ViEPacketTimeout timeout) = 0;

protected:
    ~MediaStreamTimeOutEventListener(){};
};

/** @brief 媒体流对象
*/
class MediaStream
{

public:
    /** @brief 初始化媒体流
    * \param media_params 媒体流参数集
    * \param datachannel_enabled 是否开启数据通道
    * \param dtls_client dtls server/client 模式设置
    * \param is_caller 是否为主叫
    * \param trans_type 媒体传输协议类型: UDP/ICE
    * \param security_type 媒体加密类型
    * \param ice_cfg ICE 设置参数集
    * \return 0成功，非0失败
    */
    virtual int Initialize(
        bool enable_audio,
        bool enable_video,
        bool enable_sctp,
        IceConfig *ice_cfg) = 0;

    /** @brief 录制呼叫为WAVE文件
    * \param file_name WAVE文件路径例如 C:\record\call_001.wav
    * \return 0成功，非0失败
    */
    virtual int StartWaveRecording(const char *file_name) = 0;

    /*检查是否正在录制*/
    virtual bool InWaveRecording() = 0;

    /*停止WAVE文件录制*/
    virtual int StopWaveRecording() = 0;

#ifdef ENABLE_VIDEO_STREAM
    /** @brief 录制呼叫为mp4文件
    * \param file_name mp4文件路径例如 C:\record\call_001.mp4
    * \param type 录制类型 本地画面或远端画面
    * \param width 视频宽度
    * \param height 视频高度
    * \param fps 帧率
    * \return 0成功，非0失败
    */
    virtual int StartMp4Recording(const char *file_name, RecordStreamType type, int width = 640, int height = 480, int fps = 15) = 0;
    
    /*检查是否正在录制*/
    virtual bool InMp4Recording() = 0;

    /*停止视频录制*/
    virtual int StopMp4Recording() = 0;
#endif

    /**设置媒体超时监听器*/
    virtual void SetMediaStreamEventListener(MediaStreamTimeOutEventListener *cb, void *user_ptr) = 0;
    
    /**获取媒体配置*/
    virtual MediaParams *media_params() = 0;

#ifdef ENABLE_VIDEO_STREAM
    /**获取视频流*/
    virtual VideoStream* video_stream() = 0;
#endif // ENABLE_VIDEO_STREAM

    /**获取音频流*/
    virtual AudioStream* audio_stream() = 0;

    /**获取数据通道*/
    virtual SCTPStream* data_stream() = 0;

    /**获取媒体传输层*/
    virtual TransportLayer *transport_layer() = 0;

    /**获取当前媒体传输协议类型*/
    virtual TransportLayerType trans_type() = 0;

protected:
        ~MediaStream(){}
    };

};//namespace client

#endif