﻿#ifndef SIP_CLIENT_ENGINE_CALL_HXX
#define SIP_CLIENT_ENGINE_CALL_HXX

#include <string>
#include <map>

namespace client
{

class MediaStream;
class SipProfile;
class CallReport;
typedef std::map<std::string, std::string> ExtensionHeaderMap;


/** @brief 呼叫对象类， 由 client::CallManager 以及 client::CallStateObserver 来创建
*
*/
class Call
{
public:

    /**
    *  媒体方向的枚举定义.
    */
    enum MediaDirection
    {
        kNone = 0,
        kSendRecv,     /**< 双向收发*/
        kSendOnly,     /**< 仅发送*/
        kRecvOnly,     /**< 仅接收*/
        kInActive      /**< 暂时不可用*/
    };

    /** @brief DTMF方法.
    *  DTMF方法的枚举定义.
    */
    enum DtmfMethod
    {
        kDtmfRFC2833 = 0, /**< RFC2833带外发送*/
        kDtmfInfo         /**< SIP INFO 信令发送*/
    };

    /**
    *  呼叫方向的枚举定义.
    */
    enum Direction
    {
        kIncoming = 0, /**< 来电*/
        kOutgoing      /**< 去电*/
    };

    /**
    * Call 状态枚举定义
    */
    enum CallState
    {
        kNewCall = 0,  /**< 新呼叫*/
        kCancel,       /**< 呼叫被取消*/
        kFailed,       /**< 失败或错误*/
        kRejected,     /**< 呼叫被拒绝*/
        kEarlyMedia,   /**< 收到彩铃*/
        kRinging,      /**< 对方振铃*/
        kAnswered,     /**< 呼叫接通*/
        kHangup,       /**< 呼叫结束*/
        kPausing,      /**< 设置保持*/
        kPaused,       /**< 呼叫被保持*/
        kResuming,     /**< 设置恢复*/
        kResumed,      /**< 呼叫保持解除*/
        kUpdating,     /**< 设置更新*/
        kUpdated,      /**< 呼叫更新*/
        kReferAccepted,/**< 呼叫转移被接受*/
        kReferRejected,/**< 呼叫转移被拒绝*/
    };

public:
    /** @brief 来电接听*/
    virtual void Accept() = 0;

	/**@brief接听来但不发送音视频数据
    *\param send_audio 是否接听音频流
    *\param send_video 是否接听视频流
    *\return void
    */
	virtual void Accept(bool send_audio, bool send_video) = 0;

    /**@brief拒绝来电
    *\param code 拒绝代码，例如: 用户忙 486, 无法接听 603
    *\param reason 拒绝原因，例如: BusyHere
    *\param void
    */
    virtual void Reject(int code, const char* reason = NULL) = 0;

    /**@brief发送dtmf按键
    *\param dtmf_method 发送方式，带内 RFC2833, INFO
    *\param tone [0-9,*,#] 等单个字符
    *\param play_dtmf_tone 是否在本地声卡中播放按键音
    *\return 0 成功，非0失败
    */
    virtual int SendDtmf(DtmfMethod dtmf_method, const char *tone, bool play_dtmf_tone = false) = 0;

	/**@brief转接呼叫
    *\param dst_number 需要转接的号码
    *\return 0 成功，非0失败
    */
	virtual int Transfer(const char *dst_number) = 0;

    /**@brief挂断呼叫*/
    virtual int Hangup() = 0;

    /**@brief呼叫音视频更新
    *\param enable_video 开启或关闭视频流
    *\return 0 成功，非0失败
    */
    virtual int UpdateCall(bool enable_video) = 0;

    /**@brief保持*/
    virtual int Hold() = 0;

    /**@brief恢复*/
    virtual int UnHold() = 0;

public: /**@brief属性或状态接口*/

    /**@brief获取当前呼叫ID字符串*/
    virtual const char* caller_id() = 0;

    /**@brief当前方向,去电 or 来电*/
    virtual Direction direction() = 0;

    /**@brief获取当前Call的状态*/
    virtual CallState call_state() = 0;

    /**@brief当前呼叫是否支持视频*/
    virtual bool support_video() = 0;

    /**@brief当前呼叫是否支持数据*/
    virtual bool support_data() = 0;

    /**@brief获取当前呼叫的账户信息*/
    virtual SipProfile* profile() = 0;

    /**@brief获取当前呼叫的媒体流接口*/
    virtual MediaStream* media_stream() = 0;

	/**@brief强制支持早期媒体接听*/
	virtual void set_support_early_answer(bool yesno) = 0;
    /**@brief获取呼叫中SIP扩展键值对*/
    virtual const ExtensionHeaderMap& get_extension_header_map() = 0;

public:
    /**@brief 当呼叫为 kFailed 或 kRejected 是获取错误代码和原因*/
    virtual int GetErrorCode() = 0;

    /**@brief 获取呼叫失败的错误原因字串 */
    virtual const char* GetErrorReason() = 0;

    /**@brief 获取通话详单*/
    virtual const CallReport *GetCallReport() = 0;

    /**@brief 获取当前呼叫状态描述字符串*/
    virtual const char* CallStateName(CallState state) = 0;

    /**@brief 呼叫对象名*/
    virtual const char* toString() = 0;

	/**@brief 获取from device 参数名称*/
	virtual bool GetDeviceType(char *device_type) = 0;

public:
    /**@brief 设置自定义指针*/
    virtual void SetUserData(void *data) = 0;

    /**@brief 获取自定义指针*/
    virtual void *GetUserData() = 0;

protected:
    ~Call(){}
};

};//namespace client

#endif
