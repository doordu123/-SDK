﻿#ifndef SIP_CLIENT_REGISTER_HXX
#define SIP_CLIENT_REGISTER_HXX

namespace client {

class SipProfile;

enum RegistrationErrorCode {
    kForbidden = 403,
    kNotFound = 404,
    kRequestTimeout = 408,
    kNetworkUnreachable = 477,
};

/* @brief 注册事件回调
* SIP 账号注册回调监听器
*/
class RegistrationObserver
{
public:
    /** @brief 开始注册*/
    virtual void OnRegistrationProgress(SipProfile *profile) = 0;
    /** @brief 注册成功*/
    virtual void OnRegistrationSuccess(SipProfile *profile) = 0;
    /** @brief 注销成功*/
    virtual void OnRegistrationCleared(SipProfile *profile) = 0;
    /** @brief 注册失败*/
    virtual void OnRegistrationFailed(SipProfile *profile, int code, const char *reason) = 0;

protected:
    ~RegistrationObserver(){}
};

/** @brief SIP 注册管理器
* 使用注册管理器来注册/注销/刷新 SipProfile
*
调用范例:
@code
SipProfileManager *profile_manager = sip_engine->GetSipProfileManager();
SipProfile* profile = profile_manager->selectSipProfile("main_profile");

//设置账户信息
profile->set_username("alice");
profile->set_password("password");
profile->set_domain("sip.cloudwebrtc.com");
profile->transport = TCP;

RegistrationManager *register_manager = sip_engine->GetRegistrationManager();

//注册账号
register_manager->MakeRegister(profile);

//注销
register_manager->MakeDeRegister(profile);

//刷新
register_manager->RefreshRegistration(profile);

@endcode
*/
class RegistrationManager
{
public:
    /** @brief 使用Profile文件发送注册消息*/
    virtual void MakeRegister(SipProfile *sip_profile) = 0;
    /** @brief 使用Profile文件发送注销消息*/
    virtual void MakeDeRegister(SipProfile *sip_profile) = 0;
    /** @brief 刷新注册*/
    virtual void RefreshRegistration(SipProfile *sip_profile) = 0;
    /** @brief 注册事件监听器*/
    virtual void RegisterRegistrationObserver(RegistrationObserver *observer) = 0;
    /** @brief 移除注册监听器*/
    virtual void DeRegisterRegistrationObserver() = 0;
    /** @brief 通知底层网络是否可用*/
    virtual void SetNetworkReachable(bool yesno) = 0;
    /** @brief 检测Profile 是否已注册*/
    virtual bool ProfileIsRegistered(SipProfile *sip_profile) = 0;

protected:
    ~RegistrationManager(){}
};

};//namespace client

#endif
