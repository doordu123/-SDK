﻿#ifndef CLIENT_VIDEO_STREAM_INFTER_FACE_HXX
#define CLIENT_VIDEO_STREAM_INFTER_FACE_HXX

#include "MediaParams.hxx"

namespace client {
 
/**关键帧请求监听*/
class RequestNewKeyFrameListener {
public:
    virtual void RequestNewKeyFrameEvent() = 0;
protected:
    ~RequestNewKeyFrameListener(){};
};


/** 视频帧率，尺寸，码率监听器*/
class VideoStreamObserver {
public:
    virtual void IncomingFrameSizeChanged(const int video_channel,
        unsigned short width,
        unsigned short height) = 0;

    virtual void IncomingRate(const int video_channel,
        const unsigned int framerate,
        const unsigned int bitrate) = 0;

    virtual void OutgoingRate(const int video_channel,
        const unsigned int framerate,
        const unsigned int bitrate) = 0;

protected:
    virtual ~VideoStreamObserver() {}
};

/** 外部渲染接口*/
class ExternalRenderer {
public:
    virtual int FrameSizeChange(unsigned int width,
        unsigned int height,
        unsigned int number_of_streams) = 0;

    virtual int DeliverFrame(unsigned char* buffer,
        int buffer_size,
        // RTP timestamp in 90kHz.
        uint32_t timestamp,
        // NTP time of the capture time in local timebase
        // in milliseconds.
        int64_t ntp_time_ms,
        // Wallclock render time in milliseconds.
        int64_t render_time_ms,
        // Handle of the underlying video frame.
        void* handle) = 0;

    // Returns true if the renderer supports textures. DeliverFrame can be called
    // with NULL |buffer| and non-NULL |handle|.
    virtual bool IsTextureSupported() = 0;

protected:
    virtual ~ExternalRenderer() {}
};

/** 视频流接口*/
class VideoStream
{
public:
    /**设置视频参数*/
    virtual int SetupVideoStream(int camera_index,
        void *local_window_id,
        void *remote_window_id,
        ExternalRenderer *local_renderer = NULL,
        ExternalRenderer *remote_renderer = NULL,
        int rotation = 0,
        unsigned short width = 640,
        unsigned short height = 480,
        int bitrate = 512,
        int fps = 15) = 0;

    /**连接语音通道同步音唇*/
    virtual int ConnectVoiceChannel(int voice_channel) = 0;
    /**设置VideoStream通道媒体状态*/
    virtual int SetMediaDirection(StreamParams::MediaDirection direction) = 0;
    /**获取当前通道媒体状态*/
    virtual StreamParams::MediaDirection GetMediaDirection() = 0;
    /**检查当前视频通道是否可用*/
    virtual bool VideoStreamIsAvailable() = 0;
    /**关键帧请求回调,例如要求SIP INFO请求关键祯*/
    virtual int RegisterNewKeyFrameListener(RequestNewKeyFrameListener *cb) = 0;
    /**注册发送/接收帧率，视频尺寸变更时间*/
    virtual int RegisterVideoStreamObserver(VideoStreamObserver *cb) = 0;
    /**强制发送关键祯*/
    virtual int SendKeyFrame() = 0;
    /**呼叫实时参数修改*/
    virtual int ChangeCaptureVideoSize(unsigned short width, unsigned short height) = 0;
    /**修改发送码率*/
    virtual int ChangeSendBitRate(int bitrate ) = 0;
    /**切换摄像头*/
    virtual int ChangeCamera(int camera_index, int rotation_new, void *local_window_id = NULL, ExternalRenderer *local_renderer = NULL) = 0;
    /**修改远端渲染器*/
    virtual int ChangeRemoteRender(void *remote_window_id, ExternalRenderer *remote_renderer = NULL) = 0;
    /**修改本端渲染器*/
    virtual int ChangeLocalRender(void *local_window_id, ExternalRenderer *local_renderer = NULL) = 0;
    /**获取当前摄像头旋转角度*/
    virtual int GetCaptureRotation() = 0;
    /**修改当前摄像头旋转角度*/
    virtual int ChangeCaptureRotation(int rotation) = 0;
    /**获取丢包率等实时参数*/
    virtual int GetReceivedRTCPStatistics(
        unsigned short& fraction_lost,
        unsigned int& cumulative_lost,
        unsigned int& extended_max,
        unsigned int& jitter,
        int& rtt_ms) const = 0;

    /**获取本地摄像头截图*/
    virtual int GetLocalStreamSnapshot(const char *fileName) = 0;
    /**获取远端画面摄像头截图*/
    virtual int GetRemoteStreamSnapshot(const char *fileName) = 0;

protected:
    ~VideoStream(){}
};

};//namespace client

#endif