﻿//
//  CallReport.hxx
//  sources_for_indexing
//
//  Created by DuanWeiwei on 15/2/6.
//
//
#ifndef CLIENT_CALL_REPORT_HXX
#define CLIENT_CALL_REPORT_HXX

#include <string>
#include <time.h>

namespace client {
    

/** @brief通话详单对象, 该对象指针由 client::Call::GetCallReport(); 方法获取.
*  当收到 Call 结束事件后，可获取通话详单写入用户数据库.
*/

class CallReport
{
public:
    enum Direction
    {
        kIncoming = 0,
        kOutgoing,
    };
    
    enum CallReportStatus
    {
        kCallAnswered = 0,
        kCallRejected,
        kCallCancel,
        kCallFailed,
    };

public:
    CallReport()
    :start_time(0),
    connect_time(0),
    finish_time(0),
    session_time(0),
    duration(0),
    video_call(false),
    status(kCallFailed)
    {}
    Direction dir;          /**< 呼叫方向*/
    bool video_call;        /**< 是否为视频呼叫*/
    CallReportStatus status;/**< 呼叫结束状态*/
    std::string from;       /**< 主叫*/ 
    std::string to;         /**< 被叫*/
    time_t start_time;      /**< 开始时间*/
    time_t connect_time;    /**< 接通时间*/
    time_t finish_time;     /**< 结束时间*/
    int session_time;       /**< 会话时长*/
    int duration;           /**< 通话时长*/
};

}; //namespace client


#endif // CLIENT_CALL_REPORT_HXX
