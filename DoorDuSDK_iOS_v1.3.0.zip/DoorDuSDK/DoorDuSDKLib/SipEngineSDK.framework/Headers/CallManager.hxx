﻿#ifndef CALL_FACTOFY_HXX
#define CALL_FACTOFY_HXX

#include "Call.hxx"
#include "CallReport.hxx"

#include <string>
#include <list>

namespace client
{

class Call;
class SipProfile;

enum CallMediaStreamType
{
	kCallAudioStream = 1,
	kCallVideoStream,
	kCallDataStream,
};


/** @brief 呼叫状态监听器, 该对象由用户客户端继承实现，\n
*  并使用 client::CallManager::RegisterCallStateObserver(CallStateObserver *observer); 方法注册监听.
*/
class CallStateObserver {
public:
    /** @brief 呼叫状态变更
    *\param call 呼叫对象.
    *\param state 呼叫状态,详细信息参考 Call::CallState .
    */
    virtual void OnCallStateChange(Call *call, Call::CallState state) = 0;
    /** @brief 收到来自对方的按键音
    *\param call 呼叫对象.
    *\param tone 按键信号 [0-9,*.#].
    */
    virtual void OnDtmf(Call *call, const char *tone) = 0;
	/** @brief 媒体状态更新
    *\param call 呼叫对象.
    *\param type 媒体类型,具体请参考 CallMediaStreamType
    *\param dir 媒体流状态，具体请参考 Call::MediaDirection
    */
    virtual void OnMediaStreamUpdate(Call *call, CallMediaStreamType type, Call::MediaDirection dir) = 0;
protected:
    ~CallStateObserver(){}
};

typedef std::map<std::string, Call*> CallMap;

/** @brief 呼叫管理器, 该对象指针由 client::SipEngine::GetCallManager(); 方法获取.
*
*/
class CallManager
{
public:
    /** @brief 使用 SipProfile 发起新的呼叫
    *\param profile 指定 SipProfile 对象
    *\param called 被叫号码
    *\param webrtc_mode 是否使用webrtc兼容方式呼叫,
    *                   改参数启用后,会使用ICE,DTLS-SRTP,SAVPF方式发起呼叫
    *\param audio_enabled 开启音频流
    *\param video_enabled 开启视频流
    *\param data_enabled  开启数据通道
    */
    virtual Call* MakeCall(
        SipProfile* profile,
        const char* called,
		bool webrtc_mode = false,
        bool audio_enabled = true,
        bool video_enabled = true,
        bool data_enabled = false,
        const ExtensionHeaderMap& extension_hdr_map = ExtensionHeaderMap()) = 0;

    /** @brief 使用 SipProfile 发起新的呼叫
    *\param profile 指定 SipProfile 对象
    *\param called 被叫号码
    *\param device_type 在呼叫请求地址中加入device_type字段
    *\param webrtc_mode 是否使用webrtc兼容方式呼叫,
    *                   改参数启用后,会使用ICE,DTLS-SRTP,SAVPF方式发起呼叫
    *\param audio_enabled 开启音频流
    *\param video_enabled 开启视频流
    *\param data_enabled  开启数据通道
    */
	virtual Call* MakeCall(
		SipProfile* profile,
		const char* called,
		const char* device_type,
		bool webrtc_mode = false,
		bool audio_enabled = true,
		bool video_enabled = true,
        bool data_enabled = false,
        const ExtensionHeaderMap& extension_hdr_map = ExtensionHeaderMap()) = 0;

    /** @brief 发起新的呼叫到指定URI
    *\param display_name SIP URI 中的显示名称
    *\param uri 被叫URI,例如: sip:alice@cloudwebrtc.com;transport=tcp
    *\param webrtc_mode 是否使用webrtc兼容方式呼叫,
    *                   改参数启用后,会使用ICE,DTLS-SRTP,SAVPF方式发起呼叫
    *\param audio_enabled 开启音频流
    *\param video_enabled 开启视频流
    *\param data_enabled  开启数据通道
    */
	virtual Call* MakeCall(
		const char* display_name,
		const char* uri, /*uri*/
		bool webrtc_mode = false,
        bool audio_enabled = true,
        bool video_enabled = true,
        bool data_enabled = false,
        const ExtensionHeaderMap& extension_hdr_map = ExtensionHeaderMap()) = 0;

    /**注册呼叫状态监听器*/
    virtual bool RegisterCallStateObserver(CallStateObserver *observer) = 0;
    /**注销呼叫监听器*/
    virtual void DeRegisterCallStateObserver() = 0;
    /**获取当前所有*/
    virtual std::list<Call*> GetCallList() = 0;
	/**设置最大并发呼叫*/
    virtual void SetMaxConcurrentCall(unsigned int num) = 0;

protected:
    ~CallManager(){}
};

};//namespace client


#endif
