﻿#ifndef STREAM_PARAMS_HXX
#define STREAM_PARAMS_HXX

#include <list>
#include <map>

#include "transport_types.hxx"

#if !defined(_MSC_VER)
#include <stdint.h>
#else
// Define C99 equivalent types, since pre-2010 MSVC doesn't provide stdint.h.
typedef signed char         int8_t;
typedef signed short        int16_t;
typedef signed int          int32_t;
typedef __int64             int64_t;
typedef unsigned char       uint8_t;
typedef unsigned short      uint16_t;
typedef unsigned int        uint32_t;
typedef unsigned __int64    uint64_t;
#endif

#if defined(WIN32)
// Compares two strings without regard to case.
#define STR_CASE_CMP(s1, s2) ::_stricmp(s1, s2)
// Compares characters of two strings without regard to case.
#define STR_NCASE_CMP(s1, s2, n) ::_strnicmp(s1, s2, n)
#else
#define STR_CASE_CMP(s1, s2) ::strcasecmp(s1, s2)
#define STR_NCASE_CMP(s1, s2, n) ::strncasecmp(s1, s2, n)
#endif

namespace client
{
    enum RecordStreamType
    {
        kLocally = 0,
        kRemotely,
        kBoth
    };

    enum StreamType
    {
        kRawStream = 0,
        kAudioStream,
        kVideoStream,
        kDataStream
    };

    enum SecurityLayerType
    {
        kSrtpNone = 0,
        kSrtpSDES,
        kSrtpDTLS,
    };

    enum ViEPacketTimeout {
        NoPacket = 0,
        PacketReceived = 1
    };

    enum TransportLayerType
    {
        kUdp = 0,
        kRFC5245
    };

    struct CodecDesc {
        int pltype;
        char plname[32];
        char type[8];
        int plfreq;
        int pacsize;
        int channels;
        int bitrate;
        CodecDesc(){
            pltype = 0;
            memset(plname, 0, sizeof(plname));
            memset(type, 0, sizeof(type));
            plfreq = 0;
            pacsize = 0;
            channels = 0;
            bitrate = 0;
        }

        CodecDesc(const char *type_str,
            int pt,
            const char *name,
            int freq,
            int pktsize,
            int nb_ch, int br){
            pltype = pt;
            strcpy(plname, name);
            strcpy(type, type_str);
            plfreq = freq;
            pacsize = pktsize;
            channels = nb_ch;
            bitrate = br;
        }

        CodecDesc& copy(CodecDesc &rhs){
            pltype = rhs.pltype;
            strcpy(plname, rhs.plname);
            strcpy(type, rhs.type);
            plfreq = rhs.plfreq;
            pacsize = rhs.pacsize;
            channels = rhs.channels;
            bitrate = rhs.bitrate;
            return *this;
        }
    };

    typedef std::list<CodecDesc> CodecDescList;

	class StreamParams
    {
	public:
		enum MediaDirection
        {
			kNone = 0,
			kSendRecv,
			kSendOnly,
			kRecvOnly,
			kInactive 
        };

	public:
		bool nack;
		bool nack_pli;
		bool ccm_fir;
		bool goog_remb;
		TransportLayerParams local_trans_params;
		TransportLayerParams remote_trans_params;
		std::list<CodecDesc> matched_codec_list;
		MediaDirection media_direction;
        std::string stream_label_;
        int send_bandwidth_limit;
        int recv_bandwidth_limit;
	public:
        StreamParams(const char *stream_label)
			: nack(false),
			ccm_fir(false),
			goog_remb(false),
			nack_pli(false),
			media_direction(kSendRecv),
            stream_label_(stream_label),
            send_bandwidth_limit(0),
            recv_bandwidth_limit(0)
		{}

		~StreamParams()
        {}

        explicit StreamParams(StreamParams *params){
			copy(*params);
		};

		StreamParams& operator=(StreamParams& rhs){
			if (&rhs == this)
				return *this;
			return copy(rhs);
		};

		StreamParams& copy(StreamParams &rhs){
			nack = rhs.nack;
			goog_remb = rhs.goog_remb;
			nack_pli = rhs.nack_pli;
			ccm_fir = rhs.ccm_fir;
			local_trans_params = rhs.local_trans_params;
			remote_trans_params = rhs.remote_trans_params;
			matched_codec_list = rhs.matched_codec_list;
			media_direction = rhs.media_direction;
            send_bandwidth_limit = rhs.send_bandwidth_limit;
            recv_bandwidth_limit = rhs.recv_bandwidth_limit;
			return *this;
		}
    private:
        StreamParams(StreamParams &params){}
	};

#define RTP_PAYLOAD_NAME_SIZE 32

    struct CodecInst {
        int pltype;
        char plname[RTP_PAYLOAD_NAME_SIZE];
        int plfreq;
        int pacsize;
        int channels;
        int rate;  // bits/sec unlike {start,min,max}Bitrate elsewhere in this file!

        bool operator==(const CodecInst& other) const {
            return pltype == other.pltype &&
                (STR_CASE_CMP(plname, other.plname) == 0) &&
                plfreq == other.plfreq &&
                pacsize == other.pacsize &&
                channels == other.channels &&
                rate == other.rate;
        }

        bool operator!=(const CodecInst& other) const {
            return !(*this == other);
        }
    };

	class MediaParams {
	public:
        enum RtpProtocolType { kRtpAVP, kRtpSAVP, kRtpSAVPF};
        MediaParams()
            :secure_media_type(kSrtpNone),
            secure_media_crypto_suite(SRTP_AES_CM_128_HMAC_SHA1_80),
            trans_type(kUdp),
            has_webrtc(false),
            has_rtcp_fb(false),
            has_video_stream(false),
            has_data_stream(false),
            dtls_client(false),
            bundle_transport(false),
            rtcp_mux(false),
            rtp_packet_timeout_ms(0),
            audio_params_(new StreamParams("audio0")),
            video_params_(new StreamParams("video0")),
            data_params_(new StreamParams("data0")),
            use_ipv6_only(false)
        {
            strcpy(msidtemp, "client");
            strcpy(cname, "client");
        }

		~MediaParams()
        {
            delete audio_params_;
            delete video_params_;
            delete data_params_;
        }

	public:
        bool support_webrtc() { return (secure_media_type == kSrtpDTLS && has_webrtc && has_rtcp_fb); }
		bool support_rtcp_fb() { return has_rtcp_fb; }
		bool support_audio(){ return has_audio_stream; }
		bool support_video(){ return has_video_stream; }
		bool support_data(){ return (has_data_stream && has_webrtc); }

		StreamParams* audio_params(){ return audio_params_; }
		StreamParams* video_params(){ return video_params_; }
		StreamParams* data_params(){ return data_params_; }

		IceConfig ice_conf;
        SecurityLayerType secure_media_type;
        SecureMediaCryptoSuite secure_media_crypto_suite;
        TransportLayerType trans_type;

		char msidtemp[36];
		char cname[16];
		char remote_finger_print[80];
		bool has_webrtc;
		bool has_rtcp_fb;
		bool has_audio_stream;
		bool has_video_stream;
		bool has_data_stream;
		bool is_caller;
		bool dtls_client;
        bool bundle_transport;
        bool rtcp_mux;
        int rtp_packet_timeout_ms;
        bool use_ipv6_only;
    private:
		StreamParams *audio_params_;
		StreamParams *video_params_;
		StreamParams *data_params_;
	};

};//namespace 

#endif
