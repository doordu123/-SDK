﻿#ifndef SIP_PROFILE_HXX
#define SIP_PROFILE_HXX

#include <string>

namespace client {
    
    /**信令传输协议*/
    enum SipTransportType
    {
        kUDP = 0,
        kTCP,
        kTLS,
        kWS,
        kWSS
    };
    
    class SipProfile
    {
    public:
        enum { kNumOfStringLength = 80 };
    public:
        ~SipProfile(){}
        /** 设置 profile 名称*/
		virtual void set_profile_name(const char *value) = 0;
        /** 设置 SIP 用户名*/
		virtual void set_username(const char *value) = 0;
        /** 设置 SIP 显示名(DisplayName)*/
		virtual void set_display_name(const char *value) = 0;
        /** 设置 SIP 认证用户名*/
		virtual void set_auth_name(const char *value) = 0;
        /** 设置 SIP 认证密码*/
		virtual void set_password(const char *value) = 0;
        /** 设置 SIP 域*/
		virtual void set_domain(const char *value) = 0;
        /** 设置 SIP 代理服务器地址*/
		virtual void set_proxy(const char *value) = 0;
        /** 设置 SIP 验证域*/
		virtual void set_realm(const char *value) = 0;
        /** 设置 SIP iOS 推送Token ID*/
		virtual void set_apns_token(const char *value) = 0;

    public:
        char profile_name[kNumOfStringLength];
        char username[kNumOfStringLength];
        char displayname[kNumOfStringLength];
        char auth_name[kNumOfStringLength];
        char password[kNumOfStringLength];
        char domain[kNumOfStringLength];
        char proxy[kNumOfStringLength];
        char realm[kNumOfStringLength];

        /** 是否开启心跳保持*/
        bool keepalive;
        /** 注册过期默认 1800 秒*/
        int register_expire;
        /** SIP 信令传输协议类型*/
        SipTransportType trans_type;
        /** 开启WebRTC兼容模式，开启后可与Chrome,Firefox 直接通信*/
        bool webrtc_mode;
        /**开启RTCP-FB模式, 同时打开 ccm,fir,pli,nack*/
        bool rtcp_fb;
        /** 自定义用户指针*/
        void *user_data;
        /** 是否发送注册消息*/
        bool send_register;
        /** 是否在Contact 参数后面加入推送ID*/
        bool contact_add_apns_token;
        /** iOS APNS 推送token ID*/
        char apns_token[kNumOfStringLength];
    };
    
};  //namespace client

#endif
