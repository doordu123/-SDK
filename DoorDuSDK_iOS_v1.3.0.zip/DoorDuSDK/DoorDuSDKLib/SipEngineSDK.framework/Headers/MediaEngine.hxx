﻿#ifndef MEDIA_ENGINE_API_HXX
#define MEDIA_ENGINE_API_HXX

#include <string>
#include <vector>

namespace client {

class MediaStream;
class RTCVoiceEngine;
class RTCVideoEngine;
class MediaEncryptFilter;

/**
* 媒体引擎对象
*/
class MediaEngine
{
public:
    /*初始化媒体引擎*/
    virtual bool Initialize(
        int rtp_port_start,
        int rtp_port_end,
        const char *voe_trac_file = 0,
        const char *vie_trac_file = 0,
        std::vector<std::string> dns_servers = std::vector<std::string>()) = 0;
    /**销毁媒体引擎*/
    virtual bool Terminate() = 0;
    /**创建媒体流对象*/
    virtual MediaStream *CreateMediaStream(bool use_ipv6_only = false, MediaEncryptFilter *enc_filter = NULL) = 0;
    /**销毁媒体流对象*/
    virtual bool DeleteMediaStream(MediaStream*& media_stream) = 0;
    /**获取语音引擎接口*/
    virtual RTCVoiceEngine* GetRTCVoiceEngine() = 0;
#ifdef ENABLE_VIDEO_STREAM
    /**获取视频引擎接口*/
    virtual RTCVideoEngine* GetRTCVideoEngine() = 0;
#endif // ENABLE_VIDEO_STREAM
protected:
    ~MediaEngine(){}
};

};// namespace client

#endif
