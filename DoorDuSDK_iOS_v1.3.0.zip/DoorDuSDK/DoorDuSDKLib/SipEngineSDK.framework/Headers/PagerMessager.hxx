﻿#ifndef CLIENT_PAGE_MESSAGER_HXX
#define CLIENT_PAGE_MESSAGER_HXX

/*SIP 消息收发器*/

namespace client {

    class SipProfile;
    
    class PagerMessageHandler
    {
    public:
        virtual void onSuccess(int code) = 0;

        virtual void onFailure(int status, const char * reason) = 0;

        virtual void onMessage(const char *from, const char *message, int length) = 0;
    };

    class PagerMessager
    {
    public:
        virtual int SendMessage(
            const SipProfile *profile,
            const char *recipient,
            const char *message,
            int length) = 0;
    
        virtual void RegisterPagerMessageHandler(PagerMessageHandler* pager_message_handler) = 0;

        virtual void DeRegisterPagerMessageHandler() = 0;
    };

};//namespace client

#endif