//
//  SipEngineSDK.h
//  SipEngineSDK
//
//  Created by DuanWeiwei on 2016/12/26.
//  Copyright © 2016年 DuanWeiwei. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SipEngineSDK.
FOUNDATION_EXPORT double SipEngineSDKVersionNumber;

//! Project version string for SipEngineSDK.
FOUNDATION_EXPORT const unsigned char SipEngineSDKVersionString[];

FOUNDATION_EXPORT @class RTCEAGLVideoView;

@interface SipEngineSDK : NSObject

-(void) InitSipEngineSDK;

@end


// In this header, you should import all the public headers of your framework using statements like #import <SipEngineSDK/PublicHeader.h>


