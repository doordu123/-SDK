//
//  DoorDuVideoView.h
//  DoorDuSDK
//
//  Created by Doordu on 2017/3/29.
//  Copyright © 2017年 深圳市多度科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

/**视频通话渲染控件*/
@interface DoorDuVideoView : UIView

@end
