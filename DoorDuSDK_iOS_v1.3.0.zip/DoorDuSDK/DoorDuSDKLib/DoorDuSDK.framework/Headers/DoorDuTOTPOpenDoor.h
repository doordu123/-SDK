//
//  DoorDuTOTPOpenDoor.h
//  DoorDuSDK
//
//  Created by DoorDu on 2018/1/12.
//  Copyright © 2018年 深圳市多度科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void (^ResultPin)(NSString *pinStr, NSUInteger lastSecond);

@interface DoorDuTOTPOpenDoor : NSObject

/**
 生成TOTP值

 @param dynamicKeyStr 门禁机动态秘钥
 @param result 返回接口 pinStr : PIN码， lastSecond : 剩余更新时长
 */
- (void)generateWithDoorDynamicKey:(NSString *)dynamicKeyStr result:(ResultPin)result;

@end
