//
//  DoorDuClient.h
//  DoorduSDK
//
//  Created by Doordu on 2017/3/30.
//  Copyright © 2017年 深圳市多度科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DoorDuOptions.h"
#import "DoorDuClientDelegate.h"
#import "DoorDuCallManagerDelegate.h"
#import "DoorDuError.h"

@class DoorDuVideoView;
@interface DoorDuClient : NSObject

/**
 判断当前SDK是否登录，如果未登录开发者必须调用sdk登录接口

 @return 返回当前SDK是否登录
 */
+ (BOOL)isDoorDuSDKLogin;

/**注册clientDelegate*/
+ (void)registClientDelegate:(id<DoorDuClientDelegate>)delegate;

/**移除clientDelegate代理*/
+ (void)removeClientDelegate;

/**注册通话状态回调*/
+ (void)registCallManagerDelegate:(id<DoorDuCallManagerDelegate>)delegate;

/**移除通话状态管理*/
+ (void)removeCallManagerDelegate;

/**监听token失败*/
+ (void)addTokenInvalideObserver:(id)observer sel:(SEL)sel;

/*!
 * @method  makeDoorCallWithMediaCallType
 * @brief   呼叫门禁机来电.
 * @param   mediaCallType           呼叫多媒体类型(语音/视频).
 * @param   remoteCallerNO          远程(被叫)通话账号.
 * @param   remoteVideoView         远程(被叫)视频显示控件.
 */
+ (void)makeDoorCallWithMediaCallType:(DoorDuMediaCallType)mediaCallType
                       remoteCallerNO:(NSString *)remoteCallerNO
                      remoteVideoView:(DoorDuVideoView *)remoteVideoView;

/**
 * @method  answerDoorMediaCallType
 * @brief   接听门禁机来电.
 * @param   mediaCallType           呼叫多媒体类型(语音/视频).
 * @param   remoteCallerNO          远程(被叫)通话账号.
 * @param   remoteVideoView         远程(主叫)视频显示控件.
 */
+ (void)answerDoorMediaCallType:(DoorDuMediaCallType)mediaCallType
                 remoteCallerNO:(NSString *)remoteCallerNO
                remoteVideoView:(DoorDuVideoView *)remoteVideoView;

/**是否正在通话中*/
+ (BOOL)isCalling;

/**是否存在通话*/
+ (BOOL)isExistCall;

/**拒接来电*/
+ (void)rejectCurrentCall;

/**挂断当前呼叫*/
+ (void)hangupCurrentCall;

/**切换话筒状态,enable为YES打开话筒、为NO关闭话筒*/
+ (BOOL)switchMicrophone:(BOOL)enable;

/**切换扬声器状态,enable为YES打开扬声器、为NO关闭扬声器*/
+ (BOOL)switchSpeaker:(BOOL)enable;

/**切换摄像头方向*/
+ (BOOL)switchCameraDirection;

/**视频模式切换到语音模式*/
+ (BOOL)switchVideoModeToAudioMode;

@end
