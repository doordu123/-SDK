//
//  DoorDuClientDelegate.h
//  DoorDuSDK
//
//  Created by Doordu on 2017/3/30.
//  Copyright © 2017年 深圳市多度科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DoorDuAllResponse.h"
@class DoorDuDoorCallModel;

@protocol DoorDuClientDelegate <NSObject>

/**接收到门禁呼叫来电*/
- (void)callDidReceiveDoor:(DoorDuDoorCallModel *)model;
/**
 * 以下情况会接收到挂断通知：
 * 1.主叫方挂断了电话（取消电话呼叫）
 * 2.户户通和门禁打过来的时候同房间的人比你先接听
 * 3.呼叫超时
 */
- (void)callDidHangupMessage;
/**收到物业通知消息*/
- (void)receivePropertyNoticeMessage:(DoorDuPropertyNotice *)model;
/**收到授权变更通知*/
- (void)receiveAuthorizationChangeMessage:(DoorDuAuthorizationChange *)model;

@end
