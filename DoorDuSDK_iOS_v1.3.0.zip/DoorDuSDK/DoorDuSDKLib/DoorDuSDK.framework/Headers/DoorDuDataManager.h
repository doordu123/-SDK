//
//  DoorDuDataApi.h
//  Doordu
//
//  Created by Doordu on 2017/3/29.
//  Copyright © 2017年 深圳市多度科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DoorDuError.h"
#import "DoorDuAllResponse.h"
#import <UIKit/UIKit.h>

@class DoorDuOptions;
/**业务数据管理*/
@interface DoorDuDataManager : NSObject

/*! @brief 向多度注册第三方应用
 *
 * @param       appId       doordu授权的的appid
 * @param       secretKey   doordu授权的的secretKey
 * @param       options     sdk环境配置
 * @param       completion  结果回调
 */
+ (void)registSDKWithAppId:(NSString *)appId
                 secretKey:(NSString *)secretKey
                   options:(DoorDuOptions *)options
                completion:(void(^)(BOOL isSuccess, DoorDuError *error))completion;

#pragma mark --- SDK初始化、退出接口
/**
 初始化用户信息接口, 用于音视频空间初始化
 
 @param nationCode 手机号国家码 默认86(可为空)
 @param mobileNo 手机号(可为空)
 @param openId 用户唯一标识,通过服务接口返回(可为空， nationCode、mobileNo必须一起使用，且nationCode、mobileNo与openId必须一个不为空， 两个都有值得情况下nationCode、mobileNo无效)
 @param completion 结果回调
 */
+ (void)loginSDKWithNationCode:(NSString *)nationCode
                      mobileNo:(NSString *)mobileNo
                        openId:(NSString *)openId
                    completion:(void(^)(BOOL isSuccess, DoorDuError *error))completion;

/**
 用户退出接口
 
 @param completion 结果回调
 */
+ (void)loginoutWithCompletion:(void(^)(BOOL isSuccess, DoorDuError *error))completion;

#pragma mark --- 登记push token
/** 向Doordu注册该设备的deviceToken，便于发送Push消息
 @param deviceToken APNs返回的deviceToken
 */
+ (void)registerDeviceToken:(NSData *)deviceToken;


#pragma mark --- 用户接口
/**
 获取用户转接号码接口
 
 @param roomId     房间ID
 @param completion 结果回调
 */
+ (void)getUserTransferNumberWithRoomId:(NSString *)roomId
                             completion:(void(^)(DoorDuCallTransfer *transferNumberInfo, DoorDuError *error))completion;

/**
 用户呼叫转接号码设置
 
 @param roomId 房间ID
 @param mobile     手机号
 @param nationCode 国家码，默认86
 @param completion 结果回调
 */
+ (void)setUserTransferNumberWithRoomId:(NSString *)roomId
                                 mobile:(NSString *)mobile
                             nationCode:(NSString *)nationCode
                             completion:(void(^)(BOOL isSuccess, DoorDuError *error))completion;

#pragma mark -- 我的房间列表
/**
 获取房间列表
 
 @param completion 结果回调, 如果请求成功， error == nil
 */
+ (void)getUserRoomListWithCompletion:(void(^)(NSArray<DoorDuRoomInfo *> *roomList, DoorDuError *error))completion;

/**
 用户获取钥匙包列表接口
 
 @param roomId 房间ID
 @param completion 结果回调, 如果请求成功， error == nil
 */
+ (void)getUserKeyListWithRoomId:(NSString *)roomId
                      completion:(void(^)(DoorDuKeyList *keyList, DoorDuError *error))completion;

/**
 设置钥匙串排序列表
 
 @param roomId 房间ID
 @param doorIds 271744,363425,1234566 按照顺序(门禁机设备ID)
 @param completion 结果回调
 */
+ (void)setUserKeysSortWithRoomId:(NSString *)roomId
                          doorIds:(NSString *)doorIds
                       completion:(void(^)(BOOL isSuccess, DoorDuError *error))completion;

/**
 自定义钥匙名称接口
 
 @param doorId     门禁机ID
 @param aliasString 别名
 @param completion 结果回调
 */
+ (void)setUserKeypackageAliasWithDoorId:(NSString *)doorId
                                   alias:(NSString *)aliasString
                              completion:(void(^)(BOOL isSuccess, DoorDuError *error))completion;

#pragma mark --- 获取小区公告列表
/**
 小区公告列表接口
 
 @param startPage 页码从1开始
 @param pageSize 每页显示数量
 @param completion 结果回调, 如果请求成功error == nil
 */
+ (void)getCommunityNoticeListWithStartPage:(NSUInteger)startPage
                                   pageSize:(NSUInteger)pageSize
                                 completion:(void(^)(NSArray<DoorDuCommunityNotice *> *noticeList, DoorDuError *error))completion __attribute__((deprecated("Use -getCommunityNoticeListWithRoomId:StartPage:pageSize:completion: instead")));

/**
 小区公告列表接口，SDK1.3.0 增加房间id参数，用于获取指定房间的公告信息
 @param roomId    用户房间ID，该值为空表示获取用户所有小区的公告信息
 @param startPage 页码从1开始
 @param pageSize 每页显示数量
 @param completion 结果回调, 如果请求成功error == nil
 */
+ (void)getCommunityNoticeListWithRoomId:(NSString *)roomId
                               StartPage:(NSUInteger)startPage
                                pageSize:(NSUInteger)pageSize
                              completion:(void(^)(NSArray<DoorDuCommunityNotice *> *noticeList, DoorDuError *error))completion;



#pragma mark --- 获取公告详情
/**
 获取公告详情
 
 @param noticeId 公告ID
 @param completion 结果回调, 如果请求成功error == nil
 */
+ (void)getNoticeDetailWithNoticeId:(NSString *)noticeId
                         completion:(void(^)(DoorDuCommunityNotice *noticeDetail, DoorDuError *error))completion;

#pragma mark --- 获取该用户所在房间的访客留影接口
/**
 获取该用户所在房间的访客留影接口
 
 @param roomId 房间ID
 @param openType 开门类型 0-所有记录 1-IC卡开门 2-APP开门 3-呼叫接听开门 4-密码开门 5-未开门(未接通) 6-呼叫未接听开门 7-查看门口视频开门
 @param startPage 页码默认是第1页
 @param pageSize 每页显示数量，默认每页20条
 @param completion 结果回调, 如果请求成功error == nil
 */
+ (void)getUserVistorsHistoryWithRoomId:(NSString *)roomId
                               openType:(NSUInteger)openType
                              startPage:(NSUInteger)startPage
                               pageSize:(NSUInteger)pageSize
                             completion:(void(^)(NSArray<DoorDuVistorHistoryInfo *> *vistorHistoryList, DoorDuError *error))completion;

/**
 获取房间访客留影记录
 
 @param roomId 房间ID
 @param openType 开门类型 0-所有记录 1-IC卡开门 2-APP开门 3-呼叫接听开门 4-密码开门 5-未开门(未接通) 6-呼叫未接听开门 7-查看门口视频开门
 @param startPage 页码默认是第1页
 @param pageSize 每页显示数量，默认每页20条
 @param completion 结果回调, 如果请求成功error == nil
 */
+ (void)getRoomVistorsHistoryWithRoomId:(NSString *)roomId
                               openType:(NSUInteger)openType
                              startPage:(NSUInteger)startPage
                               pageSize:(NSUInteger)pageSize
                             completion:(void(^)(NSArray<DoorDuVistorHistoryInfo *> *vistorHistoryList, DoorDuError *error))completion;

#pragma mark --- 开门接口
/**
 开门接口
 
 @param roomId 房间ID
 @param doorId 门禁主键id
 @param completion 结果回调, 如果请求成功error == nil
 */
+ (void)openDoorWithRoomId:(NSString *)roomId
                    doorId:(NSString *)doorId
                completion:(void(^)(BOOL isSuccess, DoorDuError *error))completion  __attribute__((deprecated("Use -openDoorWithRoomId:doorId:openType:completion: instead")));

/**
 开门接口, SDK1.3  增加了 openType
 
 @param roomId 房间ID
 @param doorId 门禁主键id
 @param openType 开门方式：2-钥匙包开门，3-被呼叫接通后开门，5-主动查看门禁视频开门，6-被呼叫未接通时开门，默认为2钥匙包开门
 @param completion 结果回调, 如果请求成功error == nil
 */
+ (void)openDoorWithRoomId:(NSString *)roomId
                    doorId:(NSString *)doorId
                  openType:(NSString *)openType
                completion:(void(^)(BOOL isSuccess, DoorDuError *error))completion;


/**
 获取密码开门
 
 @param roomId 房间ID
 @param completion 结果回调, 如果请求成功error == nil
 */
+ (void)getDoorPasswordWithRoomId:(NSString *)roomId
                       completion:(void(^)(DoorDuDoorPassword *doorPwd, DoorDuError *error))completion;

/**
 密码开门密码列表
 
 @param roomID 房间ID
 @param completion completion 结果回调, 如果请求成功error == nil
 */
+ (void)getDoorPasswordListWithRoomId:(NSString *)roomID
                           completion:(void(^)(NSArray<DoorDuOpenDoorPwd *> *allPwd, DoorDuError *error))completion;

/**
 获取 密码开门密码详情
 
 @param roomID 房间ID
 @param passwordID 密码唯一标识符
 @param completion completion completion 结果回调, 如果请求成功error == nil
 */
+ (void)getDoorPasswordDetailWithRoomId:(NSString *)roomID
                             passwordId:(NSString *)passwordID
                             completion:(void(^)(DoorDuOpenDoorPasswordDetail *pwdDetail, DoorDuError *error))completion;

#pragma mark --- 免打扰相关接口
/**
 用于获取用户免打扰数据
 
 @param completion 返回内容
 */
+ (void)getUserDisturbInfoWithCompletion:(void(^)(DoorDuCallDisturbInfo *disturbInfo, DoorDuError *error))completion;

/**
 用于设置指定房间免打扰
 
 @param roomId 房间ID
 @param appStatus  app免打扰类型 0-关闭 1-开启 2-只在夜间开启
 @param callStatus 呼叫转接电话免打扰开关，0-关闭，1-打开，2-夜间开启
 @param completion 结果回调, 如果请求成功error == nil
 */
+ (void)setUserRoomDisturbInfoWithRoomId:(NSString *)roomId
                               appStatus:(NSString *)appStatus
                              callStatus:(NSString *)callStatus
                              completion:(void(^)(DoorDuRoomDisturbSettingResult *disturbInfo, DoorDuError *error))completion;

/**
 一键免打扰设置接口，用于设置用户所有房间免打扰信息
 
 @param appstatus APP呼叫开关状态 0-关 1-开
 @param callStatus 呼叫转接开关状态，0-关，1-开
 @param completion 结果回调, 如果请求成功error == nil
 */
+ (void)setAllRoomDisturbInfoWithAppStatus:(NSString *)appstatus
                                callStatus:(NSString *)callStatus
                                completion:(void(^)(DoorDuDisturbSettingResult *disturbInfo, DoorDuError *error))completion;

#pragma mark --  获取用户所有实体卡信息
/**
 获取用户单个房间所有实体卡信息
 
 @param roomId 房间ID
 @param completion 结果回调, 如果请求成功error == nil
 */
+ (void)getUserEntityCardsWithRoomId:(NSString *)roomId
                          completion:(void(^)(NSArray<DoorDuEntityCardInfo *> *cards, DoorDuError *error))completion;

#pragma mark --- 授权管理相关接口
#pragma mark ---- 新增授权
/**
 新增授权
 
 @param nationCode 国家码，默认 86
 @param name 被授权人姓名
 @param authMobile 被授权人手机号
 @param roomId 授权房间ID
 @param authType 授权类型 1-家人 2-租客 3-临时客人
 @param beginTime 授权开始时间
 @param endTime 授权结束时间
 @param completion 结果回调
 */
+ (void)addAuthorizeWithNationCode:(NSString *)nationCode
                              name:(NSString *)name
                        authMobile:(NSString *)authMobile
                            roomId:(NSString *)roomId
                          authType:(NSString *)authType
                         beginTime:(NSString *)beginTime
                           endTime:(NSString *)endTime
                        completion:(void(^)(BOOL isSuccess, DoorDuError *error))completion;

#pragma mark ---- 修改授权
/**
 修改授权
 
 @param name 被授权人姓名
 @param authUserId 被授权人用户ID
 @param roomId 授权房间ID
 @param authType 授权类型 1-家人 2-租客 3-临时客人
 @param beginTime 授权开始时间
 @param endTime 授权结束时间
 @param completion 结果回调
 */
+ (void)modifyAuthorizeWithName:(NSString *)name
                     authUserId:(NSString *)authUserId
                         roomId:(NSString *)roomId
                       authType:(NSString *)authType
                      beginTime:(NSString *)beginTime
                        endTime:(NSString *)endTime
                     completion:(void(^)(BOOL isSuccess, DoorDuError *error))completion;

#pragma mark ---- 删除授权
/**
 删除授权
 
 @param authUserId 被授权人用户ID
 @param roomId 被授权人用户ID
 @param completion 结果回调
 */
+ (void)deleteAuthorizeWithAuthUserId:(NSString *)authUserId
                               roomId:(NSString *)roomId
                           completion:(void(^)(BOOL isSuccess, DoorDuError *error))completion;

#pragma mark ---- 终止授权
/**
 终止授权接口,把自己给终结掉。自己把自己解除授权
 
 @param roomId 授权房间ID
 @param completion 结果回调
 */
+ (void)terminalAuthorizeWithRoomId:(NSString *)roomId
                         completion:(void(^)(BOOL isSuccess, DoorDuError *error))completion;

#pragma mark ---- 获取授权列表
/**
 获取用户授权列表
 
 @param roomId 授权房间ID
 @param startPage 页码默认是第1页
 @param pageSize 每页显示数量，默认每页20条
 @param completion 结果回调
 */
+ (void)getAuthorizeListWithRoomId:(NSString *)roomId
                         startPage:(NSString *)startPage
                          pageSize:(NSString *)pageSize
                        completion:(void(^)(DoorDuAuthorizeListInfo *authList, DoorDuError *error))completion;


#pragma mark --- 联系物业

/**
 联系物业接口,物业留言和图片最少一个
 
 @param roomId 授权房间ID
 @param content 留言内容
 @param imageDatas 图片二进制数组，最多3张图片
 @param tagType 类型：0-其它，1-投诉建议，2-报修维护，3-失物招领
 @param completion 结果返回
 */
+ (void)contactPropertyWithRoomId:(NSString *)roomId
                          content:(NSString * )content
                       imageDatas:(NSArray<NSData *> *)imageDatas
                          tagType:(NSString *)tagType
                       completion:(void(^)(BOOL isSuccess, DoorDuError *error))completion;

/**
 联系物业历史记录
 
 @param depID     小区ID
 @param startPage 页码，默认第一页
 @param pageNo 每页条数，默认20条
 @param completion 结果返回
 */
+ (void)contactPropertyHistoryWithDepID:(NSString *)depID
                              startPage:(NSString *)startPage
                                 pageNo:(NSString * )pageNo
                             completion:(void(^)(NSArray<DoorDuPropertyPublishInfo *> *publishList, DoorDuError *error))completion;

#pragma mark - 下载图片
/**
 下载图片二进制流，下载成功和失败之前 内部已做防重下载，图片下载成功后，需外部存储
 
 @param imageObjectKey imageObjectKey 图片在多度服务器唯一标识符
 @param successBlock 成功,imageData 下载完成的图片二进制 和对应的 imageObjectKey
 @param failureBlock 失败
 */
+ (void)downloadWithImageObjectKey:(NSString *)imageObjectKey
                           success:(void (^)(NSData * imageData,NSString * imageObjectKey))successBlock
                           failure:(void(^)(NSString * imageObjectKey))failureBlock;

#pragma mark --- 全国小区搜索接口
/**
 全国小区搜索接口
 
 @param keyword 搜索关键字
 @param startPage 页码从1开始
 @param pageSize 每页显示数量
 @param completion 结果回调, 如果请求成功error == nil
 */
+ (void)getEstateDepartmentSearchWithKeyword:(NSString *)keyword
                                   startPage:(NSUInteger)startPage
                                    pageSize:(NSUInteger)pageSize
                                  completion:(void(^)(NSArray<DoorDuEstateDepartmentSearch *> *departmentList, DoorDuError *error))completion;

#pragma mark --- 城市列表接口
/**
 城市列表接口
 
 @param keyword 搜索关键字
 @param startPage 页码从1开始
 @param pageSize 每页显示数量
 @param completion 结果回调, 如果请求成功error == nil
 */
+ (void)getEstateCityWithKeyword:(NSString *)keyword
                       startPage:(NSUInteger)startPage
                        pageSize:(NSUInteger)pageSize
                      completion:(void(^)(NSArray<DoorDuEstateCity *> *cityList, DoorDuError *error))completion;

#pragma mark --- 小区列表接口
/**
 小区列表接口
 
 @param keyword 搜索关键字
 @param cityId    城市ID
 @param startPage 页码从1开始
 @param pageSize 每页显示数量
 @param completion 结果回调, 如果请求成功error == nil
 */
+ (void)getEstateDepartmentListWithKeyword:(NSString *)keyword
                                    cityId:(NSString *)cityId
                                 startPage:(NSUInteger)startPage
                                  pageSize:(NSUInteger)pageSize
                                completion:(void(^)(NSArray<DoorDuEstateDepartment *> *departmentList, DoorDuError *error))completion;

#pragma mark --- 楼栋单元接口
/**
 楼栋单元接口
 
 @param keyword 搜索关键字
 @param depId    小区ID
 @param startPage 页码从1开始
 @param pageSize 每页显示数量
 @param completion 结果回调, 如果请求成功error == nil
 */
+ (void)getEstateBuildingUnitWithKeyword:(NSString *)keyword
                                   depId:(NSString *)depId
                               startPage:(NSUInteger)startPage
                                pageSize:(NSUInteger)pageSize
                              completion:(void(^)(NSArray<DoorDuEstateBuildingUnit *> *buildingList, DoorDuError *error))completion;

#pragma mark --- 房间列表接口
/**
 房间列表接口
 
 @param keyword 搜索关键字
 @param unitId    单元ID
 @param startPage 页码从1开始
 @param pageSize 每页显示数量
 @param completion 结果回调, 如果请求成功error == nil
 */
+ (void)getEstateRoomNumberWithKeyword:(NSString *)keyword
                                unitId:(NSString *)unitId
                             startPage:(NSUInteger)startPage
                              pageSize:(NSUInteger)pageSize
                            completion:(void(^)(NSArray<DoorDuEstateRoomNumber *> *roomNumberList, DoorDuError *error))completion;

// 自助授权
#pragma mark - 自助授权申请接口
/**
 自助授权申请接口
 
 @param roomNumberId 房间ID
 @param cityId 城市ID
 @param depId 小区ID
 @param realName 真实姓名
 @param mobileNo 手机号
 @param selfHelpStatus 自助登记卡状态,自助登录卡:1不开通，2申请开通
 @param authType 授权信息，授权类型：0业主，1家人，2租客，3临时客人
 @param cardImg1 身份证正面照
 @param cardImg2 身份证反面照
 @param cardImg3 身份证手持照
 @param cardNo 身份证号
 @param cardName     身份证名字
 @param nation 民族
 @param address 户籍地址
 @param government 发证机关
 @param validity 有效期
 @param nationCode     国家码
 @param completion 回调
 */
+ (void)selfAuthApplyWithRoomNumberId:(NSString *)roomNumberId
                               cityId:(NSString *)cityId
                                depId:(NSString *)depId
                             realName:(NSString *)realName
                             mobileNo:(NSString *)mobileNo
                       selfHelpStatus:(NSString *)selfHelpStatus
                             authType:(NSString *)authType
                             cardImg1:(NSString *)cardImg1
                             cardImg2:(NSString *)cardImg2
                             cardImg3:(NSString *)cardImg3
                               cardNo:(NSString *)cardNo
                             cardName:(NSString *)cardName
                               nation:(NSString *)nation
                              address:(NSString *)address
                           government:(NSString *)government
                             validity:(NSString *)validity
                           nationCode:(NSString *)nationCode
                           completion:(void(^)(BOOL isSuccess, DoorDuError *error))completion;

#pragma mark --- 自助授权申请记录
/**
 获取自助授权申请记录
 
 @param startPage 页码从1开始
 @param pageSize 每页显示数量
 @param completion 结果回调
 */
+(void)getSelfAuthRecordWithStartPage:(NSUInteger)startPage
                             pageSize:(NSUInteger)pageSize
                           completion:(void(^)(NSArray<DoorDuSelfAuthRecord *> *authRecords, DoorDuError *error))completion;

#pragma mark --- 获取业主手机号码
/**
 获取房间所属业主手机号码
 
 @param roomId 房间ID
 @param completion 结果回调
 */
+(void)getMobileOfProprietorWithRoomId:(NSString *)roomId completion:(void(^)(NSArray<NSString *> *mobiles, DoorDuError *error))completion;

#pragma mark - 获取转接号码
/**
 获取呼叫转接号码列表
 
 @param completion 结果回调
 */
+ (void)getCallTransferMobileListWithCompletion:(void(^)(NSArray<NSString *> *mobileList, DoorDuError *error))completion;

#pragma mark - 上传   身份证的正面照片 、反面照片 和手持照片接口，返回对应的模型 和 imageObjectKey
/**
 检测并上传 身份证的正面照片、身份证的反面照片、手持身份证照片(暂时没有对手持照片校验)
 
 @param imageData 图片二进制
 @param realName  真实姓名（会与身份证正面姓名对比）,只有身份证正面需要校验
 @param uploadImageDataType 这个接口只支持 上传身份证正面照片、身份证反面照片和手持身份证照片
 @param completion 检测并把上传结果返回
 imageObjectKey 图片在多度服务器唯一标识符，只有检测成功并上传成功才有值
 cardFront ：身份证正面数据模型
 cardBack  ：身份证反面数据模型
 */
+ (void)detectionAndUploadIdentifyImageData:(NSData *)imageData
                                   realName:(NSString *)realName
                        uploadImageDataType:(DoorDuUploadImageDataType)uploadImageDataType
                                 completion:(void(^)(DoorDuFaceplusplusIdentifyCardSideFront * cardFront,DoorDuFaceplusplusIdentifyCardSideBack * cardBack,NSString * imageObjectKey, DoorDuError *error))completion;


@end
