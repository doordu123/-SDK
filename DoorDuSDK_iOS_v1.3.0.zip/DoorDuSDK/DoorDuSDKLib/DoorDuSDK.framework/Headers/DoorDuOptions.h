//
//  DoorDuOptions.h
//  DoorduSDK
//
//  Created by Doordu on 2017/3/30.
//  Copyright © 2017年 深圳市多度科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DoorDuClientEnum.h"

/**
    DoorDuClient 的配置类
 */
@interface DoorDuOptions : NSObject

/*是否输出日志*/
@property (nonatomic,assign) BOOL isShowLog;

/*设置开发环境*/
@property (nonatomic,assign) DoorDuSDKMode mode;

/*设置接口超时时间 默认10s*/
@property (nonatomic,assign) float requestTimeout;

@end
