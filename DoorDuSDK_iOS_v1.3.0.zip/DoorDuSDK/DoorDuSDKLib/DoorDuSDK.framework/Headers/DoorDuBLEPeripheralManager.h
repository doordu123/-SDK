//
//  DoorDuBLEPeripheralManager.h
//  DoorDuSDK
//
//  Created by Doordu on 2018/2/27.
//  Copyright © 2018年 深圳市多度科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

#pragma mark - DoorDuBLEPeripheralManagerState(蓝牙状态)
typedef NS_ENUM(NSInteger, DoorDuBLEPeripheralManagerState) {
    
    DoorDuBLEPeripheralManagerStatePoweredOn       = 0,//蓝牙处于开启状态
    DoorDuBLEPeripheralManagerStateNone            = -1,//蓝牙处于未知状态
    DoorDuBLEPeripheralManagerStateResetting       = -2,//蓝牙处于重启状态
    DoorDuBLEPeripheralManagerStateUnsupported     = -3,//蓝牙处于不支持状态
    DoorDuBLEPeripheralManagerStateUnauthorized    = -4,//蓝牙处于未授权状态
    DoorDuBLEPeripheralManagerStatePoweredOff      = -5,//蓝牙处于未开启状态
};

#pragma mark - 发送开门广播回调 状态
typedef NS_ENUM(NSInteger, DoorDuBLEPeripheralManagerAdvertisingState) {
    
    DoorDuBLEPeripheralManagerAdvertisingStateSuccess       = 0,//广播发送成功
    DoorDuBLEPeripheralManagerAdvertisingStateUnknown       = -1,//未知错误
    DoorDuBLEPeripheralManagerAdvertisingStateNoObserver    = -2,//未开启监控
    DoorDuBLEPeripheralManagerAdvertisingStateNone          = -3,//蓝牙处于未知状态
    DoorDuBLEPeripheralManagerAdvertisingStateResetting     = -4,//蓝牙处于重启状态
    DoorDuBLEPeripheralManagerAdvertisingStateUnsupported   = -5,//蓝牙处于不支持状态
    DoorDuBLEPeripheralManagerAdvertisingStateUnauthorized  = -6,//蓝牙处于未授权状态
    DoorDuBLEPeripheralManagerAdvertisingStatePoweredOff    = -7,//蓝牙处于未开启状态
    DoorDuBLEPeripheralManagerAdvertisingStateParams        = -8,//参数错误
};
/** 蓝牙状态 */
typedef void (^DoorDuBLEPeripheralManagerStateBlock)    (DoorDuBLEPeripheralManagerState state);
/** 发送开门广播 */
typedef void (^DoorDuBLEPeripheralManagerAdvertisingStateBlock)  (DoorDuBLEPeripheralManagerAdvertisingState AdvertisingState);
/* 开门广播完成回调 **/
typedef void (^DoorDuBLEPeripheralManagerAdvertisingCompleteBlock)  (void);

/**
 * 蓝牙广播 开门
 */
@interface DoorDuBLEPeripheralManager : NSObject

/**
 创建DoorDuBLEPeripheralManager对象，并状态回调
 @param stateBlock 状态回调
 @return 返回DoorDuBLEPeripheralManager 对象
 */
+ (DoorDuBLEPeripheralManager *)startBLEPeripheralObserver:(DoorDuBLEPeripheralManagerStateBlock)stateBlock;

/**
 发送开门广播(异步)
 @param    mobile 手机号码
 @param    nationCode 手机号码所在的国家地区编码
 @param    depID 小区ID
 @param    timeInterval （时间单位-秒），设置广播时间，默认 1
 @param    stateBlock 状态
 @param    completeBlock 广播完成回调,并不代表开门成功(只有发送开门广播回调 状态为 DoorDuBLEPeripheralManagerAdvertisingStateSuccess这个回调才执行)
 */
- (void)sendAdvertisingWithMobile:(NSString *)mobile
                       nationCode:(NSString *)nationCode
                            depID:(NSString *)depID
                     timeInterval:(NSTimeInterval)timeInterval
                       stateBlock:(DoorDuBLEPeripheralManagerAdvertisingStateBlock)stateBlock
                    completeBlock:(DoorDuBLEPeripheralManagerAdvertisingCompleteBlock)completeBlock;

/**
 停止广播
 */
- (void)stopAdvertising;

@end
