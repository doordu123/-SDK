//
//  DoorDuAllResponse.h
//  DoorduSDK
//
//  Created by Doordu on 2017/3/29.
//  Copyright © 2017年 深圳市多度科技有限公司. All rights reserved.
//

/**数据模型*/
#import "DoorDuBaseResponse.h"
#import "DoorDuClientEnum.h"


#pragma mark -- 用户注册
#pragma mark -测试使用
@interface DoorDuUserRegister : DoorDuBaseResponse
/**用户唯一标识*/
@property (nonatomic,copy) NSString *open_id;
@end

#pragma mark -- 用户转接号码信息
@interface DoorDuCallTransfer : DoorDuBaseResponse

/**1：有权限设置转接号码 0：无权限设置转接号码*/
@property (nonatomic,copy) NSString *set_permission;
/**国家码，默认86*/
@property (nonatomic,copy) NSString *nation_code;
/**呼叫转接号码*/
@property (nonatomic,copy) NSString *transfer_mobile;

@end

#pragma mark -- 房间信息
// 支持序列化
@interface DoorDuRoomInfo : DoorDuBaseResponse

/**小区ID*/
@property (nonatomic,copy) NSString *dep_id;
/**小区名称*/
@property (nonatomic,copy) NSString *dep_name;
/**栋ID*/
@property (nonatomic,copy) NSString *building_id;
/**栋名称*/
@property (nonatomic,copy) NSString *building_name;
/**单元ID*/
@property (nonatomic,copy) NSString *unit_id;
/**单元名称*/
@property (nonatomic,copy) NSString *unit_name;
/**房间ID*/
@property (nonatomic,copy) NSString *room_number_id;
/**房间号码*/
@property (nonatomic,copy) NSString *room_number;
/**是否为业主 0-业主 1-家人 2-租客 3-临时客人*/
@property (nonatomic,copy) NSString *autu_type;
/**授权人数*/
@property (nonatomic,copy) NSString *authorization_number;
/**授权开卡数*/
@property (nonatomic,copy) NSString *open_card_number;
/**房间名称全称*/
@property (nonatomic,copy) NSString *room_full_name;

@end

#pragma mark -- 钥匙信息
@interface DoorDuKeyInfo : DoorDuBaseResponse

/**门禁ID*/
@property (nonatomic,copy) NSString *door_id;
/**门禁名称*/
@property (nonatomic,copy) NSString *door_name;
/**别名*/
@property (nonatomic,copy) NSString *door_alias;
/**门禁GUID*/
@property (nonatomic,copy) NSString *door_guid;
/**SIP账号*/
@property (nonatomic,copy) NSString *door_sip_no;
/**WIFI热点名称*/
@property (nonatomic,copy) NSString *ssid;
/**热点密钥*/
@property (nonatomic,copy) NSString *ssid_secretkey;
/**热点密码*/
@property (nonatomic,copy) NSString *ssid_pwd;
/**0：默认1:围墙机 2：单元门 3：地下车库*/
@property (nonatomic,copy) NSString *door_type;
/**门禁机是否支持动态令牌 NO:不支持 YES：支持*/
@property (nonatomic,assign) BOOL is_support_token;
/**门禁机动态令牌秘钥*/
@property (nonatomic,copy) NSString *totp_token;
/**令牌长度，默认6位*/
@property (nonatomic,copy) NSString *totp_pin_length;
/**令牌有效期默认360秒*/
@property (nonatomic,copy) NSString *totp_expires_time;
/**NO:不在线 YES：在线*/
@property (nonatomic,assign) BOOL is_online;
/**3:Door3、4:Door4、5:Door5*/
@property (nonatomic,copy) NSString *door_version_type;
/**门禁机版本描述，Door3、Door4、Door5*/
@property (nonatomic,copy) NSString *door_version_describe;

@end

#pragma mark -- 钥匙列表
@interface DoorDuKeyList : DoorDuBaseResponse

/**小区是否支持蓝牙钥匙开门 NO:不支持 YES：支持*/
@property (nonatomic,assign) BOOL isBluetooth;
/**管理处电话号码*/
@property (nonatomic,copy) NSString *management_phone;
/**钥匙列表数据*/
@property (nonatomic,copy) NSArray<DoorDuKeyInfo *> * list;

@end

#pragma mark -- 小区公告信息
@interface DoorDuCommunityNotice : DoorDuBaseResponse

/**物业通知ID*/
@property (nonatomic,copy) NSString *notice_id;
/**标题*/
@property (nonatomic,copy) NSString *title;
/**内容*/
@property (nonatomic,copy) NSString *content;
/**内容富文本*/
@property (nonatomic,copy) NSString *content_remark;
/**发布者*/
@property (nonatomic,copy) NSString *publisher;
/**是否紧急 0-否 1-是*/
@property (nonatomic,copy) NSString *is_urgent;
/**置顶 0-否 1-是*/
@property (nonatomic,copy) NSString *is_top;
/**添加时间*/
@property (nonatomic,copy) NSString *add_time;
/**是否为系统通知 0-否 1-是*/
@property (nonatomic,copy) NSString *is_system;
/**小区名称*/
@property (nonatomic,copy) NSString *dep_name;

@end

#pragma mark -- 访客留影信息
@interface DoorDuVistorHistoryInfo : DoorDuBaseResponse

/**开门记录的主键ID*/
@property (nonatomic,copy) NSString *recordId;
/**开门类型 1-IC卡开门 2-APP开门 3-呼叫开门 4-密码开门 5-未开门*/
@property (nonatomic,copy) NSString *open_type;
/**开门类型解释*/
@property (nonatomic,copy) NSString *open_type_info;
/**详情描述*/
@property (nonatomic,copy) NSString *des;
/**缩略图地址*/
@property (nonatomic,copy) NSString *thumbnail_url;
/**访客照片原地址*/
@property (nonatomic,copy) NSString *img_url;
/**是否接通 0-未接通 1-已接通，开门类型为呼叫开门时有效*/
@property (nonatomic,copy) NSString *is_connect;
/**开门时间戳*/
@property (nonatomic,copy) NSString *timestamp;
/**房间id*/
@property (nonatomic,copy) NSString *room_id;
/**门禁GUID*/
@property (nonatomic,copy) NSString *door_guid;
/**开门日期，例如：2015-10-10*/
@property (nonatomic,copy) NSString *date;
/**开门时间，例如：12:40*/
@property (nonatomic,copy) NSString *time;
/**开门人*/
@property (nonatomic,copy) NSString *user_name;
/**开门的门禁机名称*/
@property (nonatomic,copy) NSString *door_name;
/**客户类型：0-业主,1-家人,2-租客,3-临时客人,4-代理人*/
@property (nonatomic,copy) NSString *owner_type;

@end

#pragma mark -- 申请密码开门，门禁状态
@interface DoorDuDoorPwdStatue : DoorDuBaseResponse

/**密码是否可用*/
@property (nonatomic,assign)  BOOL success;
/**消息内容*/
@property (nonatomic,copy) NSString *msg;
/**门禁id*/
@property (nonatomic,copy) NSString *door_id;
/**门禁guid*/
@property (nonatomic,copy) NSString *door_guid;

@end

#pragma mark -- 门禁密码
@interface DoorDuDoorPassword : DoorDuBaseResponse

/**申请的密码，申请失败时为空*/
@property (nonatomic,copy) NSString *password;
/**密码销毁的时间，申请失败时为空*/
@property (nonatomic,copy) NSString *expired_time;
/**门禁列表状态*/
@property (nonatomic,copy) NSArray<DoorDuDoorPwdStatue *> *list;

@end

#pragma mark -- 门禁密码(密码开门密码列表)
@interface DoorDuOpenDoorPwd : DoorDuBaseResponse
/**密码唯一标识符（由于password可能不唯一，故使用此参数）*/
@property (nonatomic,copy) NSString *password_id;
/**开门密码*/
@property (nonatomic,copy) NSString *password;
/**状态 0-未使用 1-已使用 2-已过期*/
@property (nonatomic,copy) NSString *status;
/**status状态的解释 状态 0-未使用 1-已使用 2-已过期*/
@property (nonatomic,copy) NSString *msg;
/**密码申请时间*/
@property (nonatomic,copy) NSString *apply_time;
@end

#pragma mark -- 密码详情(门禁机列表)
@interface DoorDuOpenDoorDoorStatus : DoorDuBaseResponse
/**门禁机GUID*/
@property (nonatomic,copy) NSString *door_guid;
/**门禁机别名*/
@property (nonatomic,copy) NSString *door_name;
/**状态 0-未使用 1-已使用 2-已过期*/
@property (nonatomic,copy) NSString *status;
/**密码使用状态的解释 状态 0-未使用 1-已使用 2-已过期*/
@property (nonatomic,copy) NSString *msg;
/**使用时间，只有已使用才有值*/
@property (nonatomic,copy) NSString *use_time;
@end

#pragma mark -- 密码详情(密码开门密码详情)
@interface DoorDuOpenDoorPasswordDetail : DoorDuBaseResponse
/**开门密码*/
@property (nonatomic,copy) NSString *password;
/**密码申请时间*/
@property (nonatomic,copy) NSString *apply_time;
@property (nonatomic,copy) NSArray<DoorDuOpenDoorDoorStatus *> *doorsStatus;
@end

#pragma mark -- 呼叫响应
@interface DoorDuCall : DoorDuBaseResponse
/**
 *  过期时间
 */
@property (nonatomic,copy) NSString *expiredSeconds;
/**
 *  会话ID
 */
@property (nonatomic,copy) NSString *transactionId;
/**
 *  被呼叫的caller列表
 */
@property (nonatomic,copy) NSArray *callerList;
/**
 *  被呼叫房号的roomID
 */
@property (nonatomic,copy) NSNumber *toRoomId;

@end

#pragma mark -- 房间呼叫免打扰信息
@interface DoorDuRoomCallDisturbInfo : DoorDuBaseResponse

/**APP呼叫一键免打扰；0-关闭、1-开启、2-夜间开启*/
@property (nonatomic,copy) NSString *app_status;
/**呼叫转接免电话打扰；0-关闭、1-开启、2-夜间开启*/
@property (nonatomic,copy) NSString *call_status;
/**房间唯一标识*/
@property (nonatomic,copy) NSString *room_id;

@end

#pragma mark -- 呼叫免打扰信息
@interface DoorDuCallDisturbInfo : DoorDuBaseResponse

/**APP呼叫一键免打扰；0-关闭、1-开启*/
@property (nonatomic,copy) NSString *app_status;
/**呼叫转接电话免打扰免打扰；0-关闭、1-开启*/
@property (nonatomic,copy) NSString *call_status;
/**被呼叫的caller列表*/
@property (nonatomic,copy) NSArray<DoorDuRoomCallDisturbInfo *> *room_disturb_list;

@end

#pragma mark -- 房间免打扰设置结果
@interface DoorDuRoomDisturbSettingResult : DoorDuBaseResponse

/**app免打扰类型 0-关闭 1-开启 2-只在夜间开启*/
@property (nonatomic,copy) NSString *app_status;
/**呼叫转接电话免打扰开关，0-关闭，1-打开，2-夜间开启*/
@property (nonatomic,copy) NSString *call_status;

@end

#pragma mark -- 一键免打扰设置结果
@interface DoorDuDisturbSettingResult : DoorDuBaseResponse

/**APP呼叫开关状态 0-关 1-开*/
@property (nonatomic,copy) NSString *app_status;
/**呼叫转接电话开关状态，0-关，1-开*/
@property (nonatomic,copy) NSString *call_status;

@end

#pragma mark -- 实体卡信息
@interface DoorDuEntityCardInfo : DoorDuBaseResponse

/**小区名称*/
@property (nonatomic,copy) NSString *dep_name;
/**业主名称*/
@property (nonatomic,copy) NSString *owner_name;
/**授权开始时间*/
@property (nonatomic,copy) NSString *start_time;
/**授权结束时间*/
@property (nonatomic,copy) NSString *end_time;
/**授权状态码 0删除 1正常(白) 2停用(黑) 3代表卡过期 20卡已注销*/
@property (nonatomic,copy) NSString *status_code;
/**授权状态信息0删除 1正常(白) 2停用(黑) 3代表卡过期 20卡已注销*/
@property (nonatomic,copy) NSString *status_info;
/**卡号*/
@property (nonatomic,copy) NSString *card_number;
/**卡类型
 1:门口机 2:Andriod手机
 3:IOS手机 4:室内机
 5:门禁卡 6:别墅机
 7:物业管理机 8:物业管理平台
 9:86盒 10:机顶盒
 11:身份证卡 13:流动人口管理平台
 16:银行卡 17:居住证卡
 18:羊城通卡 19:其他卡
 20:单片机 21:国密卡
 22:数模转换机 23:NVR录像机
 24:蓝牙钥匙 25:蓝牙手环
 26:手机蓝牙 27:访客一体机
 30:CPU卡 85:银联卡
 */
@property (nonatomic,copy) NSString *card_type;
/** 卡类型描述  */
@property (nonatomic,copy) NSString *card_type_info;
/** 卡类型描述 同 card_type_info */
@property (nonatomic,copy) NSString *remark;
/** 备注 */
@property (nonatomic,copy) NSString *memo;

@end

// 卡类型
//typedef NS_ENUM(NSUInteger, DoorDuEntityCardType) {
//    
//};

#pragma mark -- 我的小区信息
@interface DoorDuCommunityInfo : DoorDuBaseResponse

/**小区ID*/
@property (nonatomic,copy) NSString *dep_id;
/**小区名称*/
@property (nonatomic,copy) NSString *dep_name;
/**栋ID*/
@property (nonatomic,copy) NSString *building_id;
/**栋名称*/
@property (nonatomic,copy) NSString *building_name;
/**单元ID*/
@property (nonatomic,copy) NSString *unit_id;
/**单元名称*/
@property (nonatomic,copy) NSString *unit_name;
/**房间ID*/
@property (nonatomic,copy) NSString *room_number_id;
/**房间号码*/
@property (nonatomic,copy) NSString *room_number;
/**是否为业主 0-业主 1-家人 2-租客 3-临时客人*/
@property (nonatomic,copy) NSString *autu_type;
/**授权人总数*/
@property (nonatomic,copy) NSString *auth_counts;
/**卡数*/
@property (nonatomic,copy) NSString *card_counts;

@end

#pragma mark --- 授权信息
@interface DoorDuAuthorizeInfo : DoorDuBaseResponse

/**被授权用户id*/
@property (nonatomic,copy) NSString *auth_user_id;
/**被授权用户手机号*/
@property (nonatomic,copy) NSString *auth_user_mobile;
/**被授权用户名称*/
@property (nonatomic,copy) NSString *auth_user_name;
/**有效时间（开始时间）例如：2015.01.12*/
@property (nonatomic,copy) NSString *begin_time;
/**有效时间（结束时间）例如：2015.02.12*/
@property (nonatomic,copy) NSString *end_time;
/**是否为无限制 0-否 1-是无限制*/
@property (nonatomic,copy) NSString *is_no_limit;
/**授权类型 1-家人 2-租客 3-临时客人*/
@property (nonatomic,copy) NSString *auth_type;
/**授权类型解释*/
@property (nonatomic,copy) NSString *auth_type_info;
/**国家码*/
@property (nonatomic,copy) NSString *nation_code;

@end

#pragma mark --- 授权信息列表
@interface DoorDuAuthorizeListInfo : DoorDuBaseResponse

/**授权人数上限,0无限制,-1不能授权，大于0就是限制人数*/
@property (nonatomic,copy) NSString *upper_limit;
/**已授权列表总人数*/
@property (nonatomic,copy) NSString *auth_list_number;
/**授权列表*/
@property (nonatomic,copy) NSArray<DoorDuAuthorizeInfo *> *authList;

@end

#pragma mark -- 物业回复消息
@interface DoorDuPropertyMessage : DoorDuBaseResponse
/**回复的内容*/
@property (nonatomic,copy) NSString *msg;
/**内容*/
@property (nonatomic,copy) NSString *create_time;
@end

#pragma mark --- 物业消息信息
@interface DoorDuPropertyPublishInfo : DoorDuBaseResponse
/**内容*/
@property (nonatomic,copy) NSString *content;
/**照片名称（数组类型）*/
@property (nonatomic,copy) NSArray *photos_name;
/**类型：0-其它，1-投诉建议，2-报修维护，3-失物招领’;*/
@property (nonatomic,copy) NSString *tag_type;
/**tag_type_info：0-其它，1-投诉建议，2-报修维护，3-失物招领’*/
@property (nonatomic,copy) NSString *tag_type_info;
/**用户id*/
@property (nonatomic,copy) NSString *user_id;
/**处理状态；0-已发送，1-处理中，2-已解决*/
@property (nonatomic,copy) NSString *status;
/**发布时间*/
@property (nonatomic,copy) NSString *create_time;
/**物业回复的内容*/
@property (nonatomic,copy) NSArray<DoorDuPropertyMessage *> *reply_list;
@end

#pragma mark -- 物业通知
@interface DoorDuPropertyNotice : DoorDuBaseResponse

/**通知类型*/
@property (nonatomic,assign) DoorDuPropertyNoticeType noticeType;
/**
 * DoorDuPropertyNoticeType 对应的ID（楼栋、单元、房间、用户）
 * 例：noticeType为kDoorDuPropertyNoticeUnitType,noticeType_id为对应的 room id（唯一标识）
 */
@property (nonatomic,copy) NSString *noticeType_id;
/**发送人*/
@property (nonatomic,copy) NSString *adduser;
/**内容*/
@property (nonatomic,copy) NSString *content;
/**物业通知ID*/
@property (nonatomic,copy) NSString *notice_id;
/**日期*/
@property (nonatomic,copy) NSString *time;
/**标题*/
@property (nonatomic,copy) NSString *title;
/**是否紧急(1:紧急，0:普通通知)*/
@property (nonatomic,copy) NSString *urgent;

@end

#pragma mark -- 授权变更通知
@interface DoorDuAuthorizationChange : DoorDuBaseResponse

/**标题*/
@property (nonatomic,copy) NSString *title;
/**内容*/
@property (nonatomic,copy) NSString *content;
/**房间id*/
@property (nonatomic,copy) NSString *room_id;
/** 授权变更类型 */
@property (nonatomic,assign) DoorDuAuthorizationChangeType type;

@end

#pragma mark -- 全国小区搜索
@interface DoorDuEstateDepartmentSearch : DoorDuBaseResponse

/**城市ID*/
@property (nonatomic,copy) NSString *city_id;
/**城市名称*/
@property (nonatomic,copy) NSString *city_name;
/**小区ID*/
@property (nonatomic,copy) NSString *dep_id;
/**小区名称*/
@property (nonatomic,copy) NSString *dep_name;
/**省份名称*/
@property (nonatomic,copy) NSString *province_name;
/**区名称*/
@property (nonatomic,copy) NSString *district_name;

@end

#pragma mark -- 城市列表
@interface DoorDuEstateCity : DoorDuBaseResponse

/**城市ID*/
@property (nonatomic,copy) NSString *city_id;
/**城市名称*/
@property (nonatomic,copy) NSString *city_name;

@end

#pragma mark -- 小区列表
@interface DoorDuEstateDepartment : DoorDuBaseResponse

/**小区ID*/
@property (nonatomic,copy) NSString *dep_id;
/**小区名称*/
@property (nonatomic,copy) NSString *dep_name;

@end

#pragma mark -- 楼栋单元
@interface DoorDuEstateBuildingUnit : DoorDuBaseResponse

/**栋ID*/
@property (nonatomic,copy) NSString *building_id;
/**栋号*/
@property (nonatomic,copy) NSString *building_no;
/**栋名称*/
@property (nonatomic,copy) NSString *building_name;
/**单元ID*/
@property (nonatomic,copy) NSString *unit_id;
/**单元号*/
@property (nonatomic,copy) NSString *unit_no;
/**单元名称*/
@property (nonatomic,copy) NSString *unit_name;
/**楼栋单元信息全拼*/
@property (nonatomic,copy) NSString *full_name;

@end

#pragma mark -- 房间列表
@interface DoorDuEstateRoomNumber : DoorDuBaseResponse

/**房间ID*/
@property (nonatomic,copy) NSString *room_number_id;
/**房号*/
@property (nonatomic,copy) NSString *room_number;
/**1：开过卡 0：未开过卡*/
@property (nonatomic,copy) NSString *is_open_card;

@end

#pragma mark -- 自助授权申请记录
@interface DoorDuSelfAuthRecord : DoorDuBaseResponse

/**申请时间*/
@property (nonatomic,copy) NSString *apply_time;
/**审核状态值0，1，2*/
@property (nonatomic,copy) NSString *status_code;
/**审核状态信息 0未审核，1审核通过，2审核不通过*/
@property (nonatomic,copy) NSString *status_info;
/**申请人手机号*/
@property (nonatomic,copy) NSString *mobile_no;
/**申请人*/
@property (nonatomic,copy) NSString *apply_person;
/**申请身份*/
@property (nonatomic,copy) NSString *apply_identity;
/**申请城市名称*/
@property (nonatomic,copy) NSString *city_name;
/**申请小区名称*/
@property (nonatomic,copy) NSString *dep_name;
/**楼栋房号全称*/
@property (nonatomic,copy) NSString *room_full_name;
/**自助登记卡状态*/
@property (nonatomic,copy) NSString *self_help_status;
/**备注状态*/
@property (nonatomic,copy) NSString *review_reason;
/**自助开卡验证码*/
@property (nonatomic,copy) NSString *verification_code;

@end

#pragma mark -- 自助授权申请记录
@interface DoorDuOwnMobile : DoorDuBaseResponse

/**用户时间*/
@property (nonatomic,copy) NSString *mobile_no;

@end

#pragma mark -- 呼叫转接号码
@interface DoorDuCallTranferMobile : DoorDuBaseResponse

/**用户时间*/
@property (nonatomic,copy) NSString *numbers;

@end

#pragma mark -- face++ 身份证识别，身份证正面信息
@interface DoorDuFaceplusplusIdentifyCardSideFront : DoorDuBaseResponse

@property (nonatomic,assign) int type;//证件类型，返回1，代表是身份证。
@property (nonatomic,copy) NSString * address;//住址
@property (nonatomic,copy) NSString * birthday;//生日，格式为YYYY-MM-DD
@property (nonatomic,copy) NSString * gender;//性别（男/女）
@property (nonatomic,copy) NSString * id_card_number;//身份证号
@property (nonatomic,copy) NSString * name;//姓名
@property (nonatomic,copy) NSString * race;//民族（汉字）
@property (nonatomic,copy) NSString * side;//front/back 表示身份证的正面或者反面（illegal）

- (BOOL)checkValue;

@end

#pragma mark -- face++ 身份证识别，身份证反面信息
@interface DoorDuFaceplusplusIdentifyCardSideBack : DoorDuBaseResponse

@property (nonatomic,assign) int type;//证件类型，返回1，代表是身份证。
@property (nonatomic,copy) NSString * issued_by;//签发机关
@property (nonatomic,copy) NSString * side;//front/back 表示身份证的正面或者反面（illegal）
@property (nonatomic,copy) NSString * valid_date;//有效日期，格式为一个16位长度的字符串，表示内容如下YYYY.MM.DD-YYYY.MM.DD，或是YYYY.MM.DD-长期。

- (BOOL)checkValue;

@end


