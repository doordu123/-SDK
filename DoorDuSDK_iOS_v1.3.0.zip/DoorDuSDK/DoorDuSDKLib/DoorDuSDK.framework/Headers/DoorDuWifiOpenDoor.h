//
//  DoorDuWifiOpenDoor.h
//  DoorDuSDK
//
//  Created by DoorDu on 2018/1/12.
//  Copyright © 2018年 深圳市多度科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

@class DoorDuError;
@interface DoorDuWifiOpenDoor : NSObject

/**
 判断当前是否为wifi连接
 
 @return yes表示wifi连接
 */
- (BOOL)isConnectByWifi;

/**
 获取wifi ssid， 用于用户与门禁机SSID名称比较
 只有在wifi连接的情况下才能获取ssid，否则返回nil
 @return ssid
 */
- (NSString *)getSSID;


/**
 wifi开门禁机接口

 @param roomId 用户所在的房间id
 @param ssidKey 热点秘钥(通钥匙信息一起返回)
 @param completion 开门结果回调
 */
- (void)openDoorWithRoomId:(NSString *)roomId
                   ssidKey:(NSString *)ssidKey
                completion:(void(^)(BOOL isSuccess, DoorDuError *error))completion;

@end
